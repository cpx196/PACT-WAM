# Corrected predictor: 35 original harm cases

Source: long800_paired_seed7_20260927, 756 completed paired results. Select only
no-guidance success / old 4x guidance failure. Exactly 35 unique tasks, seed7,
one trial and initial state0. This selected cohort is not an unbiased benchmark.
No control rerun, no rescue or stable-success tasks added.

GPU2 only; nohup detached launcher. Output:
evaluate_results/harm35_euler_fixed_20260928/guidance4x_euler_fixed.
Frozen task list and original individual results: task_manifest.json.

FastWAM: checkpoints/fastwam/libero_optional_idm_2cam224.pt, unchanged BF16.
JEPA encoder: frozen original vjepa2-ac-vitg encoder; predictor from
artifacts/jepa_libero90_euler_fixed_rot180_20260928/train_2000/step_002000.pt.
Inference export: checkpoints/vjepa2-ac-libero90-euler-fixed-rot180-step2000-inference.pt.
Training checkpoint retained with optimizer/scheduler. Corrected training data
format libero_ac_euler_v1 converts source EEF rotvec to Euler XYZ.

JEPA FP32; both image inputs inverted as in original run: camera rotation180,
encoder extra rotation0. Main camera only in JEPA; FastWAM two cameras.
Video/action shifts1/1, inference10 denoise steps, execute8 actions/replan,
max700 simulation steps plus30 wait, optional-IDM action generation.
Full guidance every replan, no trigger. After steps7/8/9, raw multiplier4,
normalize_gradient=false, RMS cap0.02, AC steps2, verify_descent=true,
encoder/action overlap=true. No new action compilation or gripper protection.

Historical guided episode durations sum4.3964 hours. Estimated4.5–6 hours
single-card wall time including startup and shared-server variation; recovered
successes may finish sooner. Report number of original harms recovered /35,
not full benchmark success-rate improvement.
