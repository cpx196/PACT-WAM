# Original rescue retention: corrected EEF predictor

34 cases selected from756 paired long800 results: original no-guidance failure,
old4x-guidance success. Seed7, initial state0, one rollout each, same tasks.
Only test these34; reuse historical control. Selected cohort, not unbiased accuracy.
GPU3/7 shared queue, two persistent workers, nohup+setsid launcher.
Output evaluate_results/rescue34_euler_fixed_20260929/guidance4x_euler_fixed.

Same settings as corrected harm35 test: FastWAM optional-IDM two-camera BF16
libero_optional_idm_2cam224.pt; JEPA FP32 frozen original encoder with corrected
libero_ac_euler_v1 predictor step2000. Inference export:
checkpoints/vjepa2-ac-libero90-euler-fixed-rot180-step2000-inference.pt.
Both JEPA image streams inverted, camera180/additional encoder0; main view only.
Video/action shift1/1, inference10 steps, execute8 actions per replan,
max700+30 wait. Full guidance every replan, trigger off; raw4x after7/8/9,
normalize=false, RMS cap0.02, ACsteps2, verify_descent=true,
overlap_encoder_with_action=true, compile_action_infer=false. No gripper changes.

Old episode duration sum2.797 GPU-hours. Dual-card estimate1.5–2.5h including
load overhead and potentially longer failures (loss of original rescue).
Report retained rescues /34 and lost rescues /34; compare jointly with harm35
recovered17, remaining18. Do not extrapolate to all756 without stable-case tests.
