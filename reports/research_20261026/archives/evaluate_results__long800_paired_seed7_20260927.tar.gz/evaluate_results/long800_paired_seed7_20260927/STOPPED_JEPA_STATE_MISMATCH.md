# JEPA 实验组因姿态口径错误停止

2026-09-28，按用户要求停止实验组 experiment_rot180_guidance4x。
已终止该组 launcher、manager 和 GPU2 worker；未终止 GPU1 无 guidance 对照组。
此前 GPU3/4/7 的诊断任务也已全部按用户要求停止。

原因：旧 predictor finetune 将 LIBERO HDF5 ee_states 的轴角后三维
直接传给假定 Euler XYZ 的 adapter；在线初始姿态由四元数正确转换为
Euler XYZ。训练/在线输入口径不一致，后续推算状态亦受影响。

已完成结果、视频、日志、旧权重均保留。不删除，不自动续跑旧实验组。
这些结果可用于诊断旧配置的行为，但不可当作修复后 JEPA guidance 的
正式效果评估。无 guidance 对照不使用 JEPA，不受这个问题影响。

已有 CPU 小样本转换与一致性检查通过；尚未训练修复后的 predictor。
重新启动评测前需要正确训练权重，并遵守用户的小规模/短时资源限制。
