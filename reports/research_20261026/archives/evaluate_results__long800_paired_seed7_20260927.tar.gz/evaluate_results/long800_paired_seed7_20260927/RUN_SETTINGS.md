# Long800 paired evaluation — 2026-09-27

## Shared settings

- Fixed 800 distinct LIBERO-plus libero_10 variants: task-list SHA256 `820b48c41f95ff8cf0247565095be2e3396262b0a8271acd0f985bea667652da`.
- Rollout seed 7; one trial per task; initial-state index 0; 1600 paired episodes total.
- FastWAM: `/data/pxchen/PACT-WAM/checkpoints/fastwam/libero_optional_idm_2cam224.pt`; companion `_dataset_stats.json`; BF16; IDM, main+wrist views.
- Denoise steps 10; replan steps 8; video/action sigma shift 1/1; sigma_shift null.
- Maximum control steps 700; initialization wait 30; execution gripper binarization enabled.
- Native OOD camera preserved; original 180-degree image convention.
- compile_action_infer false; visualize_future_video true; text encoder offloaded after caching.

## Groups

- Control: GPU 1, no JEPA and no guidance.
- Experiment: GPU 2+5 shared task queue, full guidance every replan, no trigger/probe, steps 7/8/9.
- JEPA checkpoint: `/data/pxchen/PACT-WAM/checkpoints/vjepa2-ac-libero90-rot180-step2000-inference.pt`.
- JEPA FP32; primary agentview only; no extra rotation: current/future images both inverted, matching training.
- Raw gradient step size 4; gradient normalization false; max correction RMS 0.02; AC steps 2; verify_descent true (diagnostic, not acceptance/backtracking).
- Encoder overlaps action; legacy candidate settings num_action_candidates 8 and candidate_generation_mode separate retained unchanged.

## Execution

- nohup + setsid detached launcher, exclusive flock prevents duplicate launcher.
- Remote root: `/data/pxchen/PACT-WAM/evaluate_results/long800_paired_seed7_20260927`.
- Launcher: `/data/pxchen/PACT-WAM/scripts/launch_long800_paired.sh`.
- Existing completed task JSONs are skipped on restart.
- Estimate before observing this batch: 28–38 hours total; calibration needed after first 30–50 tasks.

## Startup status

- Control initially launched 2026-09-27 10:32:58 HKT and kept running uninterrupted.
- Experimental GPU3 and replacement GPU4 encountered OOM during loading as other users' processes concurrently occupied those GPUs. Their logs are archived in `startup_oom_archive` and `startup_gpu4_archive`; other users' jobs were not modified.
- Experimental manager alone was restarted at 10:41:29 on GPUs 2,5. Model parameters, weights and task-list checksum unchanged.
- At 10:45:01, all three workers executing rollouts: control task1601; experimental task946 and task1348. Experimental workers both emitted finite steps7/8/9 guidance diagnostics.
- Main launcher's eventual nonzero completion reflects the terminated initial experimental manager, not the resumed experiment. Check current `experiment_rot180_guidance4x/run.log`, `launcher_experiment_resume_gpu5.log`, per-group result counts and worker status for completion.

## User-requested GPU5 stop — 2026-09-28 13:03 HKT

- SIGTERM sent only to verified pxchen experimental worker PID1636805 (GPU5).
- Manager confirmed `requeued GPU5 task: libero_10,1930` and quarantined GPU5; PID exited and GPU5 released to 19 MiB.
- Experiment now continues on GPU2 (PID1636804), processing the shared remaining queue; completed 693/800 at handoff.
- Control GPU1 (PID1579768) and experimental manager remained alive. No parameter or task-list changes.
- Task1930 will restart from its episode beginning; completed task results remain unchanged.
