# Long-horizon paired evaluation: fixed 800-task list

Single rollout seed 7; initial-state index 0; 800 distinct tasks per group. Not launched.

## Sampling balance

| Base task | Objects Layout | Camera Viewpoints | Robot Initial States | Language Instructions | Light Conditions | Background Textures | Sensor Noise | Total |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it | 12 | 11 | 11 | 11 | 12 | 12 | 11 | 80 |
| KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it | 11 | 11 | 12 | 12 | 12 | 11 | 11 | 80 |
| KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it | 11 | 11 | 11 | 11 | 13 | 12 | 11 | 80 |
| KITCHEN_SCENE8_put_both_moka_pots_on_the_stove | 11 | 11 | 12 | 11 | 12 | 12 | 11 | 80 |
| LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket | 13 | 15 | 12 | 14 | 4 | 8 | 14 | 80 |
| LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket | 11 | 11 | 11 | 11 | 13 | 12 | 11 | 80 |
| LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket | 12 | 11 | 11 | 11 | 12 | 12 | 11 | 80 |
| LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate | 11 | 11 | 12 | 11 | 12 | 11 | 12 | 80 |
| LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate | 11 | 12 | 11 | 11 | 12 | 12 | 11 | 80 |
| STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy | 12 | 11 | 11 | 11 | 12 | 12 | 11 | 80 |

Task-list SHA256: 820b48c41f95ff8cf0247565095be2e3396262b0a8271acd0f985bea667652da

## Complete list

| Order | Task ID (0-based) | OOD | Difficulty | Name |
|---:|---:|---|---:|---|
| 1 | 1348 | Language Instructions | 3 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_language_26_view_0_0_100_0_0_initstate_0 |
| 2 | 946 | Camera Viewpoints | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_304_0_100_0_0_initstate_0 |
| 3 | 1601 | Sensor Noise | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_0_noise_39 |
| 4 | 355 | Robot Initial States | 3 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_392 |
| 5 | 2362 | Light Conditions | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_light_40 |
| 6 | 759 | Camera Viewpoints | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_34_0_100_0_0_initstate_0 |
| 7 | 2017 | Objects Layout | 2 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_level4_sample4 |
| 8 | 725 | Camera Viewpoints | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_26_15_100_0_0_initstate_0 |
| 9 | 88 | Background Textures | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_table_26 |
| 10 | 1836 | Sensor Noise | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_49 |
| 11 | 1019 | Camera Viewpoints | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_182_0_0_initstate_0 |
| 12 | 918 | Camera Viewpoints | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_297_15_100_0_0_initstate_0 |
| 13 | 470 | Robot Initial States | 1 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_255 |
| 14 | 1708 | Sensor Noise | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_0_noise_50 |
| 15 | 1476 | Language Instructions | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_language_40_view_0_0_100_0_0_initstate_0 |
| 16 | 109 | Background Textures | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_table_13 |
| 17 | 1240 | Language Instructions | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_language_34_view_0_0_100_0_0_initstate_0 |
| 18 | 150 | Background Textures | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_table_3 |
| 19 | 383 | Robot Initial States | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_223 |
| 20 | 175 | Background Textures | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_tb_10 |
| 21 | 1390 | Language Instructions | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_23_view_0_0_100_0_0_initstate_0 |
| 22 | 2315 | Light Conditions | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_light_36 |
| 23 | 2390 | Light Conditions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_light_38 |
| 24 | 1427 | Language Instructions | 3 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_language_24_view_0_0_100_0_0_initstate_0 |
| 25 | 1783 | Sensor Noise | 2 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_0_noise_34 |
| 26 | 826 | Camera Viewpoints | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_59_15_100_0_0_initstate_0 |
| 27 | 643 | Robot Initial States | 2 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_40 |
| 28 | 840 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_10_6_initstate_0 |
| 29 | 282 | Background Textures | 1 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_table_28 |
| 30 | 2455 | Light Conditions | 4 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_light_36 |
| 31 | 1550 | Sensor Noise | 4 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_0_noise_30 |
| 32 | 1939 | Objects Layout | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_add_24 |
| 33 | 249 | Background Textures | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_table_24 |
| 34 | 2251 | Light Conditions | 5 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_light_15 |
| 35 | 2050 | Objects Layout | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_level2_sample3 |
| 36 | 2427 | Light Conditions | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_light_46 |
| 37 | 1629 | Sensor Noise | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_0_noise_17 |
| 38 | 1291 | Language Instructions | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_language_44_view_0_0_100_0_0_initstate_0 |
| 39 | 2161 | Objects Layout | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_level5_sample4 |
| 40 | 2412 | Light Conditions | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_light_50 |
| 41 | 2035 | Objects Layout | 1 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_level1_sample4 |
| 42 | 2181 | Objects Layout | 1 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_level1_sample3 |
| 43 | 31 | Background Textures | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_tb_8 |
| 44 | 982 | Camera Viewpoints | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_354_10_initstate_0 |
| 45 | 139 | Background Textures | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_table_16 |
| 46 | 212 | Background Textures | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_table_5 |
| 47 | 624 | Robot Initial States | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_339 |
| 48 | 292 | Robot Initial States | 1 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_71 |
| 49 | 1165 | Language Instructions | 5 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_language_47_view_0_0_100_0_0_initstate_0 |
| 50 | 504 | Robot Initial States | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_276 |
| 51 | 1924 | Sensor Noise | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_0_noise_41 |
| 52 | 2479 | Light Conditions | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_light_30 |
| 53 | 2506 | Light Conditions | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_light_23 |
| 54 | 537 | Robot Initial States | 2 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_147 |
| 55 | 1749 | Sensor Noise | 4 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_0_noise_44 |
| 56 | 1960 | Objects Layout | 1 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_add_11 |
| 57 | 1518 | Sensor Noise | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_0_noise_38 |
| 58 | 2060 | Objects Layout | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_add_10 |
| 59 | 1845 | Sensor Noise | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_0_noise_8 |
| 60 | 2401 | Light Conditions | 4 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_light_37 |
| 61 | 1310 | Language Instructions | 1 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_language_22_view_0_0_100_0_0_initstate_0 |
| 62 | 602 | Robot Initial States | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_458 |
| 63 | 64 | Background Textures | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_tb_17 |
| 64 | 1130 | Language Instructions | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_language_33_view_0_0_100_0_0_initstate_0 |
| 65 | 441 | Robot Initial States | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_374 |
| 66 | 1096 | Camera Viewpoints | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_355_15_100_0_0_initstate_0 |
| 67 | 2219 | Objects Layout | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_add_30 |
| 68 | 1202 | Language Instructions | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_language_43_view_0_0_100_0_0_initstate_0 |
| 69 | 685 | Camera Viewpoints | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_2_350_initstate_0 |
| 70 | 2120 | Objects Layout | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_level3_sample3 |
| 71 | 1998 | Objects Layout | 1 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_add_5 |
| 72 | 1036 | Camera Viewpoints | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_331_0_100_0_0_initstate_0 |
| 73 | 2171 | Objects Layout | 2 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_add_22 |
| 74 | 1461 | Language Instructions | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_language_22_view_0_0_100_0_0_initstate_0 |
| 75 | 1071 | Camera Viewpoints | 2 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_358_2_initstate_0 |
| 76 | 2107 | Objects Layout | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_add_28 |
| 77 | 2089 | Objects Layout | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_level5_sample1 |
| 78 | 2426 | Light Conditions | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_light_44 |
| 79 | 1609 | Sensor Noise | 5 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_0_noise_47 |
| 80 | 1126 | Language Instructions | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_language_28_view_0_0_100_0_0_initstate_0 |
| 81 | 284 | Background Textures | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_table_4 |
| 82 | 1296 | Language Instructions | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_language_49_view_0_0_100_0_0_initstate_0 |
| 83 | 2465 | Light Conditions | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_light_7 |
| 84 | 2328 | Light Conditions | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_light_48 |
| 85 | 869 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_72_15_100_0_0_initstate_0 |
| 86 | 1344 | Language Instructions | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_language_22_view_0_0_100_0_0_initstate_0 |
| 87 | 144 | Background Textures | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_table_6 |
| 88 | 2259 | Light Conditions | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_light_24 |
| 89 | 514 | Robot Initial States | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_376 |
| 90 | 2398 | Light Conditions | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_light_11 |
| 91 | 2403 | Light Conditions | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_light_15 |
| 92 | 647 | Robot Initial States | 1 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_100 |
| 93 | 760 | Camera Viewpoints | 5 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_34_15_100_0_0_initstate_0 |
| 94 | 1925 | Sensor Noise | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_0_noise_42 |
| 95 | 1516 | Sensor Noise | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_0_noise_36 |
| 96 | 912 | Camera Viewpoints | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_294_15_100_0_0_initstate_0 |
| 97 | 925 | Camera Viewpoints | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_164_0_0_initstate_0 |
| 98 | 1947 | Objects Layout | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_level2_sample1 |
| 99 | 218 | Background Textures | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_tb_10 |
| 100 | 2217 | Objects Layout | 4 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_add_28 |
| 101 | 448 | Robot Initial States | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_444 |
| 102 | 2475 | Light Conditions | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_light_21 |
| 103 | 1777 | Sensor Noise | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_0_noise_28 |
| 104 | 3 | Background Textures | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_table_13 |
| 105 | 1624 | Sensor Noise | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_0_noise_12 |
| 106 | 361 | Robot Initial States | 5 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_462 |
| 107 | 1539 | Sensor Noise | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_0_noise_14 |
| 108 | 455 | Robot Initial States | 1 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_95 |
| 109 | 104 | Background Textures | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_tb_7 |
| 110 | 733 | Camera Viewpoints | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_30_15_100_0_0_initstate_0 |
| 111 | 1410 | Language Instructions | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_48_view_0_0_100_0_0_initstate_0 |
| 112 | 2357 | Light Conditions | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_light_36 |
| 113 | 1161 | Language Instructions | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_language_40_view_0_0_100_0_0_initstate_0 |
| 114 | 322 | Robot Initial States | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_411 |
| 115 | 48 | Background Textures | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_table_25 |
| 116 | 271 | Background Textures | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_tb_5 |
| 117 | 1188 | Language Instructions | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_language_26_view_0_0_100_0_0_initstate_0 |
| 118 | 1969 | Objects Layout | 1 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_add_28 |
| 119 | 2500 | Light Conditions | 4 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_light_13 |
| 120 | 2052 | Objects Layout | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_level3_sample3 |
| 121 | 1016 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_329_0_100_0_0_initstate_0 |
| 122 | 576 | Robot Initial States | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_188 |
| 123 | 2030 | Objects Layout | 1 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_add_26 |
| 124 | 1856 | Sensor Noise | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_0_noise_20 |
| 125 | 1423 | Language Instructions | 4 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_language_18_view_0_0_100_0_0_initstate_0 |
| 126 | 174 | Background Textures | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_tb_1 |
| 127 | 2132 | Objects Layout | 1 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_add_17 |
| 128 | 1831 | Sensor Noise | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_44 |
| 129 | 134 | Background Textures | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_tb_21 |
| 130 | 827 | Camera Viewpoints | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_60_0_100_0_0_initstate_0 |
| 131 | 527 | Robot Initial States | 2 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_27 |
| 132 | 387 | Robot Initial States | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_263 |
| 133 | 630 | Robot Initial States | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_409 |
| 134 | 1317 | Language Instructions | 1 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_language_32_view_0_0_100_0_0_initstate_0 |
| 135 | 149 | Background Textures | 1 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_table_19 |
| 136 | 2397 | Light Conditions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_light_49 |
| 137 | 690 | Camera Viewpoints | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_4_15_100_0_0_initstate_0 |
| 138 | 1740 | Sensor Noise | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_0_noise_35 |
| 139 | 1692 | Sensor Noise | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_0_noise_34 |
| 140 | 1212 | Language Instructions | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_language_5_view_0_0_100_0_0_initstate_0 |
| 141 | 2442 | Light Conditions | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_light_2 |
| 142 | 303 | Robot Initial States | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_221 |
| 143 | 2003 | Objects Layout | 2 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_level1_sample1 |
| 144 | 1253 | Language Instructions | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_language_49_view_0_0_100_0_0_initstate_0 |
| 145 | 1305 | Language Instructions | 1 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_language_15_view_0_0_100_0_0_initstate_0 |
| 146 | 1897 | Sensor Noise | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_0_noise_14 |
| 147 | 743 | Camera Viewpoints | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_130_0_0_initstate_0 |
| 148 | 280 | Background Textures | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_table_23 |
| 149 | 2235 | Objects Layout | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_level3_sample3 |
| 150 | 1009 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_325_15_100_0_0_initstate_0 |
| 151 | 388 | Robot Initial States | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_273 |
| 152 | 593 | Robot Initial States | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_368 |
| 153 | 23 | Background Textures | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_tb_18 |
| 154 | 2400 | Light Conditions | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_light_24 |
| 155 | 1536 | Sensor Noise | 3 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_0_noise_9 |
| 156 | 239 | Background Textures | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_table_12 |
| 157 | 1720 | Sensor Noise | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_0_noise_13 |
| 158 | 2383 | Light Conditions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_light_27 |
| 159 | 1401 | Language Instructions | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_37_view_0_0_100_0_0_initstate_0 |
| 160 | 1146 | Language Instructions | 4 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_language_2_view_0_0_100_0_0_initstate_0 |
| 161 | 688 | Camera Viewpoints | 1 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_1_15_100_0_0_initstate_0 |
| 162 | 2411 | Light Conditions | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_light_45 |
| 163 | 727 | Camera Viewpoints | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_27_15_100_0_0_initstate_0 |
| 164 | 2505 | Light Conditions | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_light_22 |
| 165 | 490 | Robot Initial States | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_495 |
| 166 | 2473 | Light Conditions | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_light_19 |
| 167 | 794 | Camera Viewpoints | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_8_10_initstate_0 |
| 168 | 2056 | Objects Layout | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_level5_sample2 |
| 169 | 2269 | Light Conditions | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_light_34 |
| 170 | 2308 | Light Conditions | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_light_3 |
| 171 | 1257 | Language Instructions | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_language_3_view_0_0_100_0_0_initstate_0 |
| 172 | 95 | Background Textures | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_table_7 |
| 173 | 1972 | Objects Layout | 1 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_level2_sample1 |
| 174 | 2127 | Objects Layout | 1 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_add_1 |
| 175 | 183 | Background Textures | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_tb_18 |
| 176 | 336 | Robot Initial States | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_162 |
| 177 | 1069 | Camera Viewpoints | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_199_0_0_initstate_0 |
| 178 | 913 | Camera Viewpoints | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_295_0_100_0_0_initstate_0 |
| 179 | 2028 | Objects Layout | 1 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_add_24 |
| 180 | 958 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_310_0_100_0_0_initstate_0 |
| 181 | 1428 | Language Instructions | 1 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_language_26_view_0_0_100_0_0_initstate_0 |
| 182 | 565 | Robot Initial States | 3 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_487 |
| 183 | 124 | Background Textures | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_table_9 |
| 184 | 1605 | Sensor Noise | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_0_noise_43 |
| 185 | 1464 | Language Instructions | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_language_25_view_0_0_100_0_0_initstate_0 |
| 186 | 2073 | Objects Layout | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_add_26 |
| 187 | 2186 | Objects Layout | 2 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_level3_sample1 |
| 188 | 193 | Background Textures | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_table_1 |
| 189 | 1106 | Language Instructions | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_language_6_view_0_0_100_0_0_initstate_0 |
| 190 | 141 | Background Textures | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_table_28 |
| 191 | 416 | Robot Initial States | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_94 |
| 192 | 1869 | Sensor Noise | 3 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_0_noise_35 |
| 193 | 1486 | Sensor Noise | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_0_noise_3 |
| 194 | 625 | Robot Initial States | 4 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_359 |
| 195 | 47 | Background Textures | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_table_24 |
| 196 | 154 | Background Textures | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_tb_2 |
| 197 | 2125 | Objects Layout | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_level5_sample1 |
| 198 | 1040 | Camera Viewpoints | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_333_0_100_0_0_initstate_0 |
| 199 | 1937 | Objects Layout | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_add_21 |
| 200 | 1191 | Language Instructions | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_language_31_view_0_0_100_0_0_initstate_0 |
| 201 | 837 | Camera Viewpoints | 4 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_150_0_0_initstate_0 |
| 202 | 2415 | Light Conditions | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_light_1 |
| 203 | 672 | Robot Initial States | 3 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_410 |
| 204 | 1343 | Language Instructions | 1 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_language_21_view_0_0_100_0_0_initstate_0 |
| 205 | 1828 | Sensor Noise | 4 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_40 |
| 206 | 1627 | Sensor Noise | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_0_noise_15 |
| 207 | 1758 | Sensor Noise | 3 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_0_noise_4 |
| 208 | 1690 | Sensor Noise | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_0_noise_32 |
| 209 | 2358 | Light Conditions | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_light_37 |
| 210 | 501 | Robot Initial States | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_246 |
| 211 | 29 | Background Textures | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_tb_6 |
| 212 | 678 | Robot Initial States | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_470 |
| 213 | 1995 | Objects Layout | 2 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_add_27 |
| 214 | 276 | Background Textures | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_table_1 |
| 215 | 1004 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_323_0_100_0_0_initstate_0 |
| 216 | 535 | Robot Initial States | 1 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_127 |
| 217 | 2057 | Objects Layout | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_level5_sample3 |
| 218 | 693 | Camera Viewpoints | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_7_15_100_0_0_initstate_0 |
| 219 | 1306 | Language Instructions | 1 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_language_16_view_0_0_100_0_0_initstate_0 |
| 220 | 241 | Background Textures | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_table_15 |
| 221 | 1154 | Language Instructions | 3 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_language_20_view_0_0_100_0_0_initstate_0 |
| 222 | 924 | Camera Viewpoints | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_163_0_0_initstate_0 |
| 223 | 475 | Robot Initial States | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_315 |
| 224 | 604 | Robot Initial States | 4 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_478 |
| 225 | 1167 | Language Instructions | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_language_1_view_0_0_100_0_0_initstate_0 |
| 226 | 131 | Background Textures | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_tb_19 |
| 227 | 1892 | Sensor Noise | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_0_noise_9 |
| 228 | 2244 | Objects Layout | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_level5_sample4 |
| 229 | 1432 | Language Instructions | 4 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_language_33_view_0_0_100_0_0_initstate_0 |
| 230 | 896 | Camera Viewpoints | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_285_15_100_0_0_initstate_0 |
| 231 | 2493 | Light Conditions | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_light_48 |
| 232 | 2384 | Light Conditions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_light_29 |
| 233 | 731 | Camera Viewpoints | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_29_15_100_0_0_initstate_0 |
| 234 | 745 | Camera Viewpoints | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_6_4_initstate_0 |
| 235 | 496 | Robot Initial States | 1 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_186 |
| 236 | 2079 | Objects Layout | 1 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_level1_sample4 |
| 237 | 2429 | Light Conditions | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_light_48 |
| 238 | 439 | Robot Initial States | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_354 |
| 239 | 1802 | Sensor Noise | 4 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_6 |
| 240 | 1670 | Sensor Noise | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_0_noise_11 |
| 241 | 1222 | Language Instructions | 1 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_language_16_view_0_0_100_0_0_initstate_0 |
| 242 | 631 | Robot Initial States | 4 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_419 |
| 243 | 2134 | Objects Layout | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_add_19 |
| 244 | 1532 | Sensor Noise | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_0_noise_5 |
| 245 | 77 | Background Textures | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_tb_9 |
| 246 | 1074 | Camera Viewpoints | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_358_8_initstate_0 |
| 247 | 2339 | Light Conditions | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_light_12 |
| 248 | 143 | Background Textures | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_table_4 |
| 249 | 2110 | Objects Layout | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_add_30 |
| 250 | 209 | Background Textures | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_table_27 |
| 251 | 102 | Background Textures | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_tb_20 |
| 252 | 1506 | Sensor Noise | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_0_noise_26 |
| 253 | 1933 | Objects Layout | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_add_14 |
| 254 | 2515 | Light Conditions | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_light_39 |
| 255 | 386 | Robot Initial States | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_253 |
| 256 | 1980 | Objects Layout | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_level5_sample1 |
| 257 | 2399 | Light Conditions | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_light_15 |
| 258 | 1466 | Language Instructions | 3 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_language_28_view_0_0_100_0_0_initstate_0 |
| 259 | 308 | Robot Initial States | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_271 |
| 260 | 2413 | Light Conditions | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_light_6 |
| 261 | 2190 | Objects Layout | 3 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_level4_sample1 |
| 262 | 1110 | Language Instructions | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_language_10_view_0_0_100_0_0_initstate_0 |
| 263 | 1610 | Sensor Noise | 5 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_0_noise_48 |
| 264 | 1795 | Sensor Noise | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_0_noise_47 |
| 265 | 1264 | Language Instructions | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_language_11_view_0_0_100_0_0_initstate_0 |
| 266 | 1737 | Sensor Noise | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_0_noise_32 |
| 267 | 1848 | Sensor Noise | 3 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_0_noise_11 |
| 268 | 2250 | Light Conditions | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_light_14 |
| 269 | 1359 | Language Instructions | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_language_38_view_0_0_100_0_0_initstate_0 |
| 270 | 172 | Background Textures | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_table_8 |
| 271 | 1389 | Language Instructions | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_21_view_0_0_100_0_0_initstate_0 |
| 272 | 1633 | Sensor Noise | 2 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_0_noise_22 |
| 273 | 817 | Camera Viewpoints | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_55_0_100_0_0_initstate_0 |
| 274 | 1045 | Camera Viewpoints | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_336_0_100_0_0_initstate_0 |
| 275 | 2324 | Light Conditions | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_light_44 |
| 276 | 2456 | Light Conditions | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_light_39 |
| 277 | 148 | Background Textures | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_table_13 |
| 278 | 334 | Robot Initial States | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_142 |
| 279 | 871 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_73_15_100_0_0_initstate_0 |
| 280 | 2025 | Objects Layout | 2 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_add_20 |
| 281 | 1807 | Sensor Noise | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_12 |
| 282 | 1981 | Objects Layout | 1 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_level5_sample3 |
| 283 | 278 | Background Textures | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_table_17 |
| 284 | 1023 | Camera Viewpoints | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_187_0_0_initstate_0 |
| 285 | 798 | Camera Viewpoints | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_8_356_initstate_0 |
| 286 | 115 | Background Textures | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_table_21 |
| 287 | 1885 | Sensor Noise | 3 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_0_noise_2 |
| 288 | 1636 | Sensor Noise | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_0_noise_25 |
| 289 | 2430 | Light Conditions | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_light_50 |
| 290 | 2385 | Light Conditions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_light_30 |
| 291 | 622 | Robot Initial States | 3 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_319 |
| 292 | 80 | Background Textures | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_table_15 |
| 293 | 1483 | Language Instructions | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_language_50_view_0_0_100_0_0_initstate_0 |
| 294 | 219 | Background Textures | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_tb_11 |
| 295 | 1169 | Language Instructions | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_language_4_view_0_0_100_0_0_initstate_0 |
| 296 | 844 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_10_352_initstate_0 |
| 297 | 1957 | Objects Layout | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_level5_sample3 |
| 298 | 1307 | Language Instructions | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_language_18_view_0_0_100_0_0_initstate_0 |
| 299 | 1148 | Language Instructions | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_language_5_view_0_0_100_0_0_initstate_0 |
| 300 | 421 | Robot Initial States | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_164 |
| 301 | 516 | Robot Initial States | 4 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_396 |
| 302 | 2048 | Objects Layout | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_add_28 |
| 303 | 2001 | Objects Layout | 1 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_add_8 |
| 304 | 980 | Camera Viewpoints | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_354_6_initstate_0 |
| 305 | 905 | Camera Viewpoints | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_290_0_100_0_0_initstate_0 |
| 306 | 1514 | Sensor Noise | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_0_noise_34 |
| 307 | 1394 | Language Instructions | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_27_view_0_0_100_0_0_initstate_0 |
| 308 | 2461 | Light Conditions | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_light_49 |
| 309 | 147 | Background Textures | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_table_12 |
| 310 | 1573 | Sensor Noise | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_0_noise_11 |
| 311 | 137 | Background Textures | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_table_1 |
| 312 | 700 | Camera Viewpoints | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_14_15_100_0_0_initstate_0 |
| 313 | 1288 | Language Instructions | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_language_40_view_0_0_100_0_0_initstate_0 |
| 314 | 59 | Background Textures | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_tb_12 |
| 315 | 1776 | Sensor Noise | 3 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_0_noise_27 |
| 316 | 780 | Camera Viewpoints | 5 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_45_15_100_0_0_initstate_0 |
| 317 | 403 | Robot Initial States | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_433 |
| 318 | 2346 | Light Conditions | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_light_19 |
| 319 | 1115 | Language Instructions | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_language_15_view_0_0_100_0_0_initstate_0 |
| 320 | 2280 | Light Conditions | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_light_48 |
| 321 | 2405 | Light Conditions | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_light_21 |
| 322 | 1424 | Language Instructions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_language_19_view_0_0_100_0_0_initstate_0 |
| 323 | 945 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_303_15_100_0_0_initstate_0 |
| 324 | 721 | Camera Viewpoints | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_24_15_100_0_0_initstate_0 |
| 325 | 1682 | Sensor Noise | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_0_noise_24 |
| 326 | 248 | Background Textures | 3 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_table_23 |
| 327 | 487 | Robot Initial States | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_465 |
| 328 | 544 | Robot Initial States | 3 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_257 |
| 329 | 659 | Robot Initial States | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_270 |
| 330 | 2023 | Objects Layout | 1 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_add_15 |
| 331 | 1558 | Sensor Noise | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_0_noise_44 |
| 332 | 2106 | Objects Layout | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_add_26 |
| 333 | 2189 | Objects Layout | 3 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_level3_sample4 |
| 334 | 1748 | Sensor Noise | 4 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_0_noise_43 |
| 335 | 1098 | Camera Viewpoints | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_357_15_100_0_0_initstate_0 |
| 336 | 2287 | Light Conditions | 2 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_light_1 |
| 337 | 2482 | Light Conditions | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_light_34 |
| 338 | 2202 | Objects Layout | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_add_14 |
| 339 | 170 | Background Textures | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_table_5 |
| 340 | 310 | Robot Initial States | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_291 |
| 341 | 1871 | Sensor Noise | 4 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_0_noise_37 |
| 342 | 573 | Robot Initial States | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_148 |
| 343 | 2497 | Light Conditions | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_light_1 |
| 344 | 360 | Robot Initial States | 5 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_452 |
| 345 | 1333 | Language Instructions | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_language_11_view_0_0_100_0_0_initstate_0 |
| 346 | 1236 | Language Instructions | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_language_30_view_0_0_100_0_0_initstate_0 |
| 347 | 2090 | Objects Layout | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_level5_sample2 |
| 348 | 30 | Background Textures | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_tb_7 |
| 349 | 2152 | Objects Layout | 1 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_level3_sample3 |
| 350 | 173 | Background Textures | 3 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_table_9 |
| 351 | 600 | Robot Initial States | 5 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_438 |
| 352 | 948 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_305_0_100_0_0_initstate_0 |
| 353 | 560 | Robot Initial States | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_437 |
| 354 | 1553 | Sensor Noise | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_0_noise_37 |
| 355 | 1362 | Language Instructions | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_language_41_view_0_0_100_0_0_initstate_0 |
| 356 | 1162 | Language Instructions | 5 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_language_41_view_0_0_100_0_0_initstate_0 |
| 357 | 781 | Camera Viewpoints | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_131_0_0_initstate_0 |
| 358 | 1249 | Language Instructions | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_language_45_view_0_0_100_0_0_initstate_0 |
| 359 | 1430 | Language Instructions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_language_31_view_0_0_100_0_0_initstate_0 |
| 360 | 1280 | Language Instructions | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_language_32_view_0_0_100_0_0_initstate_0 |
| 361 | 1952 | Objects Layout | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_level4_sample2 |
| 362 | 1582 | Sensor Noise | 5 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_0_noise_20 |
| 363 | 55 | Background Textures | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_table_6 |
| 364 | 1971 | Objects Layout | 1 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_add_9 |
| 365 | 285 | Background Textures | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_tb_1 |
| 366 | 1044 | Camera Viewpoints | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_335_15_100_0_0_initstate_0 |
| 367 | 692 | Camera Viewpoints | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_6_15_100_0_0_initstate_0 |
| 368 | 1801 | Sensor Noise | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_5 |
| 369 | 2074 | Objects Layout | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_add_27 |
| 370 | 885 | Camera Viewpoints | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_160_0_0_initstate_0 |
| 371 | 267 | Background Textures | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_tb_21 |
| 372 | 116 | Background Textures | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_table_22 |
| 373 | 2491 | Light Conditions | 3 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_light_44 |
| 374 | 343 | Robot Initial States | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_262 |
| 375 | 319 | Robot Initial States | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_381 |
| 376 | 1320 | Language Instructions | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_language_36_view_0_0_100_0_0_initstate_0 |
| 377 | 444 | Robot Initial States | 2 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_404 |
| 378 | 2149 | Objects Layout | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_level2_sample2 |
| 379 | 391 | Robot Initial States | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_303 |
| 380 | 2243 | Objects Layout | 4 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_level5_sample3 |
| 381 | 1080 | Camera Viewpoints | 2 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_358_358_initstate_0 |
| 382 | 153 | Background Textures | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_tb_19 |
| 383 | 2454 | Light Conditions | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_light_35 |
| 384 | 2053 | Objects Layout | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_level4_sample1 |
| 385 | 2021 | Objects Layout | 1 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_add_12 |
| 386 | 1173 | Language Instructions | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_language_8_view_0_0_100_0_0_initstate_0 |
| 387 | 1997 | Objects Layout | 1 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_add_3 |
| 388 | 2097 | Objects Layout | 3 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_add_16 |
| 389 | 2292 | Light Conditions | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_light_14 |
| 390 | 1705 | Sensor Noise | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_0_noise_47 |
| 391 | 831 | Camera Viewpoints | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_144_0_0_initstate_0 |
| 392 | 1385 | Language Instructions | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_17_view_0_0_100_0_0_initstate_0 |
| 393 | 2509 | Light Conditions | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_light_28 |
| 394 | 2406 | Light Conditions | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_light_24 |
| 395 | 1922 | Sensor Noise | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_0_noise_39 |
| 396 | 506 | Robot Initial States | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_296 |
| 397 | 2418 | Light Conditions | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_light_15 |
| 398 | 1787 | Sensor Noise | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_0_noise_39 |
| 399 | 236 | Background Textures | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_tb_9 |
| 400 | 716 | Camera Viewpoints | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_21_0_100_0_0_initstate_0 |
| 401 | 1618 | Sensor Noise | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_0_noise_6 |
| 402 | 1502 | Sensor Noise | 1 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_0_noise_21 |
| 403 | 970 | Camera Viewpoints | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_173_0_0_initstate_0 |
| 404 | 2380 | Light Conditions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_light_20 |
| 405 | 612 | Robot Initial States | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_219 |
| 406 | 89 | Background Textures | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_table_27 |
| 407 | 1865 | Sensor Noise | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_0_noise_31 |
| 408 | 673 | Robot Initial States | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_420 |
| 409 | 479 | Robot Initial States | 4 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_365 |
| 410 | 140 | Background Textures | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_table_24 |
| 411 | 1736 | Sensor Noise | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_0_noise_30 |
| 412 | 2254 | Light Conditions | 5 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_light_18 |
| 413 | 1472 | Language Instructions | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_language_35_view_0_0_100_0_0_initstate_0 |
| 414 | 2361 | Light Conditions | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_light_4 |
| 415 | 756 | Camera Viewpoints | 5 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_32_15_100_0_0_initstate_0 |
| 416 | 2169 | Objects Layout | 1 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_add_20 |
| 417 | 1132 | Language Instructions | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_language_36_view_0_0_100_0_0_initstate_0 |
| 418 | 24 | Background Textures | 5 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_tb_2 |
| 419 | 2012 | Objects Layout | 3 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_level3_sample3 |
| 420 | 1147 | Language Instructions | 5 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_language_3_view_0_0_100_0_0_initstate_0 |
| 421 | 1397 | Language Instructions | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_31_view_0_0_100_0_0_initstate_0 |
| 422 | 639 | Robot Initial States | 4 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_499 |
| 423 | 2376 | Light Conditions | 4 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_light_15 |
| 424 | 2209 | Objects Layout | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_add_20 |
| 425 | 2453 | Light Conditions | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_light_33 |
| 426 | 1544 | Sensor Noise | 4 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_0_noise_19 |
| 427 | 261 | Background Textures | 3 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_tb_15 |
| 428 | 1976 | Objects Layout | 1 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_level4_sample1 |
| 429 | 1700 | Sensor Noise | 1 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_0_noise_42 |
| 430 | 316 | Robot Initial States | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_351 |
| 431 | 667 | Robot Initial States | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_360 |
| 432 | 1059 | Camera Viewpoints | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_344_0_100_0_0_initstate_0 |
| 433 | 1319 | Language Instructions | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_language_35_view_0_0_100_0_0_initstate_0 |
| 434 | 2271 | Light Conditions | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_light_36 |
| 435 | 1524 | Sensor Noise | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_0_noise_44 |
| 436 | 142 | Background Textures | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_table_3 |
| 437 | 1936 | Objects Layout | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_add_20 |
| 438 | 2032 | Objects Layout | 1 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_add_29 |
| 439 | 2425 | Light Conditions | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_light_38 |
| 440 | 1842 | Sensor Noise | 4 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_0_noise_5 |
| 441 | 562 | Robot Initial States | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_457 |
| 442 | 492 | Robot Initial States | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_116 |
| 443 | 771 | Camera Viewpoints | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_40_0_100_0_0_initstate_0 |
| 444 | 1414 | Language Instructions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_language_5_view_0_0_100_0_0_initstate_0 |
| 445 | 45 | Background Textures | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_table_22 |
| 446 | 603 | Robot Initial States | 4 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_468 |
| 447 | 806 | Camera Viewpoints | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_49_0_100_0_0_initstate_0 |
| 448 | 477 | Robot Initial States | 4 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_345 |
| 449 | 196 | Background Textures | 1 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_table_13 |
| 450 | 1270 | Language Instructions | 1 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_language_19_view_0_0_100_0_0_initstate_0 |
| 451 | 971 | Camera Viewpoints | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_174_0_0_initstate_0 |
| 452 | 832 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_145_0_0_initstate_0 |
| 453 | 1203 | Language Instructions | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_language_44_view_0_0_100_0_0_initstate_0 |
| 454 | 2104 | Objects Layout | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_add_24 |
| 455 | 10 | Background Textures | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_table_2 |
| 456 | 279 | Background Textures | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_table_2 |
| 457 | 1585 | Sensor Noise | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_0_noise_23 |
| 458 | 2484 | Light Conditions | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_light_36 |
| 459 | 354 | Robot Initial States | 4 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_382 |
| 460 | 440 | Robot Initial States | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_364 |
| 461 | 2159 | Objects Layout | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_level5_sample2 |
| 462 | 2177 | Objects Layout | 1 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_add_5 |
| 463 | 1211 | Language Instructions | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_language_4_view_0_0_100_0_0_initstate_0 |
| 464 | 1635 | Sensor Noise | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_0_noise_24 |
| 465 | 157 | Background Textures | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_tb_3 |
| 466 | 1763 | Sensor Noise | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_0_noise_9 |
| 467 | 965 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_313_15_100_0_0_initstate_0 |
| 468 | 402 | Robot Initial States | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_413 |
| 469 | 1354 | Language Instructions | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_language_32_view_0_0_100_0_0_initstate_0 |
| 470 | 2512 | Light Conditions | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_light_31 |
| 471 | 724 | Camera Viewpoints | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_26_0_100_0_0_initstate_0 |
| 472 | 2338 | Light Conditions | 3 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_light_11 |
| 473 | 127 | Background Textures | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_tb_14 |
| 474 | 1081 | Camera Viewpoints | 1 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_345_0_100_0_0_initstate_0 |
| 475 | 2311 | Light Conditions | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_light_32 |
| 476 | 185 | Background Textures | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_tb_20 |
| 477 | 2409 | Light Conditions | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_light_40 |
| 478 | 1141 | Language Instructions | 1 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_language_46_view_0_0_100_0_0_initstate_0 |
| 479 | 1744 | Sensor Noise | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_0_noise_39 |
| 480 | 2047 | Objects Layout | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_add_27 |
| 481 | 1812 | Sensor Noise | 4 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_18 |
| 482 | 686 | Camera Viewpoints | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_2_352_initstate_0 |
| 483 | 97 | Background Textures | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_table_9 |
| 484 | 2083 | Objects Layout | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_level3_sample2 |
| 485 | 897 | Camera Viewpoints | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_286_0_100_0_0_initstate_0 |
| 486 | 1478 | Language Instructions | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_language_42_view_0_0_100_0_0_initstate_0 |
| 487 | 1917 | Sensor Noise | 2 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_0_noise_34 |
| 488 | 269 | Background Textures | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_tb_3 |
| 489 | 1838 | Sensor Noise | 4 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_0_noise_1 |
| 490 | 872 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_74_0_100_0_0_initstate_0 |
| 491 | 1996 | Objects Layout | 1 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_add_28 |
| 492 | 1067 | Camera Viewpoints | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_197_0_0_initstate_0 |
| 493 | 1782 | Sensor Noise | 2 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_0_noise_33 |
| 494 | 2331 | Light Conditions | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_light_50 |
| 495 | 698 | Camera Viewpoints | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_12_15_100_0_0_initstate_0 |
| 496 | 90 | Background Textures | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_table_28 |
| 497 | 393 | Robot Initial States | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_323 |
| 498 | 493 | Robot Initial States | 1 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_126 |
| 499 | 649 | Robot Initial States | 2 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_130 |
| 500 | 2051 | Objects Layout | 5 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_level3_sample1 |
| 501 | 2233 | Objects Layout | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_level3_sample1 |
| 502 | 145 | Background Textures | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_table_1 |
| 503 | 1613 | Sensor Noise | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_0_noise_1 |
| 504 | 304 | Robot Initial States | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_231 |
| 505 | 1970 | Objects Layout | 1 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_add_30 |
| 506 | 824 | Camera Viewpoints | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_58_15_100_0_0_initstate_0 |
| 507 | 627 | Robot Initial States | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_379 |
| 508 | 2336 | Light Conditions | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_light_1 |
| 509 | 883 | Camera Viewpoints | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_158_0_0_initstate_0 |
| 510 | 991 | Camera Viewpoints | 4 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_316_15_100_0_0_initstate_0 |
| 511 | 538 | Robot Initial States | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_167 |
| 512 | 166 | Background Textures | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_table_26 |
| 513 | 1287 | Language Instructions | 1 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_language_39_view_0_0_100_0_0_initstate_0 |
| 514 | 1800 | Sensor Noise | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_4 |
| 515 | 1192 | Language Instructions | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_language_32_view_0_0_100_0_0_initstate_0 |
| 516 | 1732 | Sensor Noise | 1 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_0_noise_26 |
| 517 | 107 | Background Textures | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_table_10 |
| 518 | 2451 | Light Conditions | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_light_29 |
| 519 | 2248 | Light Conditions | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_light_12 |
| 520 | 233 | Background Textures | 4 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_tb_5 |
| 521 | 25 | Background Textures | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_tb_20 |
| 522 | 1671 | Sensor Noise | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_0_noise_12 |
| 523 | 1247 | Language Instructions | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_language_43_view_0_0_100_0_0_initstate_0 |
| 524 | 2068 | Objects Layout | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_add_20 |
| 525 | 1567 | Sensor Noise | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_0_noise_3 |
| 526 | 1298 | Language Instructions | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_language_5_view_0_0_100_0_0_initstate_0 |
| 527 | 1149 | Language Instructions | 5 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_language_6_view_0_0_100_0_0_initstate_0 |
| 528 | 1940 | Objects Layout | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_add_25 |
| 529 | 708 | Camera Viewpoints | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_4_354_initstate_0 |
| 530 | 1399 | Language Instructions | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_35_view_0_0_100_0_0_initstate_0 |
| 531 | 1545 | Sensor Noise | 4 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_0_noise_20 |
| 532 | 2431 | Light Conditions | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_light_6 |
| 533 | 2131 | Objects Layout | 1 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_add_15 |
| 534 | 2037 | Objects Layout | 2 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_level3_sample2 |
| 535 | 2408 | Light Conditions | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_light_39 |
| 536 | 2393 | Light Conditions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_light_40 |
| 537 | 1471 | Language Instructions | 3 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_language_34_view_0_0_100_0_0_initstate_0 |
| 538 | 1105 | Language Instructions | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_language_5_view_0_0_100_0_0_initstate_0 |
| 539 | 2469 | Light Conditions | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_light_14 |
| 540 | 138 | Background Textures | 4 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_table_12 |
| 541 | 2119 | Objects Layout | 3 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_level3_sample1 |
| 542 | 567 | Robot Initial States | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_8 |
| 543 | 949 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_305_15_100_0_0_initstate_0 |
| 544 | 1507 | Sensor Noise | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_0_noise_27 |
| 545 | 451 | Robot Initial States | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_484 |
| 546 | 1435 | Language Instructions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_language_40_view_0_0_100_0_0_initstate_0 |
| 547 | 2502 | Light Conditions | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_light_19 |
| 548 | 1336 | Language Instructions | 2 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_language_14_view_0_0_100_0_0_initstate_0 |
| 549 | 1911 | Sensor Noise | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_0_noise_28 |
| 550 | 1053 | Camera Viewpoints | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_340_15_100_0_0_initstate_0 |
| 551 | 761 | Camera Viewpoints | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_35_0_100_0_0_initstate_0 |
| 552 | 41 | Background Textures | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_table_18 |
| 553 | 2166 | Objects Layout | 1 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_add_16 |
| 554 | 362 | Robot Initial States | 3 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_472 |
| 555 | 464 | Robot Initial States | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_195 |
| 556 | 281 | Background Textures | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_table_27 |
| 557 | 1778 | Sensor Noise | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_0_noise_29 |
| 558 | 1446 | Language Instructions | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_language_5_view_0_0_100_0_0_initstate_0 |
| 559 | 933 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_352_8_initstate_0 |
| 560 | 187 | Background Textures | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_tb_22 |
| 561 | 1033 | Camera Viewpoints | 4 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_356_354_initstate_0 |
| 562 | 2098 | Objects Layout | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_add_17 |
| 563 | 789 | Camera Viewpoints | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_139_0_0_initstate_0 |
| 564 | 2396 | Light Conditions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_light_46 |
| 565 | 1276 | Language Instructions | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_language_26_view_0_0_100_0_0_initstate_0 |
| 566 | 215 | Background Textures | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_table_8 |
| 567 | 1300 | Language Instructions | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_language_8_view_0_0_100_0_0_initstate_0 |
| 568 | 1654 | Sensor Noise | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_0_noise_44 |
| 569 | 1965 | Objects Layout | 1 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_add_21 |
| 570 | 1525 | Sensor Noise | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_0_noise_45 |
| 571 | 2158 | Objects Layout | 1 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_level5_sample1 |
| 572 | 462 | Robot Initial States | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_175 |
| 573 | 1102 | Language Instructions | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_language_2_view_0_0_100_0_0_initstate_0 |
| 574 | 422 | Robot Initial States | 2 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_174 |
| 575 | 289 | Robot Initial States | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_1 |
| 576 | 2438 | Light Conditions | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_light_16 |
| 577 | 2256 | Light Conditions | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_light_2 |
| 578 | 1201 | Language Instructions | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_language_42_view_0_0_100_0_0_initstate_0 |
| 579 | 608 | Robot Initial States | 3 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_149 |
| 580 | 100 | Background Textures | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_tb_16 |
| 581 | 1530 | Sensor Noise | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_0_noise_1 |
| 582 | 1742 | Sensor Noise | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_0_noise_37 |
| 583 | 596 | Robot Initial States | 4 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_398 |
| 584 | 337 | Robot Initial States | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_172 |
| 585 | 146 | Background Textures | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_table_10 |
| 586 | 1086 | Camera Viewpoints | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_348_15_100_0_0_initstate_0 |
| 587 | 886 | Camera Viewpoints | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_350_4_initstate_0 |
| 588 | 2420 | Light Conditions | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_light_21 |
| 589 | 1817 | Sensor Noise | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_25 |
| 590 | 2027 | Objects Layout | 2 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_add_23 |
| 591 | 1855 | Sensor Noise | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_0_noise_19 |
| 592 | 2472 | Light Conditions | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_light_18 |
| 593 | 548 | Robot Initial States | 1 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_317 |
| 594 | 2345 | Light Conditions | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_light_18 |
| 595 | 864 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_70_0_100_0_0_initstate_0 |
| 596 | 379 | Robot Initial States | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_183 |
| 597 | 684 | Camera Viewpoints | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_2_10_initstate_0 |
| 598 | 2054 | Objects Layout | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_level4_sample2 |
| 599 | 1950 | Objects Layout | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_level3_sample2 |
| 600 | 1421 | Language Instructions | 3 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_language_16_view_0_0_100_0_0_initstate_0 |
| 601 | 110 | Background Textures | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_table_15 |
| 602 | 2404 | Light Conditions | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_light_2 |
| 603 | 1163 | Language Instructions | 5 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_language_43_view_0_0_100_0_0_initstate_0 |
| 604 | 1686 | Sensor Noise | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_0_noise_28 |
| 605 | 985 | Camera Viewpoints | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_354_354_initstate_0 |
| 606 | 1600 | Sensor Noise | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_0_noise_38 |
| 607 | 1335 | Language Instructions | 2 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_language_13_view_0_0_100_0_0_initstate_0 |
| 608 | 739 | Camera Viewpoints | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_126_0_0_initstate_0 |
| 609 | 2005 | Objects Layout | 1 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_level1_sample3 |
| 610 | 2228 | Objects Layout | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_level1_sample3 |
| 611 | 664 | Robot Initial States | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_330 |
| 612 | 1375 | Language Instructions | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_5_view_0_0_100_0_0_initstate_0 |
| 613 | 27 | Background Textures | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_tb_22 |
| 614 | 2295 | Light Conditions | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_light_17 |
| 615 | 1234 | Language Instructions | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_language_28_view_0_0_100_0_0_initstate_0 |
| 616 | 1902 | Sensor Noise | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_0_noise_19 |
| 617 | 42 | Background Textures | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_table_19 |
| 618 | 283 | Background Textures | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_table_3 |
| 619 | 2163 | Objects Layout | 1 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_add_13 |
| 620 | 730 | Camera Viewpoints | 3 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_29_0_100_0_0_initstate_0 |
| 621 | 2077 | Objects Layout | 1 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_add_30 |
| 622 | 522 | Robot Initial States | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_466 |
| 623 | 2508 | Light Conditions | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_light_25 |
| 624 | 250 | Background Textures | 1 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_table_25 |
| 625 | 286 | Background Textures | 1 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_tb_12 |
| 626 | 359 | Robot Initial States | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_442 |
| 627 | 960 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_311_0_100_0_0_initstate_0 |
| 628 | 652 | Robot Initial States | 2 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_170 |
| 629 | 1876 | Sensor Noise | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_0_noise_42 |
| 630 | 306 | Robot Initial States | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_251 |
| 631 | 1155 | Language Instructions | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_language_26_view_0_0_100_0_0_initstate_0 |
| 632 | 1811 | Sensor Noise | 4 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_16 |
| 633 | 1124 | Language Instructions | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_language_26_view_0_0_100_0_0_initstate_0 |
| 634 | 1213 | Language Instructions | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_language_6_view_0_0_100_0_0_initstate_0 |
| 635 | 2002 | Objects Layout | 1 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_add_9 |
| 636 | 180 | Background Textures | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_tb_15 |
| 637 | 691 | Camera Viewpoints | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_5_15_100_0_0_initstate_0 |
| 638 | 2341 | Light Conditions | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_light_14 |
| 639 | 1271 | Language Instructions | 4 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_language_20_view_0_0_100_0_0_initstate_0 |
| 640 | 119 | Background Textures | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_table_27 |
| 641 | 2117 | Objects Layout | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_level2_sample3 |
| 642 | 711 | Camera Viewpoints | 3 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_17_15_100_0_0_initstate_0 |
| 643 | 2449 | Light Conditions | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_light_27 |
| 644 | 1182 | Language Instructions | 5 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_language_20_view_0_0_100_0_0_initstate_0 |
| 645 | 2168 | Objects Layout | 1 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_add_19 |
| 646 | 19 | Background Textures | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_table_8 |
| 647 | 1021 | Camera Viewpoints | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_184_0_0_initstate_0 |
| 648 | 2377 | Light Conditions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_light_16 |
| 649 | 1521 | Sensor Noise | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_0_noise_41 |
| 650 | 2293 | Light Conditions | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_light_15 |
| 651 | 528 | Robot Initial States | 1 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_47 |
| 652 | 1473 | Language Instructions | 3 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_language_37_view_0_0_100_0_0_initstate_0 |
| 653 | 1326 | Language Instructions | 3 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_language_2_view_0_0_100_0_0_initstate_0 |
| 654 | 2285 | Light Conditions | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_light_8 |
| 655 | 1012 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_327_0_100_0_0_initstate_0 |
| 656 | 1953 | Objects Layout | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_level4_sample3 |
| 657 | 2410 | Light Conditions | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_light_44 |
| 658 | 98 | Background Textures | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_tb_11 |
| 659 | 274 | Background Textures | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_tb_8 |
| 660 | 902 | Camera Viewpoints | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_288_15_100_0_0_initstate_0 |
| 661 | 2208 | Objects Layout | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_add_2 |
| 662 | 72 | Background Textures | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_tb_4 |
| 663 | 2049 | Objects Layout | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_add_30 |
| 664 | 2043 | Objects Layout | 2 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_level5_sample1 |
| 665 | 198 | Background Textures | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_table_15 |
| 666 | 478 | Robot Initial States | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_355 |
| 667 | 412 | Robot Initial States | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_44 |
| 668 | 610 | Robot Initial States | 2 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_169 |
| 669 | 495 | Robot Initial States | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_156 |
| 670 | 1756 | Sensor Noise | 2 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_0_noise_2 |
| 671 | 1541 | Sensor Noise | 3 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_0_noise_16 |
| 672 | 1062 | Camera Viewpoints | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_192_0_0_initstate_0 |
| 673 | 2432 | Light Conditions | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_light_8 |
| 674 | 2139 | Objects Layout | 1 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_add_24 |
| 675 | 2483 | Light Conditions | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_light_35 |
| 676 | 1905 | Sensor Noise | 2 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_0_noise_22 |
| 677 | 1716 | Sensor Noise | 4 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_0_noise_8 |
| 678 | 1677 | Sensor Noise | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_0_noise_19 |
| 679 | 1604 | Sensor Noise | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_0_noise_42 |
| 680 | 1641 | Sensor Noise | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_0_noise_30 |
| 681 | 843 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_10_350_initstate_0 |
| 682 | 2085 | Objects Layout | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_level3_sample4 |
| 683 | 155 | Background Textures | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_tb_20 |
| 684 | 582 | Robot Initial States | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_248 |
| 685 | 809 | Camera Viewpoints | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_50_15_100_0_0_initstate_0 |
| 686 | 1416 | Language Instructions | 4 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_language_7_view_0_0_100_0_0_initstate_0 |
| 687 | 1407 | Language Instructions | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_45_view_0_0_100_0_0_initstate_0 |
| 688 | 1304 | Language Instructions | 4 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_language_14_view_0_0_100_0_0_initstate_0 |
| 689 | 2516 | Light Conditions | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_light_41 |
| 690 | 744 | Camera Viewpoints | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_6_2_initstate_0 |
| 691 | 1963 | Objects Layout | 2 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_add_17 |
| 692 | 367 | Robot Initial States | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_23 |
| 693 | 1615 | Sensor Noise | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_0_noise_3 |
| 694 | 1930 | Sensor Noise | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_0_noise_48 |
| 695 | 964 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_313_0_100_0_0_initstate_0 |
| 696 | 126 | Background Textures | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_tb_12 |
| 697 | 79 | Background Textures | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_table_14 |
| 698 | 2101 | Objects Layout | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_add_21 |
| 699 | 1526 | Sensor Noise | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_0_noise_47 |
| 700 | 1707 | Sensor Noise | 4 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_0_noise_49 |
| 701 | 1938 | Objects Layout | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_add_22 |
| 702 | 1593 | Sensor Noise | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_0_noise_31 |
| 703 | 1784 | Sensor Noise | 1 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_0_noise_35 |
| 704 | 254 | Background Textures | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_table_6 |
| 705 | 634 | Robot Initial States | 4 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_449 |
| 706 | 812 | Camera Viewpoints | 5 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_52_15_100_0_0_initstate_0 |
| 707 | 1381 | Language Instructions | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_13_view_0_0_100_0_0_initstate_0 |
| 708 | 1273 | Language Instructions | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_language_22_view_0_0_100_0_0_initstate_0 |
| 709 | 2198 | Objects Layout | 1 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_add_10 |
| 710 | 2187 | Objects Layout | 2 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_level3_sample2 |
| 711 | 463 | Robot Initial States | 4 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_185 |
| 712 | 521 | Robot Initial States | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_456 |
| 713 | 1179 | Language Instructions | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_language_16_view_0_0_100_0_0_initstate_0 |
| 714 | 2058 | Objects Layout | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_level5_sample4 |
| 715 | 2318 | Light Conditions | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_light_39 |
| 716 | 2407 | Light Conditions | 5 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_light_38 |
| 717 | 857 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_65_15_100_0_0_initstate_0 |
| 718 | 2422 | Light Conditions | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_light_25 |
| 719 | 1422 | Language Instructions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_language_17_view_0_0_100_0_0_initstate_0 |
| 720 | 920 | Camera Viewpoints | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_298_15_100_0_0_initstate_0 |
| 721 | 2064 | Objects Layout | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_add_16 |
| 722 | 2258 | Light Conditions | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_light_21 |
| 723 | 1862 | Sensor Noise | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_0_noise_28 |
| 724 | 775 | Camera Viewpoints | 5 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_42_0_100_0_0_initstate_0 |
| 725 | 579 | Robot Initial States | 4 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_218 |
| 726 | 1469 | Language Instructions | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_language_31_view_0_0_100_0_0_initstate_0 |
| 727 | 372 | Robot Initial States | 2 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_view_0_0_100_0_0_initstate_103 |
| 728 | 1301 | Language Instructions | 1 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_language_9_view_0_0_100_0_0_initstate_0 |
| 729 | 1229 | Language Instructions | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_language_23_view_0_0_100_0_0_initstate_0 |
| 730 | 352 | Robot Initial States | 3 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_362 |
| 731 | 2350 | Light Conditions | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_light_25 |
| 732 | 1367 | Language Instructions | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_language_46_view_0_0_100_0_0_initstate_0 |
| 733 | 2507 | Light Conditions | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_light_24 |
| 734 | 411 | Robot Initial States | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_24 |
| 735 | 709 | Camera Viewpoints | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_16_15_100_0_0_initstate_0 |
| 736 | 1151 | Language Instructions | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_language_10_view_0_0_100_0_0_initstate_0 |
| 737 | 990 | Camera Viewpoints | 4 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_316_0_100_0_0_initstate_0 |
| 738 | 697 | Camera Viewpoints | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_11_15_100_0_0_initstate_0 |
| 739 | 1829 | Sensor Noise | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_41 |
| 740 | 231 | Background Textures | 2 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_tb_3 |
| 741 | 546 | Robot Initial States | 2 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_0_0_initstate_287 |
| 742 | 1534 | Sensor Noise | 3 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_view_0_0_100_0_0_initstate_0_noise_7 |
| 743 | 2019 | Objects Layout | 3 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_level5_sample3 |
| 744 | 1120 | Language Instructions | 1 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_language_22_view_0_0_100_0_0_initstate_0 |
| 745 | 151 | Background Textures | 3 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_table_9 |
| 746 | 190 | Background Textures | 2 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_tb_6 |
| 747 | 327 | Robot Initial States | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_view_0_0_100_0_0_initstate_471 |
| 748 | 2480 | Light Conditions | 4 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_light_32 |
| 749 | 660 | Robot Initial States | 2 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_0_0_100_0_0_initstate_290 |
| 750 | 60 | Background Textures | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_tb_13 |
| 751 | 2136 | Objects Layout | 1 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_add_21 |
| 752 | 1084 | Camera Viewpoints | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_view_347_15_100_0_0_initstate_0 |
| 753 | 1049 | Camera Viewpoints | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_338_15_100_0_0_initstate_0 |
| 754 | 287 | Background Textures | 5 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_tb_17 |
| 755 | 1719 | Sensor Noise | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_view_0_0_100_0_0_initstate_0_noise_12 |
| 756 | 2392 | Light Conditions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_light_4 |
| 757 | 1959 | Objects Layout | 1 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_add_10 |
| 758 | 22 | Background Textures | 3 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_tb_12 |
| 759 | 2439 | Light Conditions | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_light_17 |
| 760 | 2039 | Objects Layout | 3 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_level4_sample1 |
| 761 | 2253 | Light Conditions | 5 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_light_17 |
| 762 | 1391 | Language Instructions | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_24_view_0_0_100_0_0_initstate_0 |
| 763 | 186 | Background Textures | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_tb_21 |
| 764 | 1252 | Language Instructions | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_language_48_view_0_0_100_0_0_initstate_0 |
| 765 | 2200 | Objects Layout | 3 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_add_12 |
| 766 | 277 | Background Textures | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_table_14 |
| 767 | 82 | Background Textures | 4 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_table_19 |
| 768 | 1819 | Sensor Noise | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_27 |
| 769 | 2421 | Light Conditions | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_light_22 |
| 770 | 2108 | Objects Layout | 1 | LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket_add_29 |
| 771 | 932 | Camera Viewpoints | 3 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_view_0_0_100_352_6_initstate_0 |
| 772 | 2514 | Light Conditions | 2 | STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy_light_38 |
| 773 | 578 | Robot Initial States | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_208 |
| 774 | 5 | Background Textures | 4 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_table_15 |
| 775 | 2441 | Light Conditions | 3 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_light_19 |
| 776 | 614 | Robot Initial States | 3 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_view_0_0_100_0_0_initstate_239 |
| 777 | 2395 | Light Conditions | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_light_42 |
| 778 | 2402 | Light Conditions | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_light_10 |
| 779 | 2347 | Light Conditions | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_light_2 |
| 780 | 128 | Background Textures | 5 | KITCHEN_SCENE8_put_both_moka_pots_on_the_stove_tb_15 |
| 781 | 1696 | Sensor Noise | 4 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_0_noise_38 |
| 782 | 426 | Robot Initial States | 4 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_view_0_0_100_0_0_initstate_224 |
| 783 | 489 | Robot Initial States | 5 | LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate_view_0_0_100_0_0_initstate_485 |
| 784 | 1934 | Objects Layout | 1 | KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it_add_16 |
| 785 | 999 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_320_15_100_0_0_initstate_0 |
| 786 | 2477 | Light Conditions | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_light_23 |
| 787 | 2046 | Objects Layout | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_add_18 |
| 788 | 152 | Background Textures | 2 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_tb_1 |
| 789 | 2332 | Light Conditions | 3 | KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it_light_6 |
| 790 | 265 | Background Textures | 5 | LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate_tb_2 |
| 791 | 2359 | Light Conditions | 5 | KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it_light_38 |
| 792 | 1383 | Language Instructions | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_15_view_0_0_100_0_0_initstate_0 |
| 793 | 2055 | Objects Layout | 2 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_level4_sample4 |
| 794 | 968 | Camera Viewpoints | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_171_0_0_initstate_0 |
| 795 | 2414 | Light Conditions | 4 | LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket_light_8 |
| 796 | 1806 | Sensor Noise | 1 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_11 |
| 797 | 1411 | Language Instructions | 5 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_language_50_view_0_0_100_0_0_initstate_0 |
| 798 | 973 | Camera Viewpoints | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_176_0_0_initstate_0 |
| 799 | 1835 | Sensor Noise | 3 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_0_0_100_0_0_initstate_0_noise_48 |
| 800 | 1015 | Camera Viewpoints | 5 | LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket_view_328_15_100_0_0_initstate_0 |
