# Long200 native-camera restart

The original run `evaluate_results/fastwam_noguidance_long200_fullvideo_20261015`
was stopped with user authorization after an unintended explicit camera pose and
45-degree fovy override was discovered. At the diagnostic snapshot, 56 episodes
had zero successes; 16 overlapped the historical Long800 control, of which 11
had historically succeeded. All old media/results/logs remain intact and are invalid
for the intended native-camera baseline. Exact stopping PIDs: 1875256 launcher,
1911544 manager, 1911583 worker; only these validated task processes received SIGTERM.

Corrected output:
`/data/pxchen/PACT-WAM/evaluate_results/fastwam_noguidance_long200_fullvideo_camera_fixed_20261015`

- Same exact 200-task manifest/hash, seed7, 1 trial; no selection by new outcomes.
- Same original optional-IDM FastWAM BF16 checkpoint, normalization, 10 denoise,
  shifts1/1, replan8, wait30; max700 controls explicitly; no guidance/JEPA/trigger.
- Camera position/quaternion/fovy explicitly null; original per-task cameras kept.
  Camera RGB rotation remains180 degrees, unchanged from historical native input.
- Same full9 prediction frames per replan (0/4/.../32), actual video every2 controls.
- Hard guard in recorder refuses non-null camera overrides.
- Full historical-success smoke: task593 seed7, max700; require actual success and
  9-frame prediction video before formal200 starts.
- Prefer two fully idle GPUs (stable60s); GPU6 dead CUDA context may be used only
  if no live compute process and usage<5500MiB. Never stop other users' processes.
- After smoke, allow up to120s for a stable dual-card opportunity; otherwise begin
  single-card rather than wait indefinitely. No automatic later worker expansion.
- Unique nohup launcher `scripts/launch_fullvideo200_camera_fixed.py`.

At17:39 GPU1–3 were occupied (~15GiB each), GPUs0/4/5/7 full. Only GPU6 available
after our task stopped (~19.1GiB free). Dual-card start is not yet confirmed.

## Verified restart

- Unique nohup launcher PID3802029.
- Smoke task593 passed at17:49:46: success, 29 replans / 261 full prediction frames;
  230 executed controls (including wait:260 loop steps). Rollout about47s,
  full prediction encoding about17.9s. All camera overrides null verified.
- Formal200 began17:51:48 on GPU6. No second sufficiently idle card; GPU1–3
  Qwen belongs to another user and GPU4/5/7 VLLM belongs to another user. None stopped.
- At17:58, first3 episodes (1162,1013,181) all succeeded, duration81.5/80.4/77.0s;
  3 complete prediction indexes, no failed worker tasks; fourth task2026 running.
- Operationally stable; no automatic later expansion is configured. Short initial
  successful cases are not a representative runtime sample. Provisional full200
  single-card estimate5–8h from17:51, roughly Oct15 23:00–Oct16 02:00 China time.
