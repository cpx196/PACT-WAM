# LIBERO-Plus short-horizon paired OOD evaluation

315 fixed tasks per group, 630 episodes total. Spatial/Object/Goal × seven OOD categories × 15 tasks.

Sampling seed: 239; rollout seed: 7; one trial per task, initial-state index 0. Both groups use the same task order.

Control: GPU 1, FastWAM IDM, no JEPA/no trigger. Experiment: GPUs 2+3, rot180-trained step-2000 JEPA predictor, inverted online JEPA inputs, full 4× raw-gradient guidance at flow steps 7/8/9.

FastWAM remains BF16 with its original 180° image convention. JEPA is FP32 and adds no extra rotation after extracting the primary view; current and generated future frames remain inverted. Native OOD camera poses are preserved. Max episode horizon is 400 control steps (+30 settling steps).

Complete settings and metadata are in task_manifest.json. Official difficulty labels are retained, not used as labels of our model performance.

Task-list SHA256: `db258768bf6ac412eb3afb53a90133a903ab6269b9bafcaa7232b8e257a4049b`

| Order | Suite | Task ID (0-based) | Classification ID (1-based) | OOD category | Official difficulty | Task name |
|---:|---|---:|---:|---|---:|---|
| 1 | libero_goal | 226 | 227 | Background Textures | 2 | put_the_wine_bottle_on_the_rack_tb_6 |
| 2 | libero_goal | 1410 | 1411 | Language Instructions | 1 | turn_on_the_stove_language_36_view_0_0_100_0_0_initstate_0 |
| 3 | libero_goal | 2448 | 2449 | Light Conditions | None | put_the_bowl_on_the_plate_light_24 |
| 4 | libero_object | 1541 | 1542 | Sensor Noise | 1 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_24 |
| 5 | libero_spatial | 877 | 878 | Camera Viewpoints | 3 | pick_up_the_black_bowl_on_the_stove_and_place_it_on_the_plate_view_0_0_177_0_0_initstate_0 |
| 6 | libero_goal | 1074 | 1075 | Camera Viewpoints | 1 | put_the_wine_bottle_on_the_rack_view_0_0_100_358_358_initstate_0 |
| 7 | libero_object | 1149 | 1150 | Language Instructions | 3 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_language_31_view_0_0_100_0_0_initstate_0 |
| 8 | libero_goal | 2476 | 2477 | Light Conditions | 2 | put_the_bowl_on_top_of_the_cabinet_light_39 |
| 9 | libero_spatial | 1756 | 1757 | Objects Layout | 3 | pick_up_the_black_bowl_between_the_plate_and_the_ramekin_and_place_it_on_the_plate_level2_sample4 |
| 10 | libero_spatial | 2281 | 2282 | Light Conditions | 2 | pick_up_the_black_bowl_next_to_the_ramekin_and_place_it_on_the_plate_light_10 |
| 11 | libero_object | 916 | 917 | Camera Viewpoints | 5 | pick_up_the_butter_and_place_it_in_the_basket_view_309_15_100_0_0_initstate_0 |
| 12 | libero_spatial | 2108 | 2109 | Objects Layout | 3 | pick_up_the_black_bowl_on_the_wooden_cabinet_and_place_it_on_the_plate_level5_sample3 |
| 13 | libero_spatial | 626 | 627 | Camera Viewpoints | 2 | pick_up_the_black_bowl_next_to_the_ramekin_and_place_it_on_the_plate_view_18_0_100_0_0_initstate_0 |
| 14 | libero_goal | 2282 | 2283 | Objects Layout | 1 | turn_on_the_stove_add_26 |
| 15 | libero_object | 1198 | 1199 | Language Instructions | 3 | pick_up_the_tomato_sauce_and_place_it_in_the_basket_language_1_view_0_0_100_0_0_initstate_0 |
| 16 | libero_object | 1882 | 1883 | Objects Layout | 2 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_add_9 |
| 17 | libero_goal | 433 | 434 | Robot Initial States | 4 | open_the_top_drawer_and_put_the_bowl_inside_view_0_0_100_0_0_initstate_354 |
| 18 | libero_spatial | 1155 | 1156 | Language Instructions | 4 | pick_up_the_black_bowl_in_the_top_drawer_of_the_wooden_cabinet_and_place_it_on_the_plate_language_33_view_0_0_100_0_0_initstate_0 |
| 19 | libero_object | 758 | 759 | Camera Viewpoints | 3 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_view_49_0_100_0_0_initstate_0 |
| 20 | libero_object | 2309 | 2310 | Light Conditions | 3 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_light_7 |
| 21 | libero_goal | 844 | 845 | Camera Viewpoints | 4 | put_the_bowl_on_top_of_the_cabinet_view_0_0_100_10_8_initstate_0 |
| 22 | libero_spatial | 1938 | 1939 | Objects Layout | 3 | pick_up_the_black_bowl_next_to_the_ramekin_and_place_it_on_the_plate_level3_sample3 |
| 23 | libero_goal | 1790 | 1791 | Sensor Noise | 1 | turn_on_the_stove_view_0_0_100_0_0_initstate_0_noise_13 |
| 24 | libero_object | 2008 | 2009 | Objects Layout | 5 | pick_up_the_cream_cheese_and_place_it_in_the_basket_level5_sample1 |
| 25 | libero_goal | 521 | 522 | Robot Initial States | 5 | push_the_plate_to_the_front_of_the_stove_view_0_0_100_0_0_initstate_416 |
| 26 | libero_object | 936 | 937 | Camera Viewpoints | 5 | pick_up_the_milk_and_place_it_in_the_basket_view_0_0_180_0_0_initstate_0 |
| 27 | libero_goal | 1328 | 1329 | Language Instructions | 5 | push_the_plate_to_the_front_of_the_stove_language_42_view_0_0_100_0_0_initstate_0 |
| 28 | libero_spatial | 2244 | 2245 | Light Conditions | 2 | pick_up_the_black_bowl_in_the_top_drawer_of_the_wooden_cabinet_and_place_it_on_the_plate_light_7 |
| 29 | libero_goal | 147 | 148 | Background Textures | 2 | put_the_bowl_on_top_of_the_cabinet_tb_2 |
| 30 | libero_spatial | 1619 | 1620 | Sensor Noise | 2 | pick_up_the_black_bowl_on_the_stove_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_4 |
| 31 | libero_spatial | 2111 | 2112 | Light Conditions | 2 | pick_up_the_black_bowl_between_the_plate_and_the_ramekin_and_place_it_on_the_plate_light_10 |
| 32 | libero_spatial | 2172 | 2173 | Light Conditions | 2 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_light_28 |
| 33 | libero_spatial | 2088 | 2089 | Objects Layout | 3 | pick_up_the_black_bowl_on_the_wooden_cabinet_and_place_it_on_the_plate_add_7 |
| 34 | libero_object | 1472 | 1473 | Sensor Noise | 4 | pick_up_the_cream_cheese_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_38 |
| 35 | libero_goal | 675 | 676 | Robot Initial States | 4 | put_the_wine_bottle_on_the_rack_view_0_0_100_0_0_initstate_280 |
| 36 | libero_object | 612 | 613 | Robot Initial States | 2 | pick_up_the_orange_juice_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_160 |
| 37 | libero_goal | 2573 | 2574 | Light Conditions | 1 | turn_on_the_stove_light_13 |
| 38 | libero_goal | 1390 | 1391 | Language Instructions | 5 | turn_on_the_stove_language_9_view_0_0_100_0_0_initstate_0 |
| 39 | libero_spatial | 772 | 773 | Camera Viewpoints | 3 | pick_up_the_black_bowl_in_the_top_drawer_of_the_wooden_cabinet_and_place_it_on_the_plate_view_70_15_100_0_0_initstate_0 |
| 40 | libero_spatial | 580 | 581 | Robot Initial States | 2 | pick_up_the_black_bowl_on_the_wooden_cabinet_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_230 |
| 41 | libero_goal | 2372 | 2373 | Light Conditions | None | open_the_top_drawer_and_put_the_bowl_inside_light_26 |
| 42 | libero_object | 1605 | 1606 | Sensor Noise | 5 | pick_up_the_ketchup_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_48 |
| 43 | libero_spatial | 1696 | 1697 | Sensor Noise | 3 | pick_up_the_black_bowl_on_the_wooden_cabinet_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_15 |
| 44 | libero_object | 173 | 174 | Background Textures | 3 | pick_up_the_orange_juice_and_place_it_in_the_basket_table_12 |
| 45 | libero_spatial | 328 | 329 | Robot Initial States | 1 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_13 |
| 46 | libero_object | 1103 | 1104 | Language Instructions | 2 | pick_up_the_salad_dressing_and_place_it_in_the_basket_language_7_view_0_0_100_0_0_initstate_0 |
| 47 | libero_goal | 2196 | 2197 | Objects Layout | 1 | put_the_wine_bottle_on_the_rack_add_5 |
| 48 | libero_spatial | 2195 | 2196 | Light Conditions | 3 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_light_49 |
| 49 | libero_object | 205 | 206 | Background Textures | 1 | pick_up_the_orange_juice_and_place_it_in_the_basket_tb_3 |
| 50 | libero_goal | 2483 | 2484 | Light Conditions | None | put_the_cream_cheese_in_the_bowl_light_1 |
| 51 | libero_goal | 1285 | 1286 | Language Instructions | 1 | put_the_bowl_on_top_of_the_cabinet_language_39_view_0_0_100_0_0_initstate_0 |
| 52 | libero_goal | 2427 | 2428 | Light Conditions | 2 | push_the_plate_to_the_front_of_the_stove_light_37 |
| 53 | libero_goal | 2322 | 2323 | Light Conditions | 2 | open_the_middle_drawer_of_the_cabinet_light_19 |
| 54 | libero_spatial | 1255 | 1256 | Language Instructions | 3 | pick_up_the_black_bowl_on_the_stove_and_place_it_on_the_plate_language_12_view_0_0_100_0_0_initstate_0 |
| 55 | libero_object | 1061 | 1062 | Language Instructions | 4 | pick_up_the_alphabet_soup_and_place_it_in_the_basket_language_43_view_0_0_100_0_0_initstate_0 |
| 56 | libero_spatial | 141 | 142 | Background Textures | 2 | pick_up_the_black_bowl_on_the_cookie_box_and_place_it_on_the_plate_table_22 |
| 57 | libero_goal | 979 | 980 | Camera Viewpoints | 2 | turn_on_the_stove_view_0_0_171_0_0_initstate_0 |
| 58 | libero_spatial | 2136 | 2137 | Light Conditions | 4 | pick_up_the_black_bowl_between_the_plate_and_the_ramekin_and_place_it_on_the_plate_light_36 |
| 59 | libero_spatial | 1071 | 1072 | Language Instructions | 3 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_language_17_view_0_0_100_0_0_initstate_0 |
| 60 | libero_goal | 732 | 733 | Camera Viewpoints | 1 | put_the_bowl_on_the_stove_view_25_0_100_0_0_initstate_0 |
| 61 | libero_goal | 2046 | 2047 | Objects Layout | 2 | put_the_bowl_on_the_plate_add_9 |
| 62 | libero_object | 1398 | 1399 | Sensor Noise | 4 | pick_up_the_alphabet_soup_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_4 |
| 63 | libero_goal | 1097 | 1098 | Camera Viewpoints | 3 | put_the_wine_bottle_on_the_rack_view_359_15_100_0_0_initstate_0 |
| 64 | libero_goal | 486 | 487 | Robot Initial States | 3 | put_the_bowl_on_top_of_the_cabinet_view_0_0_100_0_0_initstate_465 |
| 65 | libero_goal | 720 | 721 | Camera Viewpoints | 2 | put_the_bowl_on_the_stove_view_17_15_100_0_0_initstate_0 |
| 66 | libero_spatial | 116 | 117 | Background Textures | 1 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_tb_2 |
| 67 | libero_goal | 2109 | 2110 | Objects Layout | 2 | put_the_bowl_on_top_of_the_cabinet_add_30 |
| 68 | libero_spatial | 140 | 141 | Background Textures | 2 | pick_up_the_black_bowl_on_the_cookie_box_and_place_it_on_the_plate_table_16 |
| 69 | libero_spatial | 2327 | 2328 | Light Conditions | 4 | pick_up_the_black_bowl_on_the_ramekin_and_place_it_on_the_plate_light_22 |
| 70 | libero_object | 360 | 361 | Robot Initial States | 5 | pick_up_the_salad_dressing_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_403 |
| 71 | libero_object | 1004 | 1005 | Camera Viewpoints | 3 | pick_up_the_chocolate_pudding_and_place_it_in_the_basket_view_337_15_100_0_0_initstate_0 |
| 72 | libero_spatial | 682 | 683 | Camera Viewpoints | 2 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_view_43_15_100_0_0_initstate_0 |
| 73 | libero_goal | 2021 | 2022 | Objects Layout | 5 | push_the_plate_to_the_front_of_the_stove_moved_level5_sample4 |
| 74 | libero_object | 2384 | 2385 | Light Conditions | 3 | pick_up_the_chocolate_pudding_and_place_it_in_the_basket_light_5 |
| 75 | libero_object | 1728 | 1729 | Sensor Noise | 2 | pick_up_the_milk_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_44 |
| 76 | libero_goal | 1325 | 1326 | Language Instructions | 3 | push_the_plate_to_the_front_of_the_stove_language_36_view_0_0_100_0_0_initstate_0 |
| 77 | libero_object | 381 | 382 | Robot Initial States | 3 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_234 |
| 78 | libero_spatial | 563 | 564 | Robot Initial States | 2 | pick_up_the_black_bowl_next_to_the_plate_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_469 |
| 79 | libero_object | 83 | 84 | Background Textures | 1 | pick_up_the_butter_and_place_it_in_the_basket_table_19 |
| 80 | libero_spatial | 439 | 440 | Robot Initial States | 4 | pick_up_the_black_bowl_on_the_ramekin_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_276 |
| 81 | libero_spatial | 378 | 379 | Robot Initial States | 3 | pick_up_the_black_bowl_on_the_cookie_box_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_414 |
| 82 | libero_goal | 2318 | 2319 | Light Conditions | None | open_the_middle_drawer_of_the_cabinet_light_15 |
| 83 | libero_spatial | 1681 | 1682 | Sensor Noise | 2 | pick_up_the_black_bowl_next_to_the_plate_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_46 |
| 84 | libero_goal | 2099 | 2100 | Objects Layout | 3 | put_the_bowl_on_top_of_the_cabinet_add_19 |
| 85 | libero_object | 2453 | 2454 | Light Conditions | 4 | pick_up_the_orange_juice_and_place_it_in_the_basket_light_39 |
| 86 | libero_goal | 248 | 249 | Background Textures | 3 | put_the_wine_bottle_on_top_of_the_cabinet_tb_1 |
| 87 | libero_goal | 841 | 842 | Camera Viewpoints | 4 | put_the_bowl_on_top_of_the_cabinet_view_0_0_100_10_2_initstate_0 |
| 88 | libero_spatial | 1087 | 1088 | Language Instructions | 2 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_language_43_view_0_0_100_0_0_initstate_0 |
| 89 | libero_goal | 1638 | 1639 | Sensor Noise | 5 | open_the_top_drawer_and_put_the_bowl_inside_view_0_0_100_0_0_initstate_0_noise_28 |
| 90 | libero_object | 1307 | 1308 | Language Instructions | 4 | pick_up_the_chocolate_pudding_and_place_it_in_the_basket_language_4_view_0_0_100_0_0_initstate_0 |
| 91 | libero_spatial | 1303 | 1304 | Language Instructions | 2 | pick_up_the_black_bowl_next_to_the_plate_and_place_it_on_the_plate_language_23_view_0_0_100_0_0_initstate_0 |
| 92 | libero_object | 1790 | 1791 | Sensor Noise | 5 | pick_up_the_orange_juice_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_15 |
| 93 | libero_spatial | 390 | 391 | Robot Initial States | 2 | pick_up_the_black_bowl_in_the_top_drawer_of_the_wooden_cabinet_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_105 |
| 94 | libero_goal | 38 | 39 | Background Textures | 2 | open_the_top_drawer_and_put_the_bowl_inside_table_18 |
| 95 | libero_goal | 511 | 512 | Robot Initial States | 5 | push_the_plate_to_the_front_of_the_stove_view_0_0_100_0_0_initstate_306 |
| 96 | libero_object | 473 | 474 | Robot Initial States | 4 | pick_up_the_tomato_sauce_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_396 |
| 97 | libero_spatial | 290 | 291 | Robot Initial States | 1 | pick_up_the_black_bowl_next_to_the_ramekin_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_42 |
| 98 | libero_object | 1364 | 1365 | Language Instructions | 3 | pick_up_the_orange_juice_and_place_it_in_the_basket_language_15_view_0_0_100_0_0_initstate_0 |
| 99 | libero_goal | 2454 | 2455 | Light Conditions | None | put_the_bowl_on_the_plate_light_36 |
| 100 | libero_object | 2288 | 2289 | Light Conditions | 4 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_light_33 |
| 101 | libero_goal | 1341 | 1342 | Language Instructions | 2 | put_the_cream_cheese_in_the_bowl_language_8_view_0_0_100_0_0_initstate_0 |
| 102 | libero_object | 1289 | 1290 | Language Instructions | 3 | pick_up_the_milk_and_place_it_in_the_basket_language_33_view_0_0_100_0_0_initstate_0 |
| 103 | libero_spatial | 1913 | 1914 | Objects Layout | 3 | pick_up_the_black_bowl_next_to_the_ramekin_and_place_it_on_the_plate_add_11 |
| 104 | libero_object | 1340 | 1341 | Language Instructions | 4 | pick_up_the_chocolate_pudding_and_place_it_in_the_basket_language_38_view_0_0_100_0_0_initstate_0 |
| 105 | libero_spatial | 531 | 532 | Robot Initial States | 2 | pick_up_the_black_bowl_next_to_the_plate_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_99 |
| 106 | libero_object | 1480 | 1481 | Sensor Noise | 4 | pick_up_the_cream_cheese_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_49 |
| 107 | libero_object | 2074 | 2075 | Objects Layout | 5 | pick_up_the_milk_and_place_it_in_the_basket_level4_sample1 |
| 108 | libero_object | 2121 | 2122 | Objects Layout | 5 | pick_up_the_orange_juice_and_place_it_in_the_basket_level3_sample3 |
| 109 | libero_object | 2349 | 2350 | Light Conditions | 4 | pick_up_the_butter_and_place_it_in_the_basket_light_48 |
| 110 | libero_spatial | 1504 | 1505 | Sensor Noise | 2 | pick_up_the_black_bowl_on_the_cookie_box_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_49 |
| 111 | libero_object | 2476 | 2477 | Light Conditions | 3 | pick_up_the_salad_dressing_and_place_it_in_the_basket_light_3 |
| 112 | libero_spatial | 984 | 985 | Language Instructions | 2 | pick_up_the_black_bowl_between_the_plate_and_the_ramekin_and_place_it_on_the_plate_language_1_view_0_0_100_0_0_initstate_0 |
| 113 | libero_spatial | 1246 | 1247 | Language Instructions | 1 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_language_48_view_0_0_100_0_0_initstate_0 |
| 114 | libero_spatial | 2340 | 2341 | Light Conditions | 4 | pick_up_the_black_bowl_on_the_ramekin_and_place_it_on_the_plate_light_43 |
| 115 | libero_goal | 372 | 373 | Robot Initial States | 3 | put_the_wine_bottle_on_top_of_the_cabinet_view_0_0_100_0_0_initstate_133 |
| 116 | libero_goal | 856 | 857 | Camera Viewpoints | 2 | put_the_bowl_on_top_of_the_cabinet_view_63_15_100_0_0_initstate_0 |
| 117 | libero_object | 2268 | 2269 | Light Conditions | 4 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_light_15 |
| 118 | libero_object | 2145 | 2146 | Objects Layout | 1 | pick_up_the_salad_dressing_and_place_it_in_the_basket_add_26 |
| 119 | libero_object | 74 | 75 | Background Textures | 3 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_tb_5 |
| 120 | libero_spatial | 1397 | 1398 | Sensor Noise | 3 | pick_up_the_black_bowl_between_the_plate_and_the_ramekin_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_40 |
| 121 | libero_spatial | 1238 | 1239 | Language Instructions | 2 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_language_40_view_0_0_100_0_0_initstate_0 |
| 122 | libero_spatial | 1605 | 1606 | Sensor Noise | 1 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_38 |
| 123 | libero_object | 96 | 97 | Background Textures | 3 | pick_up_the_butter_and_place_it_in_the_basket_table_9 |
| 124 | libero_goal | 1724 | 1725 | Sensor Noise | 1 | push_the_plate_to_the_front_of_the_stove_view_0_0_100_0_0_initstate_0_noise_36 |
| 125 | libero_object | 923 | 924 | Camera Viewpoints | 5 | pick_up_the_butter_and_place_it_in_the_basket_view_313_0_100_0_0_initstate_0 |
| 126 | libero_object | 231 | 232 | Background Textures | 1 | pick_up_the_salad_dressing_and_place_it_in_the_basket_tb_5 |
| 127 | libero_object | 324 | 325 | Robot Initial States | 5 | pick_up_the_cream_cheese_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_452 |
| 128 | libero_goal | 1741 | 1742 | Sensor Noise | 4 | put_the_cream_cheese_in_the_bowl_view_0_0_100_0_0_initstate_0_noise_6 |
| 129 | libero_goal | 2055 | 2056 | Objects Layout | 5 | put_the_bowl_on_the_plate_moved_level3_sample1 |
| 130 | libero_object | 2200 | 2201 | Objects Layout | 2 | pick_up_the_tomato_sauce_and_place_it_in_the_basket_add_7 |
| 131 | libero_goal | 2147 | 2148 | Objects Layout | 2 | put_the_cream_cheese_in_the_bowl_add_3 |
| 132 | libero_goal | 1709 | 1710 | Sensor Noise | 5 | push_the_plate_to_the_front_of_the_stove_view_0_0_100_0_0_initstate_0_noise_8 |
| 133 | libero_spatial | 2165 | 2166 | Light Conditions | 3 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_light_21 |
| 134 | libero_object | 850 | 851 | Camera Viewpoints | 3 | pick_up_the_tomato_sauce_and_place_it_in_the_basket_view_286_0_100_0_0_initstate_0 |
| 135 | libero_spatial | 2297 | 2298 | Light Conditions | 3 | pick_up_the_black_bowl_on_the_cookie_box_and_place_it_on_the_plate_light_22 |
| 136 | libero_object | 278 | 279 | Robot Initial States | 4 | pick_up_the_alphabet_soup_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_381 |
| 137 | libero_spatial | 78 | 79 | Background Textures | 2 | pick_up_the_black_bowl_in_the_top_drawer_of_the_wooden_cabinet_and_place_it_on_the_plate_table_19 |
| 138 | libero_goal | 664 | 665 | Robot Initial States | 1 | put_the_wine_bottle_on_the_rack_view_0_0_100_0_0_initstate_170 |
| 139 | libero_spatial | 847 | 848 | Camera Viewpoints | 3 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_view_302_15_100_0_0_initstate_0 |
| 140 | libero_spatial | 665 | 666 | Camera Viewpoints | 1 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_view_34_0_100_0_0_initstate_0 |
| 141 | libero_object | 155 | 156 | Background Textures | 4 | pick_up_the_milk_and_place_it_in_the_basket_tb_11 |
| 142 | libero_object | 1306 | 1307 | Language Instructions | 3 | pick_up_the_chocolate_pudding_and_place_it_in_the_basket_language_3_view_0_0_100_0_0_initstate_0 |
| 143 | libero_object | 134 | 135 | Background Textures | 1 | pick_up_the_ketchup_and_place_it_in_the_basket_tb_2 |
| 144 | libero_goal | 1451 | 1452 | Language Instructions | 5 | put_the_bowl_on_the_plate_language_41_view_0_0_100_0_0_initstate_0 |
| 145 | libero_goal | 279 | 280 | Background Textures | 2 | turn_on_the_stove_tb_20 |
| 146 | libero_spatial | 1823 | 1824 | Objects Layout | 4 | pick_up_the_black_bowl_in_the_top_drawer_of_the_wooden_cabinet_and_place_it_on_the_plate_add_26 |
| 147 | libero_spatial | 1934 | 1935 | Objects Layout | 3 | pick_up_the_black_bowl_next_to_the_ramekin_and_place_it_on_the_plate_level2_sample3 |
| 148 | libero_goal | 2459 | 2460 | Light Conditions | None | put_the_bowl_on_the_plate_light_40 |
| 149 | libero_spatial | 608 | 609 | Camera Viewpoints | 1 | pick_up_the_black_bowl_between_the_plate_and_the_ramekin_and_place_it_on_the_plate_view_0_0_100_2_352_initstate_0 |
| 150 | libero_goal | 111 | 112 | Background Textures | 2 | put_the_bowl_on_the_plate_table_22 |
| 151 | libero_spatial | 1483 | 1484 | Sensor Noise | 2 | pick_up_the_black_bowl_on_the_cookie_box_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_15 |
| 152 | libero_spatial | 735 | 736 | Camera Viewpoints | 2 | pick_up_the_black_bowl_in_the_top_drawer_of_the_wooden_cabinet_and_place_it_on_the_plate_view_0_0_141_0_0_initstate_0 |
| 153 | libero_object | 546 | 547 | Robot Initial States | 2 | pick_up_the_milk_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_318 |
| 154 | libero_object | 2487 | 2488 | Light Conditions | 3 | pick_up_the_salad_dressing_and_place_it_in_the_basket_light_40 |
| 155 | libero_spatial | 219 | 220 | Background Textures | 3 | pick_up_the_black_bowl_on_the_stove_and_place_it_on_the_plate_table_3 |
| 156 | libero_spatial | 342 | 343 | Robot Initial States | 2 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_253 |
| 157 | libero_goal | 1294 | 1295 | Language Instructions | 5 | put_the_bowl_on_top_of_the_cabinet_language_48_view_0_0_100_0_0_initstate_0 |
| 158 | libero_object | 776 | 777 | Camera Viewpoints | 3 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_view_58_15_100_0_0_initstate_0 |
| 159 | libero_object | 227 | 228 | Background Textures | 2 | pick_up_the_salad_dressing_and_place_it_in_the_basket_tb_2 |
| 160 | libero_goal | 796 | 797 | Camera Viewpoints | 5 | open_the_top_drawer_and_put_the_bowl_inside_view_0_0_100_8_350_initstate_0 |
| 161 | libero_spatial | 1521 | 1522 | Sensor Noise | 5 | pick_up_the_black_bowl_in_the_top_drawer_of_the_wooden_cabinet_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_19 |
| 162 | libero_object | 1079 | 1080 | Language Instructions | 1 | pick_up_the_cream_cheese_and_place_it_in_the_basket_language_24_view_0_0_100_0_0_initstate_0 |
| 163 | libero_spatial | 108 | 109 | Background Textures | 1 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_table_9 |
| 164 | libero_object | 574 | 575 | Robot Initial States | 3 | pick_up_the_chocolate_pudding_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_249 |
| 165 | libero_object | 2513 | 2514 | Light Conditions | 5 | pick_up_the_tomato_sauce_and_place_it_in_the_basket_light_38 |
| 166 | libero_object | 2302 | 2303 | Light Conditions | 4 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_light_46 |
| 167 | libero_goal | 359 | 360 | Robot Initial States | 5 | put_the_bowl_on_the_stove_view_0_0_100_0_0_initstate_472 |
| 168 | libero_goal | 1715 | 1716 | Sensor Noise | 4 | push_the_plate_to_the_front_of_the_stove_view_0_0_100_0_0_initstate_0_noise_17 |
| 169 | libero_spatial | 798 | 799 | Camera Viewpoints | 3 | pick_up_the_black_bowl_on_the_ramekin_and_place_it_on_the_plate_view_0_0_100_350_354_initstate_0 |
| 170 | libero_goal | 2367 | 2368 | Light Conditions | None | open_the_top_drawer_and_put_the_bowl_inside_light_21 |
| 171 | libero_goal | 1314 | 1315 | Language Instructions | 5 | push_the_plate_to_the_front_of_the_stove_language_23_view_0_0_100_0_0_initstate_0 |
| 172 | libero_goal | 1806 | 1807 | Sensor Noise | 1 | turn_on_the_stove_view_0_0_100_0_0_initstate_0_noise_44 |
| 173 | libero_goal | 591 | 592 | Robot Initial States | 3 | turn_on_the_stove_view_0_0_100_0_0_initstate_258 |
| 174 | libero_object | 1077 | 1078 | Language Instructions | 4 | pick_up_the_cream_cheese_and_place_it_in_the_basket_language_20_view_0_0_100_0_0_initstate_0 |
| 175 | libero_goal | 1586 | 1587 | Sensor Noise | 4 | put_the_wine_bottle_on_top_of_the_cabinet_view_0_0_100_0_0_initstate_0_noise_9 |
| 176 | libero_spatial | 1731 | 1732 | Objects Layout | 4 | pick_up_the_black_bowl_between_the_plate_and_the_ramekin_and_place_it_on_the_plate_add_16 |
| 177 | libero_object | 2376 | 2377 | Light Conditions | 4 | pick_up_the_chocolate_pudding_and_place_it_in_the_basket_light_39 |
| 178 | libero_object | 26 | 27 | Background Textures | 1 | pick_up_the_alphabet_soup_and_place_it_in_the_basket_tb_22 |
| 179 | libero_object | 1739 | 1740 | Sensor Noise | 4 | pick_up_the_chocolate_pudding_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_6 |
| 180 | libero_spatial | 924 | 925 | Camera Viewpoints | 2 | pick_up_the_black_bowl_next_to_the_plate_and_place_it_on_the_plate_view_0_0_100_356_6_initstate_0 |
| 181 | libero_goal | 1639 | 1640 | Sensor Noise | 5 | open_the_top_drawer_and_put_the_bowl_inside_view_0_0_100_0_0_initstate_0_noise_30 |
| 182 | libero_object | 2059 | 2060 | Objects Layout | 3 | pick_up_the_milk_and_place_it_in_the_basket_add_5 |
| 183 | libero_goal | 1493 | 1494 | Language Instructions | 5 | put_the_wine_bottle_on_the_rack_language_36_view_0_0_100_0_0_initstate_0 |
| 184 | libero_spatial | 209 | 210 | Background Textures | 2 | pick_up_the_black_bowl_on_the_stove_and_place_it_on_the_plate_table_18 |
| 185 | libero_spatial | 1777 | 1778 | Objects Layout | 3 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_add_22 |
| 186 | libero_object | 2317 | 2318 | Light Conditions | 5 | pick_up_the_butter_and_place_it_in_the_basket_light_16 |
| 187 | libero_goal | 2376 | 2377 | Light Conditions | None | open_the_top_drawer_and_put_the_bowl_inside_light_3 |
| 188 | libero_object | 926 | 927 | Camera Viewpoints | 4 | pick_up_the_butter_and_place_it_in_the_basket_view_314_15_100_0_0_initstate_0 |
| 189 | libero_object | 1584 | 1585 | Sensor Noise | 1 | pick_up_the_ketchup_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_23 |
| 190 | libero_goal | 1640 | 1641 | Sensor Noise | 3 | open_the_top_drawer_and_put_the_bowl_inside_view_0_0_100_0_0_initstate_0_noise_31 |
| 191 | libero_spatial | 2270 | 2271 | Light Conditions | 2 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_light_42 |
| 192 | libero_spatial | 1785 | 1786 | Objects Layout | 4 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_add_30 |
| 193 | libero_object | 787 | 788 | Camera Viewpoints | 5 | pick_up_the_ketchup_and_place_it_in_the_basket_view_0_0_147_0_0_initstate_0 |
| 194 | libero_spatial | 1615 | 1616 | Sensor Noise | 3 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_49 |
| 195 | libero_spatial | 590 | 591 | Robot Initial States | 2 | pick_up_the_black_bowl_on_the_wooden_cabinet_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_330 |
| 196 | libero_object | 400 | 401 | Robot Initial States | 5 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_434 |
| 197 | libero_spatial | 438 | 439 | Robot Initial States | 1 | pick_up_the_black_bowl_on_the_ramekin_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_266 |
| 198 | libero_goal | 1222 | 1223 | Language Instructions | 4 | open_the_top_drawer_and_put_the_bowl_inside_language_21_view_0_0_100_0_0_initstate_0 |
| 199 | libero_goal | 1013 | 1014 | Camera Viewpoints | 2 | turn_on_the_stove_view_324_0_100_0_0_initstate_0 |
| 200 | libero_spatial | 238 | 239 | Background Textures | 3 | pick_up_the_black_bowl_on_the_stove_and_place_it_on_the_plate_tb_3 |
| 201 | libero_object | 1540 | 1541 | Sensor Noise | 5 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_20 |
| 202 | libero_goal | 1265 | 1266 | Language Instructions | 3 | put_the_bowl_on_top_of_the_cabinet_language_16_view_0_0_100_0_0_initstate_0 |
| 203 | libero_goal | 1548 | 1549 | Sensor Noise | 4 | open_the_middle_drawer_of_the_cabinet_view_0_0_100_0_0_initstate_0_noise_49 |
| 204 | libero_goal | 812 | 813 | Camera Viewpoints | 5 | open_the_top_drawer_and_put_the_bowl_inside_view_51_15_100_0_0_initstate_0 |
| 205 | libero_spatial | 1232 | 1233 | Language Instructions | 2 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_language_34_view_0_0_100_0_0_initstate_0 |
| 206 | libero_goal | 211 | 212 | Background Textures | 4 | put_the_wine_bottle_on_the_rack_tb_11 |
| 207 | libero_object | 98 | 99 | Background Textures | 1 | pick_up_the_butter_and_place_it_in_the_basket_tb_21 |
| 208 | libero_object | 226 | 227 | Background Textures | 1 | pick_up_the_salad_dressing_and_place_it_in_the_basket_tb_18 |
| 209 | libero_goal | 1635 | 1636 | Sensor Noise | 3 | open_the_top_drawer_and_put_the_bowl_inside_view_0_0_100_0_0_initstate_0_noise_23 |
| 210 | libero_spatial | 638 | 639 | Camera Viewpoints | 3 | pick_up_the_black_bowl_next_to_the_ramekin_and_place_it_on_the_plate_view_24_0_100_0_0_initstate_0 |
| 211 | libero_spatial | 1409 | 1410 | Sensor Noise | 2 | pick_up_the_black_bowl_next_to_the_ramekin_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_5 |
| 212 | libero_goal | 252 | 253 | Background Textures | 3 | put_the_wine_bottle_on_top_of_the_cabinet_tb_13 |
| 213 | libero_object | 1844 | 1845 | Objects Layout | 4 | pick_up_the_alphabet_soup_and_place_it_in_the_basket_level2_sample2 |
| 214 | libero_goal | 1171 | 1172 | Language Instructions | 2 | put_the_wine_bottle_on_top_of_the_cabinet_language_10_view_0_0_100_0_0_initstate_0 |
| 215 | libero_spatial | 1114 | 1115 | Language Instructions | 1 | pick_up_the_black_bowl_on_the_cookie_box_and_place_it_on_the_plate_language_31_view_0_0_100_0_0_initstate_0 |
| 216 | libero_goal | 972 | 973 | Camera Viewpoints | 3 | put_the_cream_cheese_in_the_bowl_view_311_0_100_0_0_initstate_0 |
| 217 | libero_spatial | 117 | 118 | Background Textures | 1 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_tb_20 |
| 218 | libero_goal | 2026 | 2027 | Objects Layout | 2 | put_the_bowl_on_the_plate_add_14 |
| 219 | libero_object | 2140 | 2141 | Objects Layout | 1 | pick_up_the_salad_dressing_and_place_it_in_the_basket_add_20 |
| 220 | libero_goal | 1309 | 1310 | Language Instructions | 1 | push_the_plate_to_the_front_of_the_stove_language_18_view_0_0_100_0_0_initstate_0 |
| 221 | libero_spatial | 67 | 68 | Background Textures | 3 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_tb_23 |
| 222 | libero_object | 1855 | 1856 | Objects Layout | 4 | pick_up_the_alphabet_soup_and_place_it_in_the_basket_level5_sample1 |
| 223 | libero_spatial | 1801 | 1802 | Objects Layout | 4 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_level4_sample1 |
| 224 | libero_spatial | 1542 | 1543 | Sensor Noise | 3 | pick_up_the_black_bowl_in_the_top_drawer_of_the_wooden_cabinet_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_47 |
| 225 | libero_spatial | 937 | 938 | Camera Viewpoints | 2 | pick_up_the_black_bowl_next_to_the_plate_and_place_it_on_the_plate_view_334_15_100_0_0_initstate_0 |
| 226 | libero_goal | 1487 | 1488 | Language Instructions | 4 | put_the_wine_bottle_on_the_rack_language_30_view_0_0_100_0_0_initstate_0 |
| 227 | libero_spatial | 168 | 169 | Background Textures | 1 | pick_up_the_black_bowl_on_the_ramekin_and_place_it_on_the_plate_table_1 |
| 228 | libero_goal | 1885 | 1886 | Sensor Noise | 5 | put_the_wine_bottle_on_the_rack_view_0_0_100_0_0_initstate_0_noise_49 |
| 229 | libero_object | 283 | 284 | Robot Initial States | 4 | pick_up_the_alphabet_soup_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_431 |
| 230 | libero_goal | 2093 | 2094 | Objects Layout | 4 | put_the_bowl_on_the_stove_moved_level5_sample4 |
| 231 | libero_spatial | 181 | 182 | Background Textures | 1 | pick_up_the_black_bowl_on_the_ramekin_and_place_it_on_the_plate_table_25 |
| 232 | libero_spatial | 1256 | 1257 | Language Instructions | 1 | pick_up_the_black_bowl_on_the_stove_and_place_it_on_the_plate_language_13_view_0_0_100_0_0_initstate_0 |
| 233 | libero_goal | 792 | 793 | Camera Viewpoints | 4 | open_the_top_drawer_and_put_the_bowl_inside_view_0_0_100_8_4_initstate_0 |
| 234 | libero_goal | 2134 | 2135 | Objects Layout | 2 | put_the_cream_cheese_in_the_bowl_add_17 |
| 235 | libero_goal | 154 | 155 | Background Textures | 4 | put_the_cream_cheese_in_the_bowl_table_13 |
| 236 | libero_spatial | 394 | 395 | Robot Initial States | 1 | pick_up_the_black_bowl_in_the_top_drawer_of_the_wooden_cabinet_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_145 |
| 237 | libero_spatial | 51 | 52 | Background Textures | 3 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_table_8 |
| 238 | libero_object | 2233 | 2234 | Light Conditions | 5 | pick_up_the_alphabet_soup_and_place_it_in_the_basket_light_20 |
| 239 | libero_spatial | 1091 | 1092 | Language Instructions | 2 | pick_up_the_black_bowl_on_the_cookie_box_and_place_it_on_the_plate_language_2_view_0_0_100_0_0_initstate_0 |
| 240 | libero_object | 2072 | 2073 | Objects Layout | 5 | pick_up_the_milk_and_place_it_in_the_basket_level3_sample3 |
| 241 | libero_goal | 2481 | 2482 | Light Conditions | 1 | put_the_bowl_on_top_of_the_cabinet_light_6 |
| 242 | libero_object | 2308 | 2309 | Light Conditions | 4 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_light_6 |
| 243 | libero_object | 737 | 738 | Camera Viewpoints | 3 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_view_0_0_135_0_0_initstate_0 |
| 244 | libero_spatial | 1699 | 1700 | Sensor Noise | 4 | pick_up_the_black_bowl_on_the_wooden_cabinet_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_18 |
| 245 | libero_spatial | 2266 | 2267 | Light Conditions | 2 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_light_39 |
| 246 | libero_object | 1331 | 1332 | Language Instructions | 1 | pick_up_the_chocolate_pudding_and_place_it_in_the_basket_language_29_view_0_0_100_0_0_initstate_0 |
| 247 | libero_object | 706 | 707 | Camera Viewpoints | 1 | pick_up_the_salad_dressing_and_place_it_in_the_basket_view_32_0_100_0_0_initstate_0 |
| 248 | libero_object | 2048 | 2049 | Objects Layout | 3 | pick_up_the_milk_and_place_it_in_the_basket_add_22 |
| 249 | libero_goal | 253 | 254 | Background Textures | 2 | put_the_wine_bottle_on_top_of_the_cabinet_tb_14 |
| 250 | libero_spatial | 923 | 924 | Camera Viewpoints | 4 | pick_up_the_black_bowl_next_to_the_plate_and_place_it_on_the_plate_view_0_0_190_0_0_initstate_0 |
| 251 | libero_spatial | 769 | 770 | Camera Viewpoints | 3 | pick_up_the_black_bowl_in_the_top_drawer_of_the_wooden_cabinet_and_place_it_on_the_plate_view_69_0_100_0_0_initstate_0 |
| 252 | libero_object | 2080 | 2081 | Objects Layout | 5 | pick_up_the_milk_and_place_it_in_the_basket_level5_sample3 |
| 253 | libero_goal | 159 | 160 | Background Textures | 5 | put_the_cream_cheese_in_the_bowl_table_27 |
| 254 | libero_spatial | 1449 | 1450 | Sensor Noise | 2 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_13 |
| 255 | libero_object | 72 | 73 | Background Textures | 3 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_tb_3 |
| 256 | libero_object | 1492 | 1493 | Sensor Noise | 2 | pick_up_the_salad_dressing_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_13 |
| 257 | libero_goal | 2027 | 2028 | Objects Layout | 2 | put_the_bowl_on_the_plate_add_15 |
| 258 | libero_object | 266 | 267 | Robot Initial States | 2 | pick_up_the_alphabet_soup_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_261 |
| 259 | libero_goal | 2492 | 2493 | Light Conditions | 1 | put_the_cream_cheese_in_the_bowl_light_27 |
| 260 | libero_goal | 158 | 159 | Background Textures | 4 | put_the_cream_cheese_in_the_bowl_table_26 |
| 261 | libero_goal | 263 | 264 | Background Textures | 4 | put_the_wine_bottle_on_top_of_the_cabinet_tb_3 |
| 262 | libero_object | 1088 | 1089 | Language Instructions | 3 | pick_up_the_cream_cheese_and_place_it_in_the_basket_language_36_view_0_0_100_0_0_initstate_0 |
| 263 | libero_object | 806 | 807 | Camera Viewpoints | 5 | pick_up_the_ketchup_and_place_it_in_the_basket_view_64_15_100_0_0_initstate_0 |
| 264 | libero_object | 1448 | 1449 | Sensor Noise | 1 | pick_up_the_cream_cheese_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_11 |
| 265 | libero_goal | 282 | 283 | Robot Initial States | 1 | open_the_middle_drawer_of_the_cabinet_view_0_0_100_0_0_initstate_11 |
| 266 | libero_goal | 1854 | 1855 | Sensor Noise | 5 | put_the_wine_bottle_on_the_rack_view_0_0_100_0_0_initstate_0_noise_10 |
| 267 | libero_object | 535 | 536 | Robot Initial States | 4 | pick_up_the_milk_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_198 |
| 268 | libero_goal | 636 | 637 | Robot Initial States | 3 | put_the_bowl_on_the_plate_view_0_0_100_0_0_initstate_319 |
| 269 | libero_goal | 753 | 754 | Camera Viewpoints | 3 | put_the_wine_bottle_on_top_of_the_cabinet_view_31_0_100_0_0_initstate_0 |
| 270 | libero_goal | 1667 | 1668 | Sensor Noise | 4 | put_the_bowl_on_top_of_the_cabinet_view_0_0_100_0_0_initstate_0_noise_11 |
| 271 | libero_goal | 595 | 596 | Robot Initial States | 3 | turn_on_the_stove_view_0_0_100_0_0_initstate_298 |
| 272 | libero_object | 1078 | 1079 | Language Instructions | 5 | pick_up_the_cream_cheese_and_place_it_in_the_basket_language_21_view_0_0_100_0_0_initstate_0 |
| 273 | libero_object | 1597 | 1598 | Sensor Noise | 4 | pick_up_the_ketchup_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_39 |
| 274 | libero_object | 1890 | 1891 | Objects Layout | 5 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_level2_sample4 |
| 275 | libero_spatial | 2398 | 2399 | Light Conditions | 3 | pick_up_the_black_bowl_on_the_wooden_cabinet_and_place_it_on_the_plate_light_38 |
| 276 | libero_goal | 489 | 490 | Robot Initial States | 3 | put_the_bowl_on_top_of_the_cabinet_view_0_0_100_0_0_initstate_495 |
| 277 | libero_spatial | 1873 | 1874 | Objects Layout | 4 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_level2_sample3 |
| 278 | libero_spatial | 537 | 538 | Robot Initial States | 3 | pick_up_the_black_bowl_next_to_the_plate_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_159 |
| 279 | libero_object | 1373 | 1374 | Language Instructions | 1 | pick_up_the_orange_juice_and_place_it_in_the_basket_language_24_view_0_0_100_0_0_initstate_0 |
| 280 | libero_spatial | 33 | 34 | Background Textures | 2 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_table_15 |
| 281 | libero_object | 940 | 941 | Camera Viewpoints | 5 | pick_up_the_milk_and_place_it_in_the_basket_view_0_0_100_354_10_initstate_0 |
| 282 | libero_object | 1835 | 1836 | Objects Layout | 2 | pick_up_the_alphabet_soup_and_place_it_in_the_basket_add_30 |
| 283 | libero_spatial | 1438 | 1439 | Sensor Noise | 4 | pick_up_the_black_bowl_next_to_the_ramekin_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_49 |
| 284 | libero_goal | 141 | 142 | Background Textures | 4 | put_the_bowl_on_top_of_the_cabinet_table_13 |
| 285 | libero_object | 1749 | 1750 | Sensor Noise | 5 | pick_up_the_chocolate_pudding_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_17 |
| 286 | libero_object | 2431 | 2432 | Light Conditions | 4 | pick_up_the_orange_juice_and_place_it_in_the_basket_light_11 |
| 287 | libero_spatial | 998 | 999 | Language Instructions | 2 | pick_up_the_black_bowl_between_the_plate_and_the_ramekin_and_place_it_on_the_plate_language_15_view_0_0_100_0_0_initstate_0 |
| 288 | libero_goal | 392 | 393 | Robot Initial States | 2 | put_the_wine_bottle_on_top_of_the_cabinet_view_0_0_100_0_0_initstate_373 |
| 289 | libero_goal | 809 | 810 | Camera Viewpoints | 5 | open_the_top_drawer_and_put_the_bowl_inside_view_50_0_100_0_0_initstate_0 |
| 290 | libero_goal | 2242 | 2243 | Objects Layout | 2 | put_the_wine_bottle_on_top_of_the_cabinet_add_7 |
| 291 | libero_spatial | 1857 | 1858 | Objects Layout | 4 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_add_19 |
| 292 | libero_goal | 670 | 671 | Robot Initial States | 5 | put_the_wine_bottle_on_the_rack_view_0_0_100_0_0_initstate_230 |
| 293 | libero_object | 174 | 175 | Background Textures | 3 | pick_up_the_orange_juice_and_place_it_in_the_basket_table_14 |
| 294 | libero_object | 538 | 539 | Robot Initial States | 3 | pick_up_the_milk_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_238 |
| 295 | libero_object | 694 | 695 | Camera Viewpoints | 3 | pick_up_the_salad_dressing_and_place_it_in_the_basket_view_0_0_128_0_0_initstate_0 |
| 296 | libero_spatial | 799 | 800 | Camera Viewpoints | 1 | pick_up_the_black_bowl_on_the_ramekin_and_place_it_on_the_plate_view_0_0_100_350_356_initstate_0 |
| 297 | libero_spatial | 1085 | 1086 | Language Instructions | 1 | pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate_language_41_view_0_0_100_0_0_initstate_0 |
| 298 | libero_spatial | 586 | 587 | Robot Initial States | 1 | pick_up_the_black_bowl_on_the_wooden_cabinet_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_290 |
| 299 | libero_goal | 2589 | 2590 | Light Conditions | 2 | turn_on_the_stove_light_5 |
| 300 | libero_spatial | 1870 | 1871 | Objects Layout | 4 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_add_9 |
| 301 | libero_goal | 6 | 7 | Background Textures | 3 | open_the_middle_drawer_of_the_cabinet_table_17 |
| 302 | libero_spatial | 2218 | 2219 | Light Conditions | 4 | pick_up_the_black_bowl_in_the_top_drawer_of_the_wooden_cabinet_and_place_it_on_the_plate_light_24 |
| 303 | libero_object | 420 | 421 | Robot Initial States | 3 | pick_up_the_ketchup_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_255 |
| 304 | libero_object | 912 | 913 | Camera Viewpoints | 5 | pick_up_the_butter_and_place_it_in_the_basket_view_307_15_100_0_0_initstate_0 |
| 305 | libero_object | 376 | 377 | Robot Initial States | 4 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_184 |
| 306 | libero_spatial | 1948 | 1949 | Objects Layout | 2 | pick_up_the_black_bowl_on_the_cookie_box_and_place_it_on_the_plate_add_10 |
| 307 | libero_object | 1546 | 1547 | Sensor Noise | 3 | pick_up_the_bbq_sauce_and_place_it_in_the_basket_view_0_0_100_0_0_initstate_0_noise_29 |
| 308 | libero_object | 236 | 237 | Background Textures | 3 | pick_up_the_tomato_sauce_and_place_it_in_the_basket_table_14 |
| 309 | libero_spatial | 311 | 312 | Robot Initial States | 2 | pick_up_the_black_bowl_next_to_the_ramekin_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_322 |
| 310 | libero_goal | 2219 | 2220 | Objects Layout | 4 | put_the_wine_bottle_on_the_rack_moved_level5_sample4 |
| 311 | libero_spatial | 1349 | 1350 | Language Instructions | 3 | pick_up_the_black_bowl_on_the_wooden_cabinet_and_place_it_on_the_plate_language_25_view_0_0_100_0_0_initstate_0 |
| 312 | libero_goal | 2096 | 2097 | Objects Layout | 3 | put_the_bowl_on_top_of_the_cabinet_add_16 |
| 313 | libero_spatial | 196 | 197 | Background Textures | 3 | pick_up_the_black_bowl_on_the_ramekin_and_place_it_on_the_plate_tb_22 |
| 314 | libero_spatial | 1611 | 1612 | Sensor Noise | 2 | pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate_view_0_0_100_0_0_initstate_0_noise_45 |
| 315 | libero_spatial | 2379 | 2380 | Light Conditions | 3 | pick_up_the_black_bowl_on_the_stove_and_place_it_on_the_plate_light_50 |


## Three-GPU restart

Control uses GPU 1; experiment uses GPUs 2 and 3 with a shared task queue. All 315 task IDs and model parameters are unchanged. Ten completed control results and five completed experimental results were retained. In-progress tasks are requeued. Original logs/configurations are retained in restart_archive_1234.
