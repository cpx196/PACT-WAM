# Paired LIBERO-Plus OOD pilot: launch record

Initially started on 2026-09-26 at 12:20:59 HKT; restarted at 12:36:27 HKT using nohup + setsid after the user requested three cards.

- Server root: `/data/pxchen/PACT-WAM/evaluate_results/plus_short315_paired_rot180_20260926`
- GPU 1: `control_noguidance`, 315 tasks.
- GPUs 2 and 3: `experiment_rot180_guidance4x`, the same 315 tasks shared by two workers (initially GPU 3 only).
- The experimental checkpoint is the rotated-input fine-tune at step 2000, not the upright-input fine-tune.
- FastWAM current primary/wrist observations and generated future keep their 180-degree convention. The experimental JEPA uses only the primary view, with no extra encoder rotation; current and future are both inverted.
- The encoder remains frozen. FastWAM uses BF16; JEPA inference uses FP32.
- No trigger and no early-replan special rule. Full 4x raw-gradient guidance at steps 7/8/9, RMS cap 0.02, 2 AC steps, descent verification enabled.
- Original task-level camera perturbations are preserved; position/quaternion/FOV overrides are null.
- Execution gripper binarization is unchanged. No new gripper-specific gradient mask was added.
- Future-video visualization is enabled in both groups, as in previous accuracy evaluations. Therefore these wall-clock runtimes are not decode-excluded latency benchmarks.

At 12:29 HKT, control had completed 4 tasks and experiment 3 tasks. The first 3 matched tasks succeeded in both groups. GPU workers were alive and producing results/guidance diagnostics.

The old process group was stopped with SIGTERM. Ten complete control results and five complete experimental results were preserved, while interrupted tasks were requeued. Old worker logs/status and configurations are archived on the server in `restart_archive_1234`.

Comparison of archived and restarted manager configurations showed no control configuration changes and only `MULTIRUN.num_gpus: 1 -> 2` for the experiment. The task-list checksum is unchanged.

At 12:40 HKT, all three restarted workers were running: control on GPU 1, and two experimental workers on GPUs 2 and 3 executing distinct tasks from the shared queue. Both experimental workers had passed model loading and were generating action guidance diagnostics. Already completed tasks were skipped. No traceback or OOM was observed during the startup check.

Before restart, mean task durations were 50.6 seconds over 10 control tasks and 101.1 seconds over 5 experimental tasks. At these rates, remaining work is about 4.3 hours per group with the new topology. Conservative initial estimate after the three-card restart: 5–8 hours total (roughly 17:30–20:30 HKT). These early results are not representative of all categories, and failure-heavy sampling can exceed the range.

`TASKS_AND_SETTINGS.md` lists all 315 tasks. `task_manifest.json` includes the settings, exact instructions, official perturbation/difficulty labels, resolved scene paths and initial-state metadata. `tasks.txt` is the exact worker input; both groups consume the same order. The two saved manager YAML files capture resolved launch settings. Official difficulty labels are not calibrated to our policy.

Monitor `progress.log`, each group's `run.log`, and `.worker_pool/status/worker_*.json`. Completion and correctness of all 630 episodes must be checked separately; startup stability is not a completed evaluation.
