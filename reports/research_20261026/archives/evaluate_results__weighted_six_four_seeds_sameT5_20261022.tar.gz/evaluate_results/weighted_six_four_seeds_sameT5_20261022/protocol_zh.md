# 六案例四seed：固定离线权重，对照无guidance

用户确认：6task_seed7_sameT5，seed7/17/27/37，trial0、初始状态索引0、固定执行8步；同一份历史T5缓存。实验组=离线逐元素加权guidance；对照=完全无guidance。固定已有三个基础任务权重，不按seed重新采样。24个(case,seed)各保存权重引用与哈希。

seed7复用：无guidance六次0/6；加权guidance六次2/6（151=360步，559=210步）。每组总24次；每组新增18次，总新增36次，含复用共48次。

## 新运行

远端输出：/data/pxchen/PACT-WAM/evaluate_results/weighted_six_four_seeds_sameT5_20261022
nohup日志：/data/pxchen/PACT-WAM/weighted_six_four_seeds_sameT5_20261022_nohup.log
launcher PID：1386573。

两卡并行，一卡weighted、另一卡control；各自按seed17六案例→seed27六案例→seed37六案例顺序。使用空闲无计算进程、空闲显存>=18432MiB且稳定20秒的GPU；不影响原始LIBERO10四seed40次作业。

先复现seed7基准首4步与加权完整32步开局，验证复用依据；每个新增seed对六案例分别进行解码开关动作相同、重复推理相同检查。两组共享paired_preflight文件，严格校验相同(seed,task)的初始观察和未加权动作哈希相同。正式首段和本组preflight精确匹配。

保留夹爪修复与每次前向执行接口相同/反向夹爪梯度为0审计。guided固定节点7/8/9、raw倍率4、RMS上限0.02、FP32 AR2 Predictor epoch10 step19690、原AR梯度链、L1、beta1。控制组关闭ranker与guidance，不加载JEPA模型。

全新代码使用原生_run_task_to_file与run_single_episode；每组单独日志、summary，父summary自动合并12个复用结果与36个新结果。任何严格一致性错误保留日志并终止配对新作业，不能放松检查。完整实际/想象视频保留。

启动记录：2026-10-22 10:56两组启动，weighted GPU0/PID1393745，control GPU2/PID1393746；launcher1386573。两组与父进程SIGHUP均忽略。11:00前seed7历史复现通过；control已进入seed17。按当前速度，完整结果预计北京时间12:50–13:15，取决于成功是否提前结束与视频写入时间。
