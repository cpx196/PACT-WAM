# 保留的 seed7 六任务 baseline

按用户 2026-10-21 的决定，保留原始六任务无 guidance、固定执行8步的结果，作为后续实验基准，不另换一份基线。

- 任务：151、242、260、321、559、590。
- seed=7，trial=0，initial_state_index=0；每次规划32步，固定执行8步；无 guidance。
- task151 来源：`evaluate_results/fastwam_t4_seed7_task151_20261020` 的 `fixed8`。
- 其余五任务来源：`evaluate_results/fastwam_t4_seed7_remaining5_20261020` 的 `fixed8`。
- 六任务结果均失败，每任务700控制步、88次WAM调用。

这是保留原始 baseline 的决定。此前跨轮次更改文本编码批次的效果归因仍作废，不因此恢复旧的阈值效果结论。

为保留这份基准的实际输入，已从受控定位实验冻结历史编码张量：task151 使用原先单任务编码，其余五任务使用原先五任务合批编码。不能用修复后重新逐条编码生成的新张量替换它们，再直接对照旧 baseline。

远端冻结目录：`/data/pxchen/PACT-WAM/evaluate_results/t4_seed7_baseline_reference_20261021`。内含历史文本缓存、指纹、原始文件校验值、抽取出的六条 baseline 结果和528个窗口。

当前已精确复现 task151、559 的历史首动作；其余四任务以及完整轨迹尚未重新验证。后续方法需要明确加载这份历史编码缓存（标记为 historical_mixed_1_and_5，当前默认 canonical_batch1 加载入口会拒绝混用），核对各任务初始观测及首段动作后，才能开展与该基线的公平效果比较。
