#!/usr/bin/env bash
set -uo pipefail

cd /data/pxchen/PACT-WAM
source scripts/local_libero_env.sh
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

output_root=/data/pxchen/PACT-WAM/evaluate_results/retest_split_idm_core3_seed37_step0p1_gpu3_gpu7_20260921
task_file=/data/pxchen/PACT-WAM/artifacts/evaluate_results/jepa_guidance_last2_long_core3_20260915_1800/seed_17/libero_plus_long_robot_init_core3.txt
mkdir -p "$output_root"
echo $$ > "$output_root/launcher.pid"

run_eval() {
    local run_name=$1
    local gpu_id=$2
    local guidance_enabled=$3
    local run_dir="$output_root/$run_name"
    mkdir -p "$run_dir"
    echo "[$(date '+%F %T')] START $run_name gpu=$gpu_id guidance=$guidance_enabled"

    common_args=(
        task=libero_optional_idm_2cam224_1e-4
        "ckpt=$FASTWAM_CHECKPOINT"
        "EVALUATION.dataset_stats_path=$FASTWAM_DATASET_STATS"
        "EVALUATION.output_dir=$run_dir"
        "MULTIRUN.task_file=$task_file"
        MULTIRUN.num_gpus=1
        EVALUATION.num_trials=1
        EVALUATION.replan_steps=8
        EVALUATION.num_inference_steps=10
        EVALUATION.compile_action_infer=false
        EVALUATION.visualize_future_video=true
        EVALUATION.offload_text_encoder=true
        EVALUATION.action_infer_mode=idm
        EVALUATION.video_sigma_shift=5.0
        EVALUATION.action_sigma_shift=1.0
        EVALUATION.sigma_shift=null
        model.load_text_encoder=true
        model.redirect_common_files=false
        model.skip_dit_load_from_pretrain=true
        seed=37
    )

    if [[ "$guidance_enabled" == true ]]; then
        method_args=(
            EVALUATION.vjepa2_ac.enabled=true
            EVALUATION.vjepa2_ac.num_action_candidates=8
            EVALUATION.vjepa2_ac.replan_steps=8
            "EVALUATION.vjepa2_ac.checkpoint_path=$VJEPA2_CHECKPOINT"
            "EVALUATION.vjepa2_ac.repo_path=$VJEPA2_REPO"
            EVALUATION.vjepa2_ac.dtype=float32
            EVALUATION.vjepa2_ac.candidate_generation_mode=separate
            EVALUATION.vjepa2_ac.camera.preset=libero_default
            EVALUATION.vjepa2_ac.camera.position=null
            EVALUATION.vjepa2_ac.camera.quaternion=null
            EVALUATION.vjepa2_ac.camera.fovy=null
            EVALUATION.vjepa2_ac.camera.image_rotation_degrees=180
            EVALUATION.vjepa2_ac.guidance.enabled=true
            'EVALUATION.vjepa2_ac.guidance.after_flow_steps=[7,8,9]'
            EVALUATION.vjepa2_ac.guidance.step_size=0.1
            EVALUATION.vjepa2_ac.guidance.ac_steps=2
            EVALUATION.vjepa2_ac.guidance.verify_descent=true
        )
    else
        method_args=(
            EVALUATION.vjepa2_ac.enabled=false
            EVALUATION.vjepa2_ac.guidance.enabled=false
        )
    fi

    CUDA_VISIBLE_DEVICES="$gpu_id" \
        "$FASTWAM_PYTHON" experiments/libero/run_libero_manager.py \
        "${common_args[@]}" "${method_args[@]}" \
        2>&1 | tee "$run_dir/run.log"
    local status=${PIPESTATUS[0]}
    echo "[$(date '+%F %T')] END $run_name status=$status"
    return "$status"
}

control_status=0
guidance_status=0
run_eval control_seed37 3 false &
control_pid=$!
run_eval guidance_seed37 7 true &
guidance_pid=$!
wait "$control_pid" || control_status=$?
wait "$guidance_pid" || guidance_status=$?

echo "[$(date '+%F %T')] ALL_BATCHES_FINISHED control_status=$control_status guidance_status=$guidance_status"
