#!/usr/bin/env bash
set -uo pipefail

cd /data/pxchen/PACT-WAM
source scripts/local_libero_env.sh
results_root=/data/pxchen/PACT-WAM/evaluate_results/trigger_probe_long36_failures64_shift1_20260922
analysis_log="$results_root/trigger_analysis.log"
mkdir -p "$results_root"

while true; do
    completed=$(find "$results_root" -type f -name 'gpu*_task*_results.json' 2>/dev/null | wc -l)
    if [[ "$completed" -ge 64 ]]; then
        break
    fi
    if [[ -f "$results_root/completion.log" ]] && ! grep -q 'FINISHED status=0' "$results_root/completion.log"; then
        echo "Main evaluation ended unsuccessfully; trigger analysis not started." >> "$analysis_log"
        exit 1
    fi
    sleep 30
done

"$FASTWAM_PYTHON" experiments/libero/analyze_trigger_probe.py "$results_root" \
    >> "$analysis_log" 2>&1
status=$?
echo "[$(date '+%F %T')] ANALYSIS_FINISHED status=$status" >> "$analysis_log"
exit "$status"
