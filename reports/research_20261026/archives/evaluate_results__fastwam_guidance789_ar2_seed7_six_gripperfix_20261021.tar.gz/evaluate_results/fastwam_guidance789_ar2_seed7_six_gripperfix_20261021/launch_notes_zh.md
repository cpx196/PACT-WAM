# 修复夹爪后：seed7六任务guidance重跑

任务151/242/260/321/559/590，全部新跑，不复用旧guidance episode。seed7/trial0/init0、700控制步、settling30步、原生固定执行8步；仍用AR2 epoch10，guidance节点7/8/9，倍率4，normalize_gradient=false，RMS上限0.02。未改变AR梯度链或去噪调度。

夹爪修复：Predictor接收执行端CPU反归一化与二值化后的夹爪命令，夹爪梯度为0。真实模型的每次energy与每次反向均核验这一点。

复现：固定 `/data/pxchen/PACT-WAM/evaluate_results/t4_seed7_baseline_reference_20261021` 中的历史文本缓存及SHA256。task151使用历史单条编码，其余五任务使用历史五条合批编码；不重新运行T5。启动前六任务逐一确认初态与旧baseline首4步精确一致，无guidance解码开关前后完整32动作一致，guided首段重复一致；正式首段观测和动作还必须匹配preflight。任何检查失败自动停止，保留诊断。

输出目录：`/data/pxchen/PACT-WAM/evaluate_results/fastwam_guidance789_ar2_seed7_six_gripperfix_20261021`

nohup日志：`/data/pxchen/PACT-WAM/guidance_seed7_six_gripperfix_20261021_nohup.log`

GPU6；唯一输出目录、launcher.lock、源码快照与校验值、逐任务结果及视频。旧guidance的1/6结果只作历史记录，不将其作为严格匹配输入的因果对照。

启动：北京时间2026-10-21 14:49，launcher PID1698337，worker PID1698692。14:53:10确认企稳：所有复现和夹爪检查通过，task151已完成11次正式replan（约3秒/次），两个进程均忽略SIGHUP。预计北京时间15:30–15:45完成；取决于任务提前成功与视频保存耗时。
