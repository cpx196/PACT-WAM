#!/usr/bin/env bash
set -uo pipefail

cd /data/pxchen/PACT-WAM
source scripts/local_libero_env.sh
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

output_root=/data/pxchen/PACT-WAM/evaluate_results/trigger_probe_long36_failures64_shift1_20260922
task_root=/data/pxchen/PACT-WAM/evaluate_results/long36_failure_task_lists
mkdir -p "$output_root"
echo $$ > "$output_root/launcher.pid"

run_seed() {
    local seed=$1
    local gpu=$2
    local task_file="$task_root/long36_control_failures_seed${seed}.txt"
    local run_dir="$output_root/seed_${seed}"
    mkdir -p "$run_dir"
    echo "[$(date '+%F %T')] START seed=$seed gpu=$gpu" | tee -a "$output_root/progress.log"

    CUDA_VISIBLE_DEVICES="$gpu" MUJOCO_EGL_DEVICE_ID="$gpu" \
        "$FASTWAM_PYTHON" experiments/libero/run_libero_manager.py \
        task=libero_optional_idm_2cam224_1e-4 \
        "ckpt=$FASTWAM_CHECKPOINT" \
        "EVALUATION.dataset_stats_path=$FASTWAM_DATASET_STATS" \
        "EVALUATION.output_dir=$run_dir" \
        "MULTIRUN.task_file=$task_file" \
        MULTIRUN.num_gpus=1 \
        EVALUATION.num_trials=1 \
        EVALUATION.replan_steps=8 \
        EVALUATION.num_inference_steps=10 \
        EVALUATION.compile_action_infer=false \
        EVALUATION.visualize_future_video=true \
        EVALUATION.offload_text_encoder=true \
        EVALUATION.action_infer_mode=idm \
        EVALUATION.video_sigma_shift=1.0 \
        EVALUATION.action_sigma_shift=1.0 \
        EVALUATION.sigma_shift=null \
        EVALUATION.vjepa2_ac.enabled=false \
        EVALUATION.vjepa2_ac.guidance.enabled=false \
        EVALUATION.vjepa2_ac.camera.preset=libero_default \
        EVALUATION.vjepa2_ac.camera.position=null \
        EVALUATION.vjepa2_ac.camera.quaternion=null \
        EVALUATION.vjepa2_ac.camera.fovy=null \
        EVALUATION.vjepa2_ac.camera.image_rotation_degrees=180 \
        EVALUATION.trigger_probe.enabled=true \
        EVALUATION.trigger_probe.ac_steps=8 \
        "EVALUATION.vjepa2_ac.checkpoint_path=$VJEPA2_CHECKPOINT" \
        "EVALUATION.vjepa2_ac.repo_path=$VJEPA2_REPO" \
        EVALUATION.vjepa2_ac.dtype=float32 \
        model.load_text_encoder=true \
        model.redirect_common_files=false \
        model.skip_dit_load_from_pretrain=true \
        "seed=$seed" \
        > "$run_dir/run.log" 2>&1
    local status=$?
    echo "[$(date '+%F %T')] END seed=$seed gpu=$gpu status=$status" | tee -a "$output_root/progress.log"
    return "$status"
}

overall_status=0
run_seed 7 3 & p0=$!
run_seed 27 7 & p1=$!
wait "$p0" || overall_status=1
wait "$p1" || overall_status=1

if [[ "$overall_status" -eq 0 ]]; then
    run_seed 17 3 & p0=$!
    run_seed 37 7 & p1=$!
    wait "$p0" || overall_status=1
    wait "$p1" || overall_status=1
fi

echo "[$(date '+%F %T')] FINISHED status=$overall_status" | tee -a "$output_root/completion.log"
exit "$overall_status"
