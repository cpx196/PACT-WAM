# Long-horizon harm diagnostic (2026-09-28)

## Evidence and limits

The frozen first 600 paired long800 episodes contain 29 harm and 29 rescue.
All 7,656 logged local corrections in those harm episodes reduce their local
JEPA objective. Median relative local decreases: harm 0.0338616%, rescue
0.0327846%. These are percentages, not absolute loss changes. Median correction
RMS: harm 0.00313172, rescue 0.00310131. Local descent is not a validated task
success criterion. This alone does not identify the cause of harm.

All replans use guidance in the original long800 experiment, so binary trigger
ON/OFF oscillation cannot explain this particular comparison. Current/future
JEPA images both use the rot180 convention matching the predictor checkpoint.
An orientation mismatch is not shown in the current settings.

## Fixed diagnostic cohort

29 harm + 29 rescue + 14 stable successes = 72 tasks, interleaved by label.
These are selected diagnostic cases, NOT an unbiased evaluation set.
Single rollout seed 7, initial state 0. Task-list SHA256:
`89f3f0d742906a7fe733a124b73ecc67caf32ccdd72c080edae7632b6685c988`.
Original 4x rollout durations sum to 6.79 hours for this cohort.

## Variants

| GPU | Group | Change from existing experiment |
|---|---|---|
| 3 | guidance1x | raw step size 1.0 instead of 4.0 |
| 4 | guidance2x | raw step size 2.0 instead of 4.0 |
| 7 | guidance4x_protected_gripper | zero direct gradient on dimension 7 AND restore same-state no-guidance final gripper |

The gripper protection requires a same-state no-guidance action pass on every
replan; this is a diagnostic cost, not a claimed latency-free optimization.
Masking alone does not prevent denoising from changing the final gripper via
cross-dimensional interactions. Restoring the baseline command guarantees the
same gripper decision at that state, not an identical future trajectory.

Unchanged: FastWAM optional-IDM two-camera checkpoint BF16; frozen JEPA encoder,
LIBERO90 rot180 step2000 predictor FP32; both JEPA image streams inverted;
shift 1/1; 10 denoise steps; correction after 7/8/9; RMS cap 0.02; AC steps 2;
8 executed actions/replan; max 700 + 30 wait; no trigger; no action compilation.
FastWAM checkpoint: checkpoints/fastwam/libero_optional_idm_2cam224.pt.
JEPA: checkpoints/vjepa2-ac-libero90-rot180-step2000-inference.pt.

## Paired telemetry and decision criteria

1x/2x: first four replans and every fourth replan. Protected gripper: all replans.
Same explicit seed and same precomputed video latents for baseline/guided passes.
Record final output JEPA energies, 7D action changes, local corrections, BF16
zero-update fraction and gripper threshold crossings. These compare actions at
the guided trajectory's state, NOT the independent control trajectory.

Measure separately: original harms recovered, original rescues retained, and
new failures among stable successes. Do not select on aggregate success alone.
Any promising variant needs a held-out paired evaluation before scaling up.
No local surrogate gate can guarantee zero harm in the true environment.

## Operations

Remote output: evaluate_results/harm_diagnostic_20260928.
nohup + setsid launcher scripts/launch_harm_diagnostic.sh. Independent workers,
independent task queues; existing long800 production entrypoints untouched.
Restart launcher skips completed task result files. Startup configuration-path
error logs retained in each group's startup_config_error_logs; no tasks completed
in that failed attempt. Absolute-path Hydra config smoke test passed afterwards.
Summarize with scripts/summarize_harm_diagnostic.py. Expected 7–10 hours from
successful startup, subject to failures and shared-server load.

## Update: confirmed posture-coordinate inconsistency

LIBERO create_dataset.py stores obs/ee_states orientation as quaternion-derived
axis-angle (rotvec). Our finetune loader passes those three values unchanged
to LiberoACAdapter.convert, which assumes Euler XYZ. Online state_from_observation
instead correctly converts quaternion to Euler XYZ. Thus the predictor sees
different initial pose coordinates during training and evaluation. Subsequent
synthetic state integration during training is also affected by the initial
misinterpretation. This is a confirmed input-contract bug, not yet a demonstrated
explanation for every harm.

Actual training-data example: rotvec [3.12978233, 0.02702689, -0.18627974],
equivalent Euler [3.13643636, 0.11894003, 0.01696334].
Canonical repair: convert training rotvec to Euler BEFORE building the initial
AC state, then retrain the predictor; keep online adapter canonical. Do not
silently call a checkpoint-compatibility workaround the canonical repair.

Pilot observations: original harm task2455 succeeds at 1x and 2x, but still fails
at 4x with the gripper protected. No final-loss rise in its 88 protected-gripper
replans. This single task does not establish generalization, but gripper alone
does not explain this case. 2x also retains original rescue task759.

GPU7 protected-gripper queue intentionally stopped after task2455 to prioritize
the coordinate inconsistency. Task759 was in progress and requeued; do not count
it as a completed failure. GPU7 now reserved for a separate 18-task pilot
guidance4x_checkpoint_state_compat (first 6 harm + 6 rescue + 6 stable successes).
This uses the old checkpoint and mirrors its historical rotvec-as-Euler input
at inference to isolate training/evaluation inconsistency. It is a diagnostic
compatibility test, not a semantically correct final production pipeline.
GPU3/4 1x/2x ablations continue. Existing long800 remains unchanged.

Further pilot: original rescue task759 fails at 1x but succeeds at 2x. Stable
success task2120 succeeds at 2x. Thus simply minimizing correction strength can
lose rescue; 2x is an early candidate, not yet an established best parameter.

Canonical corrected training entrypoint is now separately saved as
scripts/train_vjepa2_ac_libero90_euler_fixed.py. Its CPU smoke test verifies that
the fixed training state and quaternion-derived online Euler state agree to
1e-6 on the example above. Historical training script/checkpoints and ongoing
800 evaluation are unchanged. No retraining has been launched yet.

Read-only LIBERO90 audit: demo_0, eight evenly spaced states per each of 90 files
(720 total). Misinterpreting the rotvec as Euler gives physical rotation error
median 20.71 degrees, p75 49.51, p95 117.72. These describe the state-coordinate
bug, not measured robot execution error or a causal attribution of harm.
Audit data saved as eef_orientation_audit.json. State-compatible pilot entered
rollout at 16:53 and wrote valid paired telemetry; expected approximately
1.5–2.5 hours for 18 tasks (original 4x duration sum 1.45 hours), depending on
changed outcomes and server contention. Other two variants still target 72 tasks.

## STOPPED at user request

The user restricted further work to small-scale tests and prohibited extended
three-GPU occupation. All diagnostic launchers, managers and workers on GPUs
3/4/7 were terminated; existing long800 workers on GPUs1/2 were preserved.
Completed results, partial telemetry, videos and scripts remain available.
The earlier 72/18-task queues are cancelled, not scheduled for automatic resume.
Do not restart them. No new GPU test is currently authorized to start immediately;
first agree a small task count, card count and wall-time budget with the user.
