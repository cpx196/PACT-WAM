#!/usr/bin/env bash
set -euo pipefail
export CUDA_VISIBLE_DEVICES=0 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PILOT_OUT=/data/pxchen/PACT-WAM/artifacts/predictor21_joint31_pilot100_bs16_20261011
export ACTION_STEPS=31
export ACTION_SUPPLEMENT="$PILOT_OUT/actions31.pt"
script_dir=/data/pxchen/PACT-WAM/artifacts/predictor2.1ac1009
python_bin=/data/pxchen/envs/jepa-wam/bin/python
trap 'echo PIPELINE_FAILED stage=$stage code=$? date="$(date -Is)"' ERR
stage=preparation
"$python_bin" -u "$script_dir/prepare_actions31.py"
stage=training
exec "$python_bin" -u "$script_dir/pilot100_joint_predictor.py"
