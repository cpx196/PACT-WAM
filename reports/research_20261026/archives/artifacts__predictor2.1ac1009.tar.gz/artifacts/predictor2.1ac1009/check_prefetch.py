import torch, numpy as np, h5py,json
import torch.nn.functional as F
from torchvision.transforms.functional import resize
from torchvision.transforms import InterpolationMode
from benchmark_cache import DATA,CKPT,ROOT
from benchmark_prefetch import Groups
from prismatic.models.backbones.vision.vjepa_vit import VJEPA21ViTBackbone
torch.set_num_threads(4)
item=torch.load(ROOT/'tokens/00000.pt',weights_only=False);r=item['row'];t=r['t']
with h5py.File(DATA/r['task_file'],'r') as f:
    g=f['data'][r['demo']];raw=np.stack([g['obs/agentview_rgb'][i] for i in [t-8,t,t,t+4,t+4,t+8]])
x=torch.from_numpy(np.ascontiguousarray(np.rot90(raw,2,axes=(1,2)))).permute(0,3,1,2)
x=resize(x,[384,384],InterpolationMode.BICUBIC,antialias=True).float()/255
x=(x-x.new_tensor([.485,.456,.406])[None,:,None,None])/x.new_tensor([.229,.224,.225])[None,:,None,None]
group=Groups([[(0,r)]])[0];y=group['frames'].float()/255
y=(y-y.new_tensor([.485,.456,.406])[None,:,None,None])/y.new_tensor([.229,.224,.225])[None,:,None,None]
y=y[group['pair_frames']].reshape(6,3,384,384)
print('PIXELS',torch.max(abs(x-y)).item(),'BF16',torch.max(abs(x.bfloat16()-y.bfloat16())).item(),flush=True)
model=VJEPA21ViTBackbone('vjepa2_1-vit-l-384px','resize-naive',checkpoint_path=CKPT).cuda().eval()
def enc(x,repeat,inside):
    with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
        z=model.encode_pair(x.reshape(3,2,3,384,384).repeat(repeat,1,1,1,1).cuda()).reshape(-1,576,1024)
        if inside:z=F.layer_norm(z.float(),(1024,)).bfloat16()
    if not inside:z=F.layer_norm(z.float(),(1024,)).bfloat16()
    return z[:3].cpu()
a=enc(x,4,False);b=enc(y,1,True);c=enc(y,1,False)
for name,z in [('baseline_repeat4',a),('unique_inside',b),('unique_outside',c)]:
    d=abs(z.float()-item['latents'].float());print(name,d.mean().item(),d.max().item(),flush=True)
print('AB',abs(a.float()-b.float()).mean().item(),'AC',abs(a.float()-c.float()).mean().item(),flush=True)
