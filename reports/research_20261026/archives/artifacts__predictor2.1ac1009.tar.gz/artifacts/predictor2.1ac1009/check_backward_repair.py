"""Verify alternate checkpoint execution on the exact previous failure batch."""
import os,json,time
from pathlib import Path
import numpy as np,torch
from pilot100_joint_predictor import CacheDataset,JointPredictor,DATA

OUT=Path(os.environ['REPAIR_OUT']);OUT.mkdir(parents=True,exist_ok=True)
torch.set_num_threads(1);torch.set_num_interop_threads(1)
torch.manual_seed(7)
dataset=CacheDataset('train');per_epoch=(len(dataset)+15)//16
failure_step=3967;epoch=(failure_step-1)//per_epoch;batch_id=(failure_step-1)%per_epoch
order=np.random.default_rng(7+epoch).permutation(len(dataset))
indices=order[batch_id*16:(batch_id+1)*16]
samples=[dataset[int(i)] for i in indices]
b={k:torch.stack([s[k] for s in samples]).cuda() for k in samples[0]}
stats=json.loads((DATA/'train_only_stats.json').read_text())
for key,name in [('raw_actions','action'),('state','state')]:
    b[key]=(b[key]-b[key].new_tensor(stats[name]['mean']))/b[key].new_tensor(stats[name]['std']).clamp_min(1e-6)
model=JointPredictor().cuda().train()
payload=torch.load(os.environ['RESUME_CHECKPOINT'],map_location='cpu',weights_only=False,mmap=True)
model.load_state_dict(payload['model']);del payload
records=[];reference={};reference_output=None
for mode in ['nonreentrant','reentrant']:
    os.environ['CHECKPOINT_MODE']=mode;model.zero_grad(set_to_none=True);started=time.time()
    with torch.autocast('cuda',dtype=torch.bfloat16):p=model(b['current_latent'],b['raw_actions'],b['state'])
    loss=(p.float()-b['joint_target']).abs().mean()
    with torch.autograd.set_multithreading_enabled(False):loss.backward()
    torch.cuda.synchronize();assert torch.isfinite(loss)
    gradients={n:p.grad.detach().cpu().clone() for n,p in model.named_parameters() if p.grad is not None}
    assert all(torch.isfinite(g).all() for g in gradients.values())
    if not reference:
        reference=gradients;reference_output=p.detach().float().cpu()
        differences={}
    else:
        assert gradients.keys()==reference.keys()
        maximum=max(float((g-reference[n]).abs().max()) for n,g in gradients.items())
        relative=(sum(float((g-reference[n]).square().sum()) for n,g in gradients.items())/
                  max(sum(float(g.square().sum()) for g in reference.values()),1e-30))**.5
        error=float((p.detach().float().cpu()-reference_output).abs().max())
        # BF16 recomputation can change gradient accumulation rounding;
        # require identical outputs and <1% global relative gradient error.
        assert error==0 and relative<.01,(error,maximum,relative)
        differences=dict(output_max_abs=error,gradient_max_abs=maximum,gradient_relative_l2=relative)
    row=dict(mode=mode,loss=float(loss),elapsed_s=time.time()-started,**differences)
    records.append(row);print('REPAIR_CHECK',json.dumps(row),flush=True)
    del gradients,p
report=dict(status='passed',failure_batch_step=failure_step,batch_size=len(indices),
    single_thread_backward=True,records=records,peak_allocated_mib=torch.cuda.max_memory_allocated()/2**20)
(OUT/'summary.json').write_text(json.dumps(report,indent=2));print('REPAIR_PASSED',json.dumps(report),flush=True)
