"""Exact-window prefetch benchmark, optionally sharded across GPUs."""
import argparse, json, time, os
from pathlib import Path
import h5py
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from torchvision.transforms.functional import resize
from torchvision.transforms import InterpolationMode
from benchmark_cache import DATA, MANIFEST, CKPT

class Groups(Dataset):
    def __init__(self,groups): self.groups=groups
    def __len__(self): return len(self.groups)
    def __getitem__(self,k):
        torch.set_num_threads(1)
        group=self.groups[k];rows=[r for _,r in group]
        frame_ids=sorted({(r['demo'],v) for r in rows for v in [r['t']-8,r['t'],r['t']+4,r['t']+8]})
        with h5py.File(DATA/rows[0]['task_file'],'r') as f:
            frames=np.stack([f['data'][demo]['obs/agentview_rgb'][i] for demo,i in frame_ids])
            actions=[np.asarray(f['data'][r['demo']]['actions'][r['t']:r['t']+8]) for r in rows]
            states=[np.asarray(f['data'][r['demo']]['obs/ee_states'][r['t']]) for r in rows]
        frames=np.ascontiguousarray(np.rot90(frames,2,axes=(1,2)))
        frames=resize(torch.from_numpy(frames).permute(0,3,1,2),[384,384],InterpolationMode.BICUBIC,antialias=True)
        pairs=sorted({(r['demo'],a,b) for r in rows for a,b in [(r['t']-8,r['t']),(r['t'],r['t']+4),(r['t']+4,r['t']+8)]})
        fi={v:i for i,v in enumerate(frame_ids)};pi={v:i for i,v in enumerate(pairs)}
        pair_frames=torch.tensor([[fi[(demo,a)],fi[(demo,b)]] for demo,a,b in pairs])
        window_pairs=torch.tensor([[pi[(r['demo'],r['t']-8,r['t'])],pi[(r['demo'],r['t'],r['t']+4)],pi[(r['demo'],r['t']+4,r['t']+8)]] for r in rows])
        return {'frames':frames,'pair_frames':pair_frames,'window_pairs':window_pairs,'rows':rows,'ids':[i for i,_ in group], 'actions':actions,'states':states,'unique_frames':len(frame_ids),'unique_pairs':len(pairs)}

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--shard',type=int,default=0);p.add_argument('--shards',type=int,default=1);args=p.parse_args()
    out=args.out/f'shard{args.shard}';out.mkdir(parents=True,exist_ok=True)
    if (out/'tokens').exists(): raise RuntimeError('Refuse duplicate output')
    (out/'tokens').mkdir()
    torch.set_num_threads(4)
    train=[r for r in json.loads(MANIFEST.read_text()) if r['split']=='train']
    rows=[train[i] for i in np.linspace(0,len(train)-1,508,dtype=int)][8:]
    buckets={}
    for i,r in enumerate(rows):buckets.setdefault(r['task_file'],[]).append((i,r))
    groups=[]
    for key in sorted(buckets):
        rs=sorted(buckets[key],key=lambda x:(x[1]['demo'],x[1]['t']))
        groups.extend(rs[j:j+32] for j in range(0,len(rs),32))
    groups=groups[args.shard::args.shards]
    from prismatic.models.backbones.vision.vjepa_vit import VJEPA21ViTBackbone
    ts=time.perf_counter();model=VJEPA21ViTBackbone('vjepa2_1-vit-l-384px','resize-naive',checkpoint_path=CKPT).cuda().eval();torch.cuda.synchronize();load=time.perf_counter()-ts
    # Explicit spawn avoids forking a CUDA-initialized parent.
    loader=DataLoader(Groups(groups),batch_size=None,num_workers=4,prefetch_factor=2,multiprocessing_context='spawn')
    def encode(item):
        x=item['frames'].float()/255
        x=(x-x.new_tensor([.485,.456,.406])[None,:,None,None])/x.new_tensor([.229,.224,.225])[None,:,None,None]
        x=x.cuda()
        parts=[]
        with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
            for idx in item['pair_frames'].split(12):
                pairs=x[idx.cuda()]
                # BF16 kernels vary with batch shape. Keep baseline's 12-pair
                # shape, padding only the last partial batch and dropping it.
                if len(idx)<12:pairs=torch.cat((pairs,pairs[-1:].expand(12-len(idx),-1,-1,-1,-1)))
                z=model.encode_pair(pairs).reshape(12,576,1024)[:len(idx)]
                parts.append(F.layer_norm(z.float(),(1024,)).to(torch.bfloat16).cpu())
        return torch.cat(parts)[item['window_pairs']]
    warm=Groups(groups)[0];encode(warm);torch.cuda.synchronize()
    start=time.perf_counter();measurement_start_unix=time.time();wait_s=enc_s=write_s=0.;count=uf=up=0;maxdiff=0.;mean_diff=[]
    it=iter(loader)
    while True:
        ts=time.perf_counter()
        try:item=next(it)
        except StopIteration:break
        wait_s+=time.perf_counter()-ts
        ts=time.perf_counter();z=encode(item);torch.cuda.synchronize();enc_s+=time.perf_counter()-ts
        assert torch.isfinite(z).all()
        ts=time.perf_counter()
        for j,i in enumerate(item['ids']):
            torch.save({'row':item['rows'][j],'latents':z[j].clone(),'raw_actions':item['actions'][j],'raw_ee_state':item['states'][j]},out/'tokens'/f'{i:05d}.pt')
        write_s+=time.perf_counter()-ts
        count+=len(item['ids']);uf+=item['unique_frames'];up+=item['unique_pairs']
        if count%50==0:print(json.dumps({'count':count,'elapsed':time.perf_counter()-start}),flush=True)
    ts=time.perf_counter()
    for path in (out/'tokens').glob('*.pt'):
        with path.open('rb') as f:os.fsync(f.fileno())
    flush_s=time.perf_counter()-ts;elapsed=time.perf_counter()-start;measurement_end_unix=time.time()
    # Validate against old baseline outside measured region; BF16 batching tolerance.
    checked=0
    for path in sorted((out/'tokens').glob('*.pt'))[::max(1,count//10)]:
        baseline=Path('/data/pxchen/PACT-WAM/artifacts/predictor2.1ac1009/throughput500/tokens')/path.name
        if baseline.exists():
            a=torch.load(path,weights_only=False);b=torch.load(baseline,weights_only=False)
            assert a['row']==b['row']
            d=(a['latents'].float()-b['latents'].float()).abs();maxdiff=max(maxdiff,d.max().item());mean_diff.append(d.mean().item());checked+=1
    if mean_diff:assert max(mean_diff)<.002,mean_diff
    result={'windows':count,'load_s':load,'measurement_start_unix':measurement_start_unix,'measurement_end_unix':measurement_end_unix,'elapsed_s':elapsed,'windows_per_s':count/elapsed,'wait_read_preprocess_s':wait_s,'encode_s':enc_s,'write_s':write_s,'flush_s':flush_s,'unique_frames_read':uf,'unoptimized_frame_reads':count*6,'unique_pairs_encoded':up,'unoptimized_pairs':count*3,'peak_allocated_mib':torch.cuda.max_memory_allocated()/2**20,'checked_windows':checked,'max_abs_difference':maxdiff,'max_mean_abs_difference':max(mean_diff,default=0),'workers_per_gpu':4,'gpu':os.environ.get('CUDA_VISIBLE_DEVICES'),'bytes':sum(f.stat().st_size for f in (out/'tokens').glob('*.pt')),'note':'identical 500 LIBERO10 baseline windows; no training; loading, warmup and verification excluded'}
    (out/'summary.json').write_text(json.dumps(result,indent=2));print('COMPLETE',json.dumps(result),flush=True)

if __name__=='__main__':main()
