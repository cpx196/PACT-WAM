"""Single-GPU native V-JEPA2.1 cache; raw commands and measured state."""
import os, sys, json, time, types
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import h5py
import numpy as np
import torch
from PIL import Image

sys.path.insert(0, '/data/pxchen/JEPA_WAM')
# Load the unchanged encoder files without importing unrelated policy/action heads.
for package in ['prismatic', 'prismatic.models', 'prismatic.models.backbones', 'prismatic.models.backbones.vision']:
    module = types.ModuleType(package)
    module.__path__ = ['/data/pxchen/JEPA_WAM/' + package.replace('.', '/')]
    sys.modules[package] = module
from prismatic.models.backbones.vision.vjepa_vit import VJEPA21ViTBackbone

OUT = Path('/data/pxchen/PACT-WAM/artifacts/predictor21_joint20_stride20_20261011')
CKPT = '/data/pxchen/PACT-WAM/checkpoints/jepa_wam_assets_20261009/vjepa2/vjepa2_1_vitl_dist_vitG_384.pt'
ROOTS = [('libero90', '/data/pxchen/libero-suite/LIBERO/datasets/libero_90'),
         ('libero10', '/data/pxchen/PACT-WAM/artifacts/libero10_guidance_backward_smoke_20260929/data/libero_10')]

def atomic_json(name, obj):
    path = OUT/name
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(obj, indent=2))
    os.replace(temp, path)

def load_trajectory(job):
    suite, path, demo, split = job
    with h5py.File(path, 'r') as f:
        g = f['data'][demo]; obs = g['obs']
        a = np.asarray(g['actions'], dtype=np.float32)
        ee = np.asarray(obs['ee_states'], dtype=np.float32)
        pos = np.asarray(obs['ee_pos'], dtype=np.float32)
        ori = np.asarray(obs['ee_ori'], dtype=np.float32)
        grip = np.asarray(obs['gripper_states'], dtype=np.float32)
        rgb = obs['agentview_rgb']
        assert len(a) == len(ee) == len(grip) == len(rgb)
        assert a.shape[1] == 7 and ee.shape[1] == 6 and grip.shape[1] == 2
        assert np.allclose(ee[:,:3], pos, atol=1e-6)
        assert np.allclose(ee[:,3:], ori, atol=1e-6)
        starts = np.arange(0, max(0,len(a)-31), 20)
        ids = sorted(set(starts.tolist()+ (starts+31).tolist()))
        images = {i:np.asarray(rgb[i]) for i in ids}
        state = np.concatenate([ee,grip], axis=1)
        assert np.isfinite(a).all() and np.isfinite(state).all()
        return job, starts, images, a, state

def main():
    if (OUT/'progress.json').exists() or (OUT/'summary.json').exists():
        raise RuntimeError('Output already exists; refusing duplicate task')
    OUT.mkdir(parents=True, exist_ok=True); (OUT/'shards').mkdir(exist_ok=True)
    torch.set_num_threads(4)
    contract = dict(stride=20, action_length=20, target_offset=31, view='primary',
        state='XYZ + observed rotation-vector + two finger joint positions',
        actions='raw LIBERO executable commands; no integration or rotation conversion',
        orientation='raw HDF5 rot180 correction; once for both frames',
        image_transform='native VJEPA21 PIL bicubic384 + ImageNet normalization',
        latent='native final output; no extra layer norm; BF16 storage',
        split='demo index divisible by10 validation; all other demos training',
        encoder=CKPT, output_shape=[576,1024])
    atomic_json('contract.json',contract)
    jobs=[]
    for suite,root in ROOTS:
        for path in sorted(Path(root).glob('*.hdf5')):
            with h5py.File(path,'r') as f:
                names=sorted([k for k in f['data'] if k.startswith('demo_')],key=lambda k:int(k.split('_')[-1]))
            jobs.extend((suite,str(path),name,'val' if i%10==0 else 'train') for i,name in enumerate(names))
    model=VJEPA21ViTBackbone('vjepa2_1-vit-l-384px','resize-naive',checkpoint_path=CKPT).cuda().eval()
    model.requires_grad_(False)
    started=time.time(); count=0; index=[]; split_counts={'train':0,'val':0}
    norm={k:dict(n=0,sum=np.zeros(d),sum_sq=np.zeros(d)) for k,d in [('state',8),('action',7)]}
    def transform(arr):
        return model.image_transform(Image.fromarray(np.ascontiguousarray(arr[::-1,::-1])).convert('RGB'))
    def encode(x,y):
        with torch.inference_mode(), torch.autocast('cuda',dtype=torch.bfloat16):
            current=model(x.cuda()).cpu().contiguous()
            joint=model.encode_pair(torch.stack([x,y],dim=1).cuda()).reshape(len(x),576,1024).cpu().contiguous()
        assert current.shape==joint.shape==(len(x),576,1024)
        assert torch.isfinite(current).all() and torch.isfinite(joint).all()
        return current,joint
    # Bounded trajectory prefetch avoids loading the complete dataset in memory.
    with ThreadPoolExecutor(max_workers=4) as pool:
        pending={i:pool.submit(load_trajectory,jobs[i]) for i in range(min(4,len(jobs)))}
        for ji,job in enumerate(jobs):
            _,starts,images,a,state=pending.pop(ji).result()
            if ji+4<len(jobs): pending[ji+4]=pool.submit(load_trajectory,jobs[ji+4])
            if not len(starts): continue
            cur=[];target=[]
            # Match online batch=1 exactly: native encoder showed a large
            # batch-vs-single mismatch during the first smoke; do not cache it.
            for b in range(0,len(starts),1):
                ts=starts[b:b+1]
                x=torch.stack([transform(images[int(t)]) for t in ts])
                y=torch.stack([transform(images[int(t)+31]) for t in ts])
                z,j=encode(x,y)
                if count==0 and b==0:
                    z1,j1=encode(x[:1],y[:1])
                    error=max((z[:1].float()-z1.float()).abs().max().item(),(j[:1].float()-j1.float()).abs().max().item())
                    # Batch size can change BF16 numerics slightly; reject large mismatch.
                    assert error<0.25,error
                    atomic_json('smoke.json',dict(status='passed',finite=True,shape=list(z.shape),batch_vs_single_max_abs=error))
                    print('SMOKE_PASSED',error,flush=True)
                cur.append(z);target.append(j)
            actions=np.stack([a[t:t+20] for t in starts]); states=state[starts]
            shard=OUT/'shards'/f'{ji:05d}.pt'; tmp=shard.with_suffix('.tmp')
            torch.save(dict(current_latent=torch.cat(cur),joint_target=torch.cat(target),
                raw_actions=torch.from_numpy(actions),state=torch.from_numpy(states),
                starts=torch.from_numpy(starts),suite=job[0],source=job[1],demo=job[2],split=job[3]),tmp)
            os.replace(tmp,shard)
            n=len(starts);count+=n;split_counts[job[3]]+=n
            index.append(dict(file=str(shard.relative_to(OUT)),windows=n,suite=job[0],task=Path(job[1]).stem,demo=job[2],split=job[3]))
            if job[3]=='train':
                for key,vals in [('state',states),('action',actions.reshape(-1,7))]:
                    vals=vals.astype(np.float64);norm[key]['n']+=len(vals)
                    norm[key]['sum']+=vals.sum(0);norm[key]['sum_sq']+=(vals**2).sum(0)
            if ji%10==0 or count>=500 and not (OUT/'pilot500.json').exists():
                elapsed=time.time()-started
                progress=dict(windows=count,total_expected=34995,trajectories_done=ji+1,trajectories_total=len(jobs),
                    elapsed_s=elapsed,windows_per_s=count/elapsed,split_counts=split_counts,
                    peak_allocated_mib=torch.cuda.max_memory_allocated()/2**20,
                    peak_reserved_mib=torch.cuda.max_memory_reserved()/2**20,
                    eta_remaining_s=(34995-count)/(count/elapsed))
                atomic_json('progress.json',progress);print('PROGRESS',json.dumps(progress),flush=True)
                if count>=500 and not (OUT/'pilot500.json').exists():atomic_json('pilot500.json',progress)
    assert count==34995 and split_counts=={'train':31495,'val':3500},(count,split_counts)
    stats={}
    for key,v in norm.items():
        mean=v['sum']/v['n']; std=np.sqrt(np.maximum(v['sum_sq']/v['n']-mean**2,0))
        stats[key]=dict(mean=mean.tolist(),std=std.tolist(),count=v['n'])
    atomic_json('train_only_stats.json',stats);atomic_json('index.json',index)
    atomic_json('summary.json',dict(status='complete',windows=count,split_counts=split_counts,
        elapsed_s=time.time()-started,bytes=sum(p.stat().st_size for p in (OUT/'shards').glob('*.pt')),
        peak_allocated_mib=torch.cuda.max_memory_allocated()/2**20,peak_reserved_mib=torch.cuda.max_memory_reserved()/2**20))
    print('CACHE_COMPLETE',count,flush=True)

if __name__=='__main__':
    try: main()
    except Exception as e:
        if OUT.exists():atomic_json('failure.json',dict(error=repr(e),time=time.time()))
        raise
