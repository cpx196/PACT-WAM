# predictor2.1ac1009 — preparation

Status: configuration draft only; no cache generation or training started.

## Verified assets (2026-10-09)

- Raw LIBERO10: `/data/pxchen/PACT-WAM/artifacts/libero10_guidance_backward_smoke_20260929/data/libero_10` (10 HDF5 files, approximately 13 GB).
- Existing demonstration-disjoint split: `/data/pxchen/PACT-WAM/artifacts/libero10_idm_dense_windows_20261004/windows_stride32.json` (historical 450 train / 50 validation demonstrations).
- Encoder: `/data/pxchen/PACT-WAM/checkpoints/jepa_wam_assets_20261009/vjepa2/vjepa2_1_vitl_dist_vitG_384.pt`.
- Official AC implementation: `/data/pxchen/vjepa2`; historical calibrated training implementation: `/data/pxchen/PACT-WAM/scripts/train_vjepa2_ac_libero10_calibrated.py`.
- Intended run root: `/data/pxchen/PACT-WAM/artifacts/predictor2.1ac1009`.

## Proposed experiment

Freeze the official V-JEPA 2.1 distilled ViT-L encoder. Initialize a new frame-causal AC predictor (24 layers, width 1024, 16 heads; actual parameter count to be measured). Do not load the incompatible V-JEPA 2.0 AC predictor or reuse any 2.0 latent cache.

Reuse demonstration split and stride32 sampling indices, not latent contents. Encode context and real future targets again in the same 2.1 space. Use primary camera only initially; preserve all spatial tokens. Proposed common orientation is rot180 for both context and targets, consistent with the historical contract; verify against actual HDF5 and native JEPA-WAM inputs before encoding.

Supervision: normalized latent teacher-forcing L1 plus mean two-step autoregressive rollout L1, equal weights. No ranking, WAM future supervision, IDM, ARB, or online guidance in this experiment. Real future frames are training labels only.

Pilot proposal: 200 optimizer steps, validate/save every 50; AdamW lr=1e-4 (new random predictor, not the old pretrained-predictor fine-tune LR), weight decay=.04, 20-step warmup, gradient clip=1; BF16 autocast with FP32 trainable parameters. Batch size is pending a single-GPU memory smoke. Save optimizer, scheduler, RNG state and full feature/action contract. Formal training length remains undecided until the pilot.

## Required gates before a GPU launch

1. Verify split is disjoint and enumerate usable windows, with future indices inside each demonstration.
2. Match native JEPA-WAM encoder weights, image preprocessing, feature layer and token layout. Its projected future target uses joint encoding of a current/future image pair, not necessarily an independently encoded future image. Decide this target contract before adapting the trainer; do not assume the historical `[t-8,t]`, `[t,t+4]`, `[t+4,t+8]` pair schedule is a drop-in match.
3. Verify primary-view selection and orientation visually for HDF5, context, and targets.
4. Reuse the repaired rotvec-to-Euler / SO(3) composition code, but audit temporal grouping and the train-only response calibration. Historical gains were translation .23483648715373953 and rotation .2206974792204195 with OSC scales .05 and .5; these remain provisional for this new target schedule. Never confuse normalized executable commands with absolute EEF poses.
5. Smoke must verify exact output/target shape, finite gradients, actual parameter count, update after backward, validation, and checkpoint resume. Report clipping and action sensitivity as diagnostics, not extra losses.

Only after these checks should fresh 2.1 caching and the pilot begin. GPU 4 was idle at preparation time, but must be rechecked before allocation. This is a LIBERO-trained AC variant, not an official released 2.1-AC checkpoint or exact reproduction of its DROID experiment.
