"""No compile, no training: validate native equivalence then measure batch1."""
import sys,time,json,copy,traceback
from pathlib import Path
import torch,numpy as np
sys.path.insert(0,'/data/pxchen/PACT-WAM/artifacts/predictor2.1ac1009')
from smoke_joint_predictor import JointPredictor,DATA
from vectorized_ac_attention import enable_vectorized,forward_vectorized
from src.models.utils.modules import ACRoPEAttention
ROOT=Path('/data/pxchen/PACT-WAM/artifacts')
OUT=ROOT/'predictor21_vectorized_no_compile_20261012'
CKPT=ROOT/'predictor21_joint20_train10epoch_bs16_gpu3_20261011/step19690.pt'
def emit(event,**kw):print(json.dumps(dict(event=event,**kw)),flush=True)
def main():
    OUT.mkdir(exist_ok=True)
    if (OUT/'summary.json').exists():raise RuntimeError('Already complete')
    torch.set_num_threads(2);torch.manual_seed(11)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    # FP32 unit tests cover time-major ordering, original A=2 and expanded A=21.
    unit=[]
    with torch.inference_mode():
        for T,A in ((1,21),(2,21),(2,2),(1,0)):
            attn=ACRoPEAttention(128,4,qkv_bias=True,grid_size=4).eval().cuda()
            x=torch.randn(2,T*(A+16),128,device='cuda')
            kw=dict(T=T,H=4,W=4,action_tokens=A)
            ref=attn(x,**kw);out=forward_vectorized(attn,x,**kw)
            error=float((ref-out).abs().max());assert torch.allclose(ref,out,atol=2e-6,rtol=2e-5),(T,A,error)
            unit.append(dict(T=T,action_tokens=A,max_abs=error))
    emit('UNIT_TEST_PASSED',tests=unit)
    original=JointPredictor().eval().requires_grad_(False)
    payload=torch.load(CKPT,map_location='cpu',weights_only=False,mmap=True)
    original.load_state_dict(payload['model'],strict=True);del payload;original.cuda()
    optimized=copy.deepcopy(original);enable_vectorized(optimized)
    assert all(torch.equal(v,optimized.state_dict()[k]) for k,v in original.state_dict().items())
    stats=json.load(open(DATA/'train_only_stats.json'))
    rows=json.load(open(DATA/'index.json'));samples=[]
    for idx in (0,501,2000,3000,4000,4999):
        row=rows[idx];d=torch.load(DATA/row['file'],map_location='cpu',weights_only=False,mmap=True)
        j=0;c=torch.load(ROOT/'jepawam_pw_cache_benchmark100_20261012/000.pt',map_location='cpu',weights_only=False)
        # First test explicitly uses the measured WAM command cache; remaining tests use diverse demonstrations.
        raw=c['wam_action'][None] if idx==0 else d['raw_actions'][j:j+1]
        def norm(v,k):return ((v-torch.tensor(stats[k]['mean']))/torch.tensor(stats[k]['std']).clamp_min(1e-6)).cuda()
        samples.append((d['current_latent'][j:j+1].cuda(),norm(raw,'action'),norm(d['state'][j:j+1],'state'),d['joint_target'][j:j+1].cuda()))
    checks=[];fp32_references=[]
    with torch.inference_mode():
        for precision in ('fp32','bf16'):
            for i,(z,a,s,target) in enumerate(samples):
                with torch.autocast('cuda',dtype=torch.bfloat16,enabled=precision=='bf16'):
                    ref=original(z,a,s).float();out=optimized(z,a,s).float()
                diff=out-ref;rel=float(diff.norm()/ref.norm().clamp_min(1e-8))
                row=dict(precision=precision,sample=i,max_abs=float(diff.abs().max()),mae=float(diff.abs().mean()),relative_l2=rel,
                         original_target_l1=float((ref-target).abs().mean()),optimized_target_l1=float((out-target).abs().mean()))
                checks.append(row);emit('EQUIVALENCE',**row)
                assert bool(torch.isfinite(out).all())
                if precision=='fp32':
                    assert torch.allclose(ref,out,atol=2e-5,rtol=2e-4),row
                    fp32_references.append(ref.clone())
                else:
                    fp32=fp32_references[i]
                    row['native_bf16_vs_fp32_relative_l2']=float((ref-fp32).norm()/fp32.norm())
                    row['vectorized_bf16_vs_fp32_relative_l2']=float((out-fp32).norm()/fp32.norm())
                    emit('BF16_REFERENCE_CHECK',**row)
                    # Replaces an arbitrary max-absolute bound with the native precision error baseline.
                    assert rel<.005,row
                    assert row['vectorized_bf16_vs_fp32_relative_l2']<=1.1*row['native_bf16_vs_fp32_relative_l2'],row
                    assert abs(row['optimized_target_l1']-row['original_target_l1'])<.001,row
        z,a,s,_=samples[0];timings={}
        for name,m in (('original',original),('vectorized',optimized)):
            with torch.autocast('cuda',dtype=torch.bfloat16):
                for _ in range(5):m(z,a,s)
                values=[]
                for _ in range(30):
                    torch.cuda.synchronize();start=time.perf_counter();m(z,a,s);torch.cuda.synchronize();values.append(time.perf_counter()-start)
            timings[name]=dict(mean_ms=float(np.mean(values)*1000),median_ms=float(np.median(values)*1000),p95_ms=float(np.percentile(values,95)*1000))
            emit('TIMING',name=name,**timings[name])
    result=dict(status='passed',compile=False,batch=1,precision='BF16 autocast FP32 weights',unit_tests=unit,equivalence=checks,timings=timings,
                speedup=timings['original']['mean_ms']/timings['vectorized']['mean_ms'],checkpoint=str(CKPT),weights_unchanged=True,
                peak_allocated_mib=torch.cuda.max_memory_allocated()/2**20,peak_reserved_mib=torch.cuda.max_memory_reserved()/2**20)
    (OUT/'summary.json').write_text(json.dumps(result,indent=2));emit('COMPLETE',**{k:v for k,v in result.items() if k not in ('unit_tests','equivalence')})
if __name__=='__main__':
    try:main()
    except Exception:
        OUT.mkdir(exist_ok=True);(OUT/'failure.json').write_text(json.dumps(dict(traceback=traceback.format_exc()),indent=2));raise
