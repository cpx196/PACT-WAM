"""100-step bounded pilot; disjoint trajectories, fixed validation diagnostics."""
import json, time, math, random, os, faulthandler, zipfile, struct
from pathlib import Path
from collections import OrderedDict
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from smoke_joint_predictor import JointPredictor, DATA

OUT=Path(os.environ.get('PILOT_OUT','/data/pxchen/PACT-WAM/artifacts/predictor21_joint20_pilot100_bs16_20261011'))
SUPPLEMENT=None
ACTION_STEPS=int(os.environ.get('ACTION_STEPS','20'))
TOTAL_STEPS=int(os.environ.get('TOTAL_STEPS','100'))
RESUME=os.environ.get('RESUME_CHECKPOINT')
SAVE_EVERY=int(os.environ.get('SAVE_EVERY','25'))
LR_FLOOR=float(os.environ.get('LR_FLOOR','0'))
SINGLE_BACKWARD=os.environ.get('SINGLE_BACKWARD','0')=='1'
DECAY_END=int(os.environ.get('DECAY_END_STEP','5907'))
ANCHOR_DECAY=os.environ.get('ANCHOR_DECAY','0')=='1'
if os.environ.get('ACTION_SUPPLEMENT'):
    SUPPLEMENT=torch.load(os.environ['ACTION_SUPPLEMENT'],map_location='cpu',weights_only=False)

class CacheDataset(Dataset):
    def __init__(self,split):
        rows=[r for r in json.loads((DATA/'index.json').read_text()) if r['split']==split]
        self.items=[(r['file'],j) for r in rows for j in range(r['windows'])]
        self.cache=OrderedDict()
    def __len__(self):return len(self.items)
    def __getitem__(self,i):
        name,j=self.items[i]
        if name not in self.cache:
            # Explicit bounded reads avoid mmap page-fault/readahead amplification
            # observed on this shared filesystem. Existing torch.save uses these
            # four separate FP32 contiguous storages in dictionary order.
            offsets=[]
            with zipfile.ZipFile(DATA/name) as archive, (DATA/name).open('rb') as f:
                for storage in range(4):
                    info=next(x for x in archive.infolist() if x.filename.endswith('/data/'+str(storage)))
                    assert info.compress_type==zipfile.ZIP_STORED
                    f.seek(info.header_offset+26);fn,extra=struct.unpack('<HH',f.read(4))
                    offsets.append(info.header_offset+30+fn+extra)
            self.cache[name]=offsets
            if len(self.cache)>8:self.cache.popitem(last=False)
        self.cache.move_to_end(name)
        result={}
        with (DATA/name).open('rb') as f:
            for offset,key,shape in zip(self.cache[name],('current_latent','joint_target','raw_actions','state'),((576,1024),(576,1024),(20,7),(8,))):
                count=int(np.prod(shape));f.seek(offset+j*count*4);data=f.read(count*4)
                assert len(data)==count*4
                result[key]=torch.from_numpy(np.frombuffer(data,dtype=np.float32).copy().reshape(shape))
        if SUPPLEMENT is not None:
            replacement=SUPPLEMENT['actions'][f'{name}:{j}']
            assert torch.equal(replacement[:20],result['raw_actions'])
            result['raw_actions']=replacement
        return result

def main():
    if (OUT/'metrics.jsonl').exists():raise RuntimeError('Duplicate pilot output')
    OUT.mkdir(parents=True,exist_ok=True)
    faulthandler.enable()
    faulthandler.dump_traceback_later(90,repeat=True)
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    torch.manual_seed(7);np.random.seed(7);random.seed(7)
    assert json.loads((DATA/'summary.json').read_text())['status']=='complete'
    stats=json.loads((DATA/'train_only_stats.json').read_text())
    if SUPPLEMENT is not None:stats['action']=SUPPLEMENT['action_stats']
    train=CacheDataset('train'); val=CacheDataset('val')
    batches=[]
    for epoch in range(math.ceil(TOTAL_STEPS/math.ceil(len(train)/16))):
        epoch_order=np.random.default_rng(7+epoch).permutation(len(train)).tolist()
        batches.extend(epoch_order[i:i+16] for i in range(0,len(train),16))
    batches=batches[:TOTAL_STEPS]
    order=[i for batch in batches for i in batch]
    assert len(batches)==TOTAL_STEPS
    print('PHASE verify_direct_reader',time.time(),flush=True)
    direct=train[order[0]];name,j=train.items[order[0]]
    reference=torch.load(DATA/name,map_location='cpu',weights_only=False,mmap=True)
    assert all(torch.equal(direct[k][:20] if k=='raw_actions' else direct[k],reference[k][j]) for k in direct), 'Storage reader mismatch'
    del reference
    print('DIRECT_READER_VERIFIED exact',flush=True)
    # No forked workers or pinned-memory thread: isolate the stalled original run.
    vids=np.random.default_rng(17).choice(len(val),128,replace=False).tolist()
    val_loader=DataLoader(val,batch_size=16,sampler=vids,num_workers=0,pin_memory=False)
    print('PHASE load_validation',time.time(),flush=True)
    validation=[b for b in val_loader]
    print('PHASE initialize_model',time.time(),flush=True)
    model=JointPredictor(action_steps=ACTION_STEPS).cuda()
    optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=.04)
    # Keep a continuation-compatible three-epoch schedule, not a decay to zero at step100.
    planned_steps=5907;warmup=296
    anchor_step=None;anchor_lr=None
    def multiplier(step):
        if ANCHOR_DECAY and anchor_step is not None and step>=anchor_step:
            phase=min(1.,max(0.,(step-anchor_step)/(DECAY_END-anchor_step)))
            return (LR_FLOOR+(anchor_lr-LR_FLOOR)*.5*(1+math.cos(math.pi*phase)))/1e-4
        if step<warmup:return (step+1)/warmup
        return max(LR_FLOOR/1e-4,.5*(1+math.cos(math.pi*min(1,(step-warmup)/(planned_steps-warmup)))))
    scheduler=torch.optim.lr_scheduler.LambdaLR(optimizer,multiplier)
    start_step=0
    if RESUME:
        payload=torch.load(RESUME,map_location='cpu',weights_only=False)
        previous=payload['config'];start_step=payload['step']
        assert previous.get('action_steps',20)==ACTION_STEPS==20
        assert previous['batch_size']==16 and previous['planned_steps']==planned_steps and previous['warmup']==warmup
        consumed=[i for batch in batches[:start_step] for i in batch]
        assert previous['train_order'][:len(consumed)]==consumed
        assert previous['validation_indices']==vids and start_step<TOTAL_STEPS
        model.load_state_dict(payload['model']);optimizer.load_state_dict(payload['optimizer'])
        scheduler.load_state_dict(payload['scheduler'])
        if ANCHOR_DECAY:
            anchor_step=previous.get('lr_anchor_step') or start_step
            anchor_lr=previous.get('lr_anchor_value') or optimizer.param_groups[0]['lr']
            assert DECAY_END>anchor_step and 0<LR_FLOOR<=anchor_lr
        torch.set_rng_state(payload['torch_rng']);torch.cuda.set_rng_state_all(payload['cuda_rng'])
        np.random.set_state(payload['numpy_rng']);random.setstate(payload['python_rng'])
        del payload
        print('RESUME_VERIFIED',start_step,RESUME,'lr',optimizer.param_groups[0]['lr'],flush=True)
    loader=DataLoader(train,batch_sampler=batches[start_step:],num_workers=0,pin_memory=False)
    config=dict(batch_size=16,steps=TOTAL_STEPS,initialization=RESUME or 'fresh random seed7; not smoke checkpoint',
        parameters=sum(p.numel() for p in model.parameters()),loss='joint latent L1',
        learning_rate=1e-4,weight_decay=.04,planned_steps=planned_steps,warmup=warmup,
        activation_checkpointing=True,validation_windows=128,validation_seed=17,
        checkpoint_steps=sorted(set(range(((start_step//SAVE_EVERY)+1)*SAVE_EVERY,TOTAL_STEPS+1,SAVE_EVERY))|{TOTAL_STEPS}),precision='BF16 autocast; FP32 parameters and cache',
        train_order=order,validation_indices=vids,data_root=str(DATA),num_workers=0,pin_memory=False,cpu_threads=1,
        action_steps=ACTION_STEPS,action_supplement=os.environ.get('ACTION_SUPPLEMENT'),
        save_every=SAVE_EVERY,steps_per_epoch=math.ceil(len(train)/16),
        lr_floor=LR_FLOOR,checkpoint_mode=os.environ.get('CHECKPOINT_MODE','nonreentrant'),
        lr_decay_end=DECAY_END,lr_anchor_step=anchor_step,lr_anchor_value=anchor_lr,
        single_thread_backward=SINGLE_BACKWARD,
        epoch_tail='last batch has 7 windows; no padding or dropped windows')
    (OUT/'config.json').write_text(json.dumps(config,indent=2));print('PILOT_STARTED',json.dumps({k:v for k,v in config.items() if k not in ('train_order','validation_indices')}),flush=True)
    def prepare(batch):
        b={k:v.cuda(non_blocking=True) for k,v in batch.items()}
        for key,name in [('raw_actions','action'),('state','state')]:
            mu=b[key].new_tensor(stats[name]['mean']);std=b[key].new_tensor(stats[name]['std']).clamp_min(1e-6)
            b[key]=(b[key]-mu)/std
        return b
    def forward(b):
        with torch.autocast('cuda',dtype=torch.bfloat16):return model(b['current_latent'],b['raw_actions'],b['state'])
    def emit(row):
        with (OUT/'metrics.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
        print('METRIC',json.dumps(row),flush=True)
    def evaluate(step):
        print('PHASE validation',step,time.time(),flush=True)
        model.eval();totals=dict(normal=0.,shuffled_action=0.,mean_action=0.,copy_current=0.,action_output_change=0.)
        with torch.no_grad():
            for batch in validation:
                b=prepare(batch);target=b['joint_target'];p=forward(b).float()
                totals['normal']+=(p-target).abs().mean().item()
                altered=dict(b);altered['raw_actions']=b['raw_actions'].roll(1,0)
                shuffled=forward(altered).float();totals['shuffled_action']+=(shuffled-target).abs().mean().item()
                totals['action_output_change']+=(shuffled-p).abs().mean().item()
                altered['raw_actions']=torch.zeros_like(b['raw_actions'])
                totals['mean_action']+=(forward(altered).float()-target).abs().mean().item()
                totals['copy_current']+=(b['current_latent']-target).abs().mean().item()
        row=dict(kind='validation',step=step,**{k:v/len(validation) for k,v in totals.items()});emit(row);model.train();return row
    baseline=evaluate(start_step);started=time.time();rows=[];clipped=0
    print('PHASE load_train_batch',start_step+1,time.time(),flush=True)
    for step,batch in enumerate(loader,start_step+1):
        print('PHASE forward',step,time.time(),flush=True)
        ts=time.time();b=prepare(batch);optimizer.zero_grad(set_to_none=True)
        pred=forward(b);assert pred.shape==b['joint_target'].shape==(len(batch['state']),576,1024)
        loss=(pred.float()-b['joint_target']).abs().mean();assert torch.isfinite(loss)
        print('PHASE backward',step,time.time(),flush=True)
        with torch.autograd.set_multithreading_enabled(not SINGLE_BACKWARD):loss.backward()
        norm=float(torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True))
        clipped+=norm>1.;lr=optimizer.param_groups[0]['lr'];optimizer.step();scheduler.step();torch.cuda.synchronize()
        row=dict(kind='train',step=step,loss=float(loss),gradient_norm_before_clip=norm,
            clipped=norm>1.,lr=lr,compute_and_transfer_s=time.time()-ts,elapsed_s=time.time()-started)
        rows.append(row);emit(row)
        if step%SAVE_EVERY==0 or step==TOTAL_STEPS:
            result=evaluate(step)
            path=OUT/f'step{step:04d}.pt'
            print('PHASE save_checkpoint',step,time.time(),flush=True)
            temporary=path.with_suffix('.tmp')
            torch.save(dict(model=model.state_dict(),optimizer=optimizer.state_dict(),scheduler=scheduler.state_dict(),
                step=step,config=config,torch_rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all(),
                numpy_rng=np.random.get_state(),python_rng=random.getstate()),temporary)
            os.replace(temporary,path)
            (OUT/'progress.json').write_text(json.dumps(dict(step=step,validation=result,elapsed_s=time.time()-started),indent=2))
            print('CHECKPOINT_SAVED',str(path),flush=True)
        if step==TOTAL_STEPS:break
        print('PHASE load_train_batch',step+1,time.time(),flush=True)
    assert len(rows)==TOTAL_STEPS-start_step
    summary=dict(status='complete',steps=TOTAL_STEPS,start_step=start_step,baseline_validation=baseline,final_validation=result,
        initial_train_loss=rows[0]['loss'],last_train_loss=rows[-1]['loss'],
        first10_mean_loss=float(np.mean([r['loss'] for r in rows[:10]])),
        last10_mean_loss=float(np.mean([r['loss'] for r in rows[-10:]])),clip_rate=clipped/len(rows),
        mean_step_compute_s=float(np.mean([r['compute_and_transfer_s'] for r in rows])),elapsed_s=time.time()-started,
        peak_allocated_mib=torch.cuda.max_memory_allocated()/2**20,peak_reserved_mib=torch.cuda.max_memory_reserved()/2**20,
        checkpoint=str(OUT/f'step{TOTAL_STEPS:04d}.pt'),note='Pilot only; action-ordering and online utility are not established by latent loss alone.')
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2));print('PILOT_COMPLETE',json.dumps(summary),flush=True)
    faulthandler.cancel_dump_traceback_later()

if __name__=='__main__':
    try:main()
    except Exception as e:
        OUT.mkdir(parents=True,exist_ok=True);(OUT/'failure.json').write_text(json.dumps(dict(error=repr(e))))
        raise
