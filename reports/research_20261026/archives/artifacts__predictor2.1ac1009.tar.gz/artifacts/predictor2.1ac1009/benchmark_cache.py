"""Bounded throughput benchmark; no predictor training or legacy latent reuse."""
import json, time, sys, os
from pathlib import Path
import h5py
import numpy as np
import torch
import torch.nn.functional as F
from torchvision.transforms.functional import resize
from torchvision.transforms import InterpolationMode

ROOT=Path('/data/pxchen/PACT-WAM/artifacts/predictor2.1ac1009/throughput500')
DATA=Path('/data/pxchen/PACT-WAM/artifacts/libero10_guidance_backward_smoke_20260929/data/libero_10')
MANIFEST=Path('/data/pxchen/PACT-WAM/artifacts/libero10_idm_dense_windows_20261004/windows_stride32.json')
CKPT='/data/pxchen/PACT-WAM/checkpoints/jepa_wam_assets_20261009/vjepa2/vjepa2_1_vitl_dist_vitG_384.pt'

def main():
    ROOT.mkdir(parents=True,exist_ok=True)
    if (ROOT/'summary.json').exists() or ((ROOT/'tokens').exists() and any((ROOT/'tokens').iterdir())):
        raise RuntimeError('Refuse duplicate benchmark output')
    (ROOT/'tokens').mkdir(exist_ok=True)
    torch.set_num_threads(4)
    if not torch.cuda.is_available(): raise RuntimeError('CUDA required')
    rows=[r for r in json.loads(MANIFEST.read_text()) if r['split']=='train']
    # Spread across all tasks/demonstrations rather than timing one HDF5 region.
    ids=np.linspace(0,len(rows)-1,508,dtype=int)
    rows=[rows[i] for i in ids]
    from prismatic.models.backbones.vision.vjepa_vit import VJEPA21ViTBackbone
    start=time.perf_counter()
    model=VJEPA21ViTBackbone('vjepa2_1-vit-l-384px','resize-naive',checkpoint_path=CKPT).cuda().eval()
    torch.cuda.synchronize();load_s=time.perf_counter()-start
    handles={}
    def read_batch(rs):
        samples=[];actions=[];states=[]
        for r in rs:
            path=str(DATA/r['task_file'])
            if path not in handles: handles[path]=h5py.File(path,'r')
            g=handles[path]['data'][r['demo']];t=r['t']
            rgb=g['obs/agentview_rgb']
            frames=np.stack([rgb[i] for i in [t-8,t,t,t+4,t+4,t+8]])
            samples.append(np.ascontiguousarray(np.rot90(frames,2,axes=(1,2))))
            actions.append(np.asarray(g['actions'][t:t+8]))
            states.append(np.asarray(g['obs/ee_states'][t]))
        x=torch.from_numpy(np.stack(samples)).permute(0,1,4,2,3).reshape(-1,3,*frames.shape[1:3])
        # Match native PIL resize: interpolate uint8 first, then normalize.
        x=resize(x,[384,384],InterpolationMode.BICUBIC,antialias=True).float()/255
        x=(x-x.new_tensor([.485,.456,.406])[None,:,None,None])/x.new_tensor([.229,.224,.225])[None,:,None,None]
        return x.reshape(len(rs),3,2,3,384,384),actions,states
    def encode(x):
        x=x.reshape(-1,2,3,384,384).cuda()
        with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
            z=model.encode_pair(x)
        # Native encode_pair returns [B,V,T,H,W,D], unlike forward's flat tokens.
        z=z.reshape(x.shape[0],-1,1024)
        assert z.shape[1:]==(576,1024),z.shape
        z=F.layer_norm(z.float(),(1024,)).to(torch.bfloat16).reshape(-1,3,576,1024).cpu()
        assert torch.isfinite(z).all()
        return z
    for j in range(0,8,4): encode(read_batch(rows[j:j+4])[0])
    torch.cuda.synchronize();start=time.perf_counter();read_s=encode_s=write_s=0.;count=0
    for offset in range(8,508,4):
        rs=rows[offset:offset+4];ts=time.perf_counter();x,a,s=read_batch(rs);read_s+=time.perf_counter()-ts
        ts=time.perf_counter();z=encode(x);torch.cuda.synchronize();encode_s+=time.perf_counter()-ts
        ts=time.perf_counter()
        for i,r in enumerate(rs):
            torch.save({'row':r,'latents':z[i].clone(),'raw_actions':a[i],'raw_ee_state':s[i]},ROOT/'tokens'/f'{count+i:05d}.pt')
        write_s+=time.perf_counter()-ts;count+=len(rs)
        if count%100==0: print(json.dumps({'completed':count,'elapsed_s':time.perf_counter()-start}),flush=True)
    # Include deferred writes in end-to-end timing where supported.
    flush_start=time.perf_counter()
    for p in (ROOT/'tokens').glob('*.pt'):
        with p.open('rb') as f: os.fsync(f.fileno())
    flush_s=time.perf_counter()-flush_start
    elapsed=time.perf_counter()-start;size=sum(p.stat().st_size for p in (ROOT/'tokens').glob('*.pt'))
    summary={'windows':count,'batch_windows':4,'model_load_s':load_s,'warmup_windows':8,'read_preprocess_s':read_s,'encode_and_transfer_s':encode_s,'write_s':write_s,'flush_s':flush_s,'elapsed_s':elapsed,'windows_per_s':count/elapsed,'bytes':size,'bytes_per_window':size/count,'estimated_55000_single_gpu_s':elapsed/count*55000,'peak_allocated_mib':torch.cuda.max_memory_allocated()/2**20,'scope':'LIBERO10 only; provisional historical paired schedule, not final mixed90 throughput','contract':'rot180 main view; pair [t-8,t], [t,t+4], [t+4,t+8]; final encoder layer; per-token LN; BF16; uint8 tensor bicubic resize (PIL numerical equivalence pending)'}
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2));print('COMPLETE',json.dumps(summary),flush=True)
    for h in handles.values():h.close()

if __name__=='__main__':main()
