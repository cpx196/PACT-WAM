"""Reuse exact pilot indices and latents; read commands only, no image encoding."""
import json,time,os
from pathlib import Path
from collections import defaultdict
import h5py,numpy as np,torch

DATA=Path('/data/pxchen/PACT-WAM/artifacts/predictor21_joint20_stride20_20261011')
OUT=Path(os.environ['PILOT_OUT'])
ROOTS={'libero90':Path('/data/pxchen/libero-suite/LIBERO/datasets/libero_90'),
       'libero10':Path('/data/pxchen/PACT-WAM/artifacts/libero10_guidance_backward_smoke_20260929/data/libero_10')}
def main():
    OUT.mkdir(parents=True,exist_ok=True)
    path=OUT/'actions31.pt'
    assert not path.exists(),'Refusing duplicate preparation'
    begun=time.time();index=json.loads((DATA/'index.json').read_text())
    selected=set()
    for split,seed,n in [('train',7,1600),('val',17,128)]:
        items=[(r['file'],j) for r in index if r['split']==split for j in range(r['windows'])]
        rng=np.random.default_rng(seed)
        ids=rng.permutation(len(items))[:n] if split=='train' else rng.choice(len(items),n,replace=False)
        selected.update(items[int(i)] for i in ids)
    groups=defaultdict(list)
    for r in index:groups[(r['suite'],r['task'])].append(r)
    actions={};total=0;sums=np.zeros(7);squares=np.zeros(7)
    for (suite,task),rows in groups.items():
        with h5py.File(ROOTS[suite]/(task+'.hdf5'),'r') as f:
            for r in rows:
                a=np.asarray(f['data'][r['demo']]['actions'],dtype=np.float32)
                starts=np.arange(0,max(0,len(a)-31),20)
                assert len(starts)==r['windows'] and np.isfinite(a).all()
                for j,t in enumerate(starts):
                    chunk=np.ascontiguousarray(a[t:t+31]);assert chunk.shape==(31,7)
                    if r['split']=='train':
                        x=chunk.astype(np.float64);total+=len(x);sums+=x.sum(0);squares+=(x*x).sum(0)
                    if (r['file'],j) in selected:
                        actions[f"{r['file']}:{j}"]=torch.from_numpy(chunk.copy())
        print('READ',suite,task,'selected',len(actions),flush=True)
    assert len(actions)==1728
    mu=sums/total;std=np.sqrt(np.maximum(squares/total-mu*mu,0))
    stats=dict(mean=mu.tolist(),std=std.tolist(),count=total)
    torch.save(dict(actions=actions,action_stats=stats),path)
    report=dict(status='complete',selected_windows=len(actions),action_steps=31,
        normalization='all training windows only; no validation',action_stats=stats,
        elapsed_s=time.time()-begun,bytes=path.stat().st_size,latent_reencoded=False)
    (OUT/'preparation.json').write_text(json.dumps(report,indent=2))
    print('PREPARATION_COMPLETE',json.dumps(report),flush=True)
if __name__=='__main__':main()
