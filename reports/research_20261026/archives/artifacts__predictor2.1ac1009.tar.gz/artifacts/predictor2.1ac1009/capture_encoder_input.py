"""One native policy forward; capture the actual vision-encoder input."""
import json,time
from pathlib import Path
import numpy as np
import torch
from PIL import Image
from experiments.robot.libero import run_libero_eval as ev

def main():
    root=Path('/data/pxchen/PACT-WAM/artifacts/predictor2.1ac1009/encoder_orientation');root.mkdir(exist_ok=True)
    assets=Path('/data/pxchen/PACT-WAM/checkpoints/jepa_wam_assets_20261009')
    cfg=ev.GenerateConfig(pretrained_checkpoint=str(assets/'JEPA_WAM/checkpoints/libero/jepavla-qwen25-vjepa-224px+0_5b+mx-libero-90+n1+b32+x7--visual-cosine-projector-allviews--20260723_232305/checkpoints/step-040000-epoch-37-loss=0.0262.pt'),base_vlm=str(assets/'JEPA_WAM/checkpoints/pretrained_vlm/prism-qwen25-vjepa21-vitl-384px+0_5b+stage-finetune+x7'),llm_checkpoint_path=str(assets/'Qwen2.5-0.5B'),vjepa_checkpoint_path=str(assets/'vjepa2/vjepa2_1_vitl_dist_vitG_384.pt'),task_suite_name='libero_10',num_steps_wait=5,seed=7)
    torch.set_num_threads(4);ev.set_seed_everywhere(7)
    model=ev.get_model(cfg);ev._resolve_unnorm_key(cfg,model)
    suite=ev.benchmark.get_benchmark_dict()['libero_10']();task=suite.get_task(365)
    env,instruction=ev.get_libero_env(task,resolution=384)
    captured={}
    def hook(module,args):
        x=args[0].detach().float().cpu();captured['tensor_shape']=list(x.shape)
        assert x.ndim==5 and x.shape[:3]==(2,3,1),x.shape
        mean=x.new_tensor([.485,.456,.406]).view(3,1,1);std=x.new_tensor([.229,.224,.225]).view(3,1,1)
        for i,name in enumerate(['primary','wrist']):
            rgb=((x[i,:,0]*std+mean).clamp(0,1)*255).round().byte().permute(1,2,0).numpy()
            Image.fromarray(rgb).save(root/f'actual_encoder_{name}.png')
        captured['hook_called']=True
    handle=model.vision_backbone.featurizer.register_forward_pre_hook(hook)
    try:
        env.reset();obs=env.set_init_state(suite.get_task_init_states(365)[0])
        for _ in range(5):obs,_,_,_=env.step(ev.get_libero_dummy_action())
        Image.fromarray(obs['agentview_image']).save(root/'simulator_raw_primary.png')
        prepared=ev._prepare_observation(obs)
        Image.fromarray(prepared['full_image']).save(root/'prepared_primary.png')
        torch.cuda.synchronize();start=time.perf_counter()
        actions=ev.get_action(cfg,model,prepared,instruction)
        torch.cuda.synchronize();captured.update(task_id=365,instruction=instruction,action_shape=list(np.asarray(actions).shape),inference_s=time.perf_counter()-start)
        assert captured.get('hook_called') and np.isfinite(actions).all()
        (root/'summary.json').write_text(json.dumps(captured,indent=2));print('CAPTURE_COMPLETE',json.dumps(captured),flush=True)
    finally:handle.remove();env.close()

if __name__=='__main__':main()
