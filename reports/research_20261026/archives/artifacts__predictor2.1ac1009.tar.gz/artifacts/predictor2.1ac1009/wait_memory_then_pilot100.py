"""One lightweight waiter; do not claim/terminate any other user's resource."""
import os, time, subprocess
minimum=16*1024*1024
stable=0;last_log=0
while True:
    values={line.split(':')[0]:int(line.split()[1]) for line in open('/proc/meminfo') if line.startswith(('MemAvailable:','SwapFree:'))}
    available=values['MemAvailable']
    gpu_ok=False
    try:
        result=subprocess.run(['nvidia-smi','-i','0','--query-gpu=memory.used,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10,check=True)
        used,util=map(int,result.stdout.strip().split(','));gpu_ok=used<1000 and util<5
    except Exception:pass
    stable=stable+1 if available>=minimum and gpu_ok else 0
    if time.time()-last_log>300 or stable:
        print('WAIT_RESOURCES',dict(mem_available_gib=round(available/1024**2,2),gpu0_idle=gpu_ok,stable_checks=stable,time=time.time()),flush=True)
        last_log=time.time()
    if stable>=3:
        print('START_FRESH_PILOT100',time.time(),flush=True)
        python='/data/pxchen/envs/jepa-wam/bin/python'
        script='/data/pxchen/PACT-WAM/artifacts/predictor2.1ac1009/pilot100_joint_predictor.py'
        os.execve(python,[python,'-u',script],dict(os.environ))
    time.sleep(20)
