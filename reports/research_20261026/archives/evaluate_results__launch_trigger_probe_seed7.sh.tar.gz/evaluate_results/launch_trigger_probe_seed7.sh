#!/usr/bin/env bash
set -uo pipefail

cd /data/pxchen/PACT-WAM
source scripts/local_libero_env.sh

# Use the original official LIBERO benchmark, not LIBERO-Plus.
export PYTHONPATH="/data/pxchen/libero-suite/LIBERO:/data/pxchen/vjepa2:/data/pxchen/PACT-WAM/src:${PYTHONPATH}"
export LIBERO_CONFIG_PATH=/data/pxchen/PACT-WAM/.libero_official_config
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export CUDA_VISIBLE_DEVICES=3,6,7

output_root=/data/pxchen/PACT-WAM/evaluate_results/trigger_probe_libero10_seed7_shift1_v2_20260921
task_file=/data/pxchen/PACT-WAM/evaluate_results/official_libero10_all.txt
mkdir -p "$output_root"
echo $$ > "$output_root/launcher.pid"

"$FASTWAM_PYTHON" experiments/libero/run_libero_manager.py \
    task=libero_optional_idm_2cam224_1e-4 \
    "ckpt=$FASTWAM_CHECKPOINT" \
    "EVALUATION.dataset_stats_path=$FASTWAM_DATASET_STATS" \
    "EVALUATION.output_dir=$output_root" \
    "MULTIRUN.task_file=$task_file" \
    MULTIRUN.num_gpus=3 \
    EVALUATION.num_trials=1 \
    EVALUATION.replan_steps=8 \
    EVALUATION.num_inference_steps=10 \
    EVALUATION.compile_action_infer=false \
    EVALUATION.visualize_future_video=true \
    EVALUATION.offload_text_encoder=true \
    EVALUATION.action_infer_mode=idm \
    EVALUATION.video_sigma_shift=1.0 \
    EVALUATION.action_sigma_shift=1.0 \
    EVALUATION.sigma_shift=null \
    EVALUATION.vjepa2_ac.enabled=false \
    EVALUATION.vjepa2_ac.guidance.enabled=false \
    EVALUATION.vjepa2_ac.camera.preset=libero_default \
    EVALUATION.vjepa2_ac.camera.position=null \
    EVALUATION.vjepa2_ac.camera.quaternion=null \
    EVALUATION.vjepa2_ac.camera.fovy=null \
    EVALUATION.vjepa2_ac.camera.image_rotation_degrees=180 \
    EVALUATION.trigger_probe.enabled=true \
    EVALUATION.trigger_probe.ac_steps=8 \
    "EVALUATION.vjepa2_ac.checkpoint_path=$VJEPA2_CHECKPOINT" \
    "EVALUATION.vjepa2_ac.repo_path=$VJEPA2_REPO" \
    EVALUATION.vjepa2_ac.dtype=float32 \
    model.load_text_encoder=true \
    model.redirect_common_files=false \
    model.skip_dit_load_from_pretrain=true \
    seed=7

status=$?
echo "[$(date '+%F %T')] FINISHED status=$status" | tee -a "$output_root/completion.log"
exit "$status"
