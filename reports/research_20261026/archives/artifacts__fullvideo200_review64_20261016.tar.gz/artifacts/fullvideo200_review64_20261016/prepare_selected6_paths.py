"""CPU-only all-replan path sheets for six visually selected episodes."""
import json, concurrent.futures
from pathlib import Path
import numpy as np
import imageio.v2 as imageio
from PIL import Image,ImageDraw
ROOT=Path('/data/pxchen/PACT-WAM')
OUT=ROOT/'artifacts/fullvideo200_review64_20261016'
MEDIA=ROOT/'evaluate_results/fastwam_noguidance_long200_fullvideo_camera_fixed_20261015/formal/libero_10'
DEST=OUT/'selected6_paths';DEST.mkdir(exist_ok=True)
def read(p):
 r=imageio.get_reader(p,input_params=['-threads','1']);a=[f for f in r];r.close();return a
def one(tid):
 p=next((MEDIA/'videos').glob(f'task{tid}_trial0--*actual.mp4'))
 actual=read(p);controls=np.array(json.loads(p.with_suffix('.json').read_text())['source_control_indices'])
 base=MEDIA/'full_predictions'/f'task{tid}_trial0'
 replans=json.loads((base/'index.json').read_text())['replans']
 def get(t):return actual[int(np.abs(controls-t).argmin())] if t<=controls[-1] else None
 for page in range((len(replans)+10)//11):
  canvas=Image.new('RGB',(7*144,11*167+62),'white');d=ImageDraw.Draw(canvas)
  d.text((4,3),f'Task {tid} / seed7 trial0 / ALL replans / page {page+1} / controls through {controls[-1]}',fill='black')
  labels=['Actual start','Pred +8 main','Actual +8 main','Pred +32 main','Actual +32 main','Pred +32 wrist','Actual +32 wrist']
  for c,s in enumerate(labels):d.text((c*144+2,25),s,fill='black')
  for row,k in enumerate(range(page*11,min((page+1)*11,len(replans)))):
   ent=replans[k];pred=read(base/ent['file']);assert len(pred)==9
   start=ent['control_start'];frames=[get(start),pred[2],get(start+8),pred[8],get(start+32),pred[8],get(start+32)]
   for col,f in enumerate(frames):
    x=col*144;y=62+row*167;d.text((x+2,y+1),f'r{k} t{start}'+('' if col==0 else ('+8' if col in [1,2] else '+32')),fill='black')
    if f is not None:
     crop=f[:,192:384] if col>=5 else f[:,:192]
     canvas.paste(Image.fromarray(crop).resize((144,144)),(x,y+20))
    else:d.text((x+4,y+70),'Not recorded',fill='black')
  canvas.save(DEST/f'task{tid:04d}_page{page+1:02d}.jpg',quality=88)
 print('PATH',tid,len(replans),int(controls[-1]),flush=True)
 return {'task_id':tid,'replans':len(replans),'last_control':int(controls[-1]),'actual_frames':len(actual),'pages':(len(replans)+10)//11}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(one,[151,242,260,321,559,590]))
(DEST/'coverage.json').write_text(json.dumps(rows,indent=2))
print('DONE',flush=True)
