# 六条候选：完整时间路径复核

## 名单与覆盖

固定名单：**151、242、260、321、559、590**，全部 **seed=7、trial=0**。名单保留初筛记录，不因后续复核而无声替换。

- 来源：`fastwam_noguidance_long200_fullvideo_camera_fixed_20261015`，no guidance、replan执行8步、每段预测32步。
- 覆盖每条全部87段已保存预测（r0–r86，起点control0–688），合计522段；48张全路径对照页已逐页查看。每段对照预测+8、+32及实际同时间点，+32另外对照腕部。
- 另精查9段转折replan的全部9帧及主/腕部实际图，并对151的control304–352按现有每2步一帧密集检查。此前已有33段候选精查仍保留。
- 实际路径按8步间隔覆盖全程并检查最终control699；不是声称逐一人工检查了每条350余张实际帧，也不是对522段预测每帧都完成了精查。
- **记录缺口：**结果日志每条记88次replan，但完整预测索引仅87段；最后一次（若按8步起点推算为696）没有对应保存片段。实际结尾可见，不能补判该次预测。
- 本报告时间为控制步，从0计，不是视频播放秒数。阶段边界是视觉估计范围，不是接触传感器或仿真状态给出的精确事件标签。

## 总结

5条为长期停滞，1条（151）为延迟抓取后掉落。主要停滞不是随机在整条轨迹中发生：3条集中在放杯后撤手，2条集中在抓罐。

**151的r41是此次新增最有价值的证据：同一8步执行前缀内，预测继续持罐，实际罐子分离跌落。**其他5条的明显任务进展差异多数在预测+20至+32，实际已包含后续replan。

| Task ID | seed | 类型 | 关键观察 |
|---|---:|---|---|
| 151 | 7 | 延迟抓取后掉落，随后未恢复 | r34只展示局部时间进度差；实际后来确实提起。更强证据是r41：起点control328，预测+4/+8仍持罐，实际约330–336已分离/落下，338附近在桌面横倒。r42起预测接受倒罐观测，但没有展示可靠回抓。 |
| 242 | 7 | 放杯后撤手停滞 | 杯在约128时已到盘上，但手直到699仍在杯口附近。r30（起点240）及r34（272）预测后半段手离开杯口，实际没有相应进展；后期预测重影增多，不能把所有后期预测都判为合理。 |
| 260 | 7 | 放杯后撤手停滞 | 约112–120杯已到盘上。r14（112）、r17（136）、r34（272）预测+24/+32抬手离杯，实际仅在原处缓慢改变姿态，最终仍未撤离。 |
| 321 | 7 | 抓罐阶段持续停滞 | 开头约24步完成接近，随后红绿罐一直留在桌面。r0已出现未来姿态差，r34/r52清楚预测提罐，后续仍反复预测抬起，但实际到699没有恢复。 |
| 559 | 7 | 放杯后撤手停滞 | 约104–112杯已到盘上。r13（104）的预测+24/+32抬手离杯，实际在杯口停住；r17/r34及后续仍反复出现相同分离，直至699。 |
| 590 | 7 | 抓罐阶段持续停滞 | 约32步末端到蓝罐附近，之后未可靠提起。r3（24）预测在+24/+32提罐，实际仍悬停；r17/r34及后续继续重复，直至699。 |

## 三个不能混为一谈的结论

1. **实际长期停滞**：视频直接支持。
2. **视频想象的局部动作有进展**：若物体连续、目标正确，可作为局部分离证据；不等于该未来物理上一定可实现。
3. **为什么停滞、为什么掉落**：现有媒体没有足够的夹爪指令、接触力和逐步机器人状态证据，不能确定为松爪、碰撞、控制幅度不足或动力学错误。

一个贯穿5条停滞样本的现象是：预测前8步变化较小，明显提起/撤离主要出现在后半段；下一次replan又从几乎相同实际状态重新预测。这符合“进展不断被放到未来后半段”的表象。它使receding-horizon停滞成为待解释方向，但仅凭视频不能证明原因就是执行截断，不能据此擅自改变replan步数。

这些6条只来自3个基础长任务，其中3条属于同一个“白杯放盘+布丁盒”任务，不能当作6类独立任务。

## 分轨迹详细记录

### Task 151 / seed 7 / trial 0

指令：put both the alphabet soup and the tomato sauce in the basket table 9

OOD：Background Textures。类型：延迟抓取后掉落，随后未恢复。

| 实际control范围（约） | 实际路径观察 |
|---|---|
| 0–39 | 接近蓝罐 |
| 40–87 | 抓起蓝罐并向篮子搬运 |
| 88–143 | 蓝罐进入篮内，手离开篮口 |
| 144–207 | 手移向红绿罐 |
| 208–321 | 在红绿罐附近调整，尚未形成稳定抬升 |
| 322–329 | 红绿罐随手短暂抬起 |
| 330–339 | 罐与夹爪分离并跌落，罐横倒在篮外 |
| 340–399 | 空手继续移向篮口，未回抓倒罐 |
| 400–699 | 手停在篮口附近；红绿罐始终留在篮外 |

r34只展示局部时间进度差；实际后来确实提起。更强证据是r41：起点control328，预测+4/+8仍持罐，实际约330–336已分离/落下，338附近在桌面横倒。r42起预测接受倒罐观测，但没有展示可靠回抓。

证据范围：直接8步前缀中的物体运动分离：r41；不能证明具体控制或接触故障机制。

完整路径页：[第1页](selected6_paths/task0151_page01.jpg) / [第2页](selected6_paths/task0151_page02.jpg) / [第3页](selected6_paths/task0151_page03.jpg) / [第4页](selected6_paths/task0151_page04.jpg) / [第5页](selected6_paths/task0151_page05.jpg) / [第6页](selected6_paths/task0151_page06.jpg) / [第7页](selected6_paths/task0151_page07.jpg) / [第8页](selected6_paths/task0151_page08.jpg)

- [关键转折：transition_task0151_r039](selected6_paths/transition_task0151_r039.jpg)
- [关键转折：transition_task0151_r040](selected6_paths/transition_task0151_r040.jpg)
- [关键转折：transition_task0151_r041](selected6_paths/transition_task0151_r041.jpg)
- [关键转折：transition_task0151_r042](selected6_paths/transition_task0151_r042.jpg)

[实际密集帧304–330](selected6_paths/task0151_actual_dense1.jpg) / [实际密集帧332–352](selected6_paths/task0151_actual_dense2.jpg)

### Task 242 / seed 7 / trial 0

指令：put the white mug on the plate and put the chocolate pudding to the right of the plate table 18

OOD：Background Textures。类型：放杯后撤手停滞。

| 实际control范围（约） | 实际路径观察 |
|---|---|
| 0–55 | 接近白杯 |
| 56–87 | 提起白杯 |
| 88–127 | 把杯子搬到盘上 |
| 128–263 | 手持续停在杯口附近，未进入布丁盒阶段 |
| 264–351 | 杯口附近小幅调整，仍无可靠撤手 |
| 352–699 | 持续停滞；布丁盒仍未搬运 |

杯在约128时已到盘上，但手直到699仍在杯口附近。r30（起点240）及r34（272）预测后半段手离开杯口，实际没有相应进展；后期预测重影增多，不能把所有后期预测都判为合理。

证据范围：主要是+20至+32的跨replan分离，强度中等；是否松爪未知。

完整路径页：[第1页](selected6_paths/task0242_page01.jpg) / [第2页](selected6_paths/task0242_page02.jpg) / [第3页](selected6_paths/task0242_page03.jpg) / [第4页](selected6_paths/task0242_page04.jpg) / [第5页](selected6_paths/task0242_page05.jpg) / [第6页](selected6_paths/task0242_page06.jpg) / [第7页](selected6_paths/task0242_page07.jpg) / [第8页](selected6_paths/task0242_page08.jpg)

- [关键转折：transition_task0242_r030](selected6_paths/transition_task0242_r030.jpg)

### Task 260 / seed 7 / trial 0

指令：put the white mug on the plate and put the chocolate pudding to the right of the plate tb 12

OOD：Background Textures。类型：放杯后撤手停滞。

| 实际control范围（约） | 实际路径观察 |
|---|---|
| 0–47 | 接近并抓白杯 |
| 48–87 | 提杯并搬向盘子 |
| 88–119 | 杯子到达盘上 |
| 120–199 | 夹爪停在杯口附近 |
| 200–343 | 夹爪原位逐渐转向，但未完成撤离 |
| 344–699 | 停在杯口附近；未进入布丁盒阶段 |

约112–120杯已到盘上。r14（112）、r17（136）、r34（272）预测+24/+32抬手离杯，实际仅在原处缓慢改变姿态，最终仍未撤离。

证据范围：主要是+20至+32的跨replan分离；不能确认夹爪保持闭合。

完整路径页：[第1页](selected6_paths/task0260_page01.jpg) / [第2页](selected6_paths/task0260_page02.jpg) / [第3页](selected6_paths/task0260_page03.jpg) / [第4页](selected6_paths/task0260_page04.jpg) / [第5页](selected6_paths/task0260_page05.jpg) / [第6页](selected6_paths/task0260_page06.jpg) / [第7页](selected6_paths/task0260_page07.jpg) / [第8页](selected6_paths/task0260_page08.jpg)

- [关键转折：transition_task0260_r014](selected6_paths/transition_task0260_r014.jpg)

### Task 321 / seed 7 / trial 0

指令：put both the alphabet soup and the tomato sauce in the basket view 0 0 100 0 0 initstate 401

OOD：Robot Initial States。类型：抓罐阶段持续停滞。

| 实际control范围（约） | 实际路径观察 |
|---|---|
| 0–23 | 从初始姿态接近红绿罐并调整末端方向 |
| 24–699 | 长期停在红绿罐上方；未形成可靠提罐与入篮 |

开头约24步完成接近，随后红绿罐一直留在桌面。r0已出现未来姿态差，r34/r52清楚预测提罐，后续仍反复预测抬起，但实际到699没有恢复。

证据范围：可靠的长期局部停滞；关键提罐进展主要位于预测后半段，不证明单个8步动作段失效。

完整路径页：[第1页](selected6_paths/task0321_page01.jpg) / [第2页](selected6_paths/task0321_page02.jpg) / [第3页](selected6_paths/task0321_page03.jpg) / [第4页](selected6_paths/task0321_page04.jpg) / [第5页](selected6_paths/task0321_page05.jpg) / [第6页](selected6_paths/task0321_page06.jpg) / [第7页](selected6_paths/task0321_page07.jpg) / [第8页](selected6_paths/task0321_page08.jpg)

- [关键转折：transition_task0321_r000](selected6_paths/transition_task0321_r000.jpg)

### Task 559 / seed 7 / trial 0

指令：put the white mug on the plate and put the chocolate pudding to the right of the plate view 0 0 100 0 0 initstate 427

OOD：Robot Initial States。类型：放杯后撤手停滞。

| 实际control范围（约） | 实际路径观察 |
|---|---|
| 0–47 | 接近并抓白杯 |
| 48–87 | 提杯并搬向盘子 |
| 88–111 | 杯子到达盘上 |
| 112–699 | 手持续停在杯口附近；未进入布丁盒阶段 |

约104–112杯已到盘上。r13（104）的预测+24/+32抬手离杯，实际在杯口停住；r17/r34及后续仍反复出现相同分离，直至699。

证据范围：主要是+24至+32的跨replan分离；是否正确松爪未知。

完整路径页：[第1页](selected6_paths/task0559_page01.jpg) / [第2页](selected6_paths/task0559_page02.jpg) / [第3页](selected6_paths/task0559_page03.jpg) / [第4页](selected6_paths/task0559_page04.jpg) / [第5页](selected6_paths/task0559_page05.jpg) / [第6页](selected6_paths/task0559_page06.jpg) / [第7页](selected6_paths/task0559_page07.jpg) / [第8页](selected6_paths/task0559_page08.jpg)

- [关键转折：transition_task0559_r013](selected6_paths/transition_task0559_r013.jpg)

### Task 590 / seed 7 / trial 0

指令：put both the alphabet soup and the cream cheese box in the basket view 0 0 100 0 0 initstate 338

OOD：Robot Initial States。类型：抓罐阶段持续停滞。

| 实际control范围（约） | 实际路径观察 |
|---|---|
| 0–31 | 末端向蓝罐接近 |
| 32–699 | 长期停在蓝罐上方；蓝罐留在桌面，未搬入篮内 |

约32步末端到蓝罐附近，之后未可靠提起。r3（24）预测在+24/+32提罐，实际仍悬停；r17/r34及后续继续重复，直至699。

证据范围：主要是预测后半段的抬升与实际停滞；未定位夹爪接触失败机制。

完整路径页：[第1页](selected6_paths/task0590_page01.jpg) / [第2页](selected6_paths/task0590_page02.jpg) / [第3页](selected6_paths/task0590_page03.jpg) / [第4页](selected6_paths/task0590_page04.jpg) / [第5页](selected6_paths/task0590_page05.jpg) / [第6页](selected6_paths/task0590_page06.jpg) / [第7页](selected6_paths/task0590_page07.jpg) / [第8页](selected6_paths/task0590_page08.jpg)

- [关键转折：transition_task0590_r003](selected6_paths/transition_task0590_r003.jpg)

## 保留的不确定项

- 所有轨迹：未保存的最后一次预测无法复核；不能判断该预测是否提出了恢复动作。
- 151：掉落在330–338区间清楚可见，但具体脱离接触的瞬间和原因无法靠192像素视频精确确定；r41后半段预测也有形变。
- 242：预测重影较明显，仅保留形态较连续的r34撤手证据作为中等可信度例子，不能认定后期每段预测都合理。
- 242/260/559：杯子到盘上可见，不等于已通过仿真成功条件验证放杯子目标；夹爪是否松开、是否夹住杯沿不能直接确定。
- 321/590：不能从手在物体上方推断夹爪实际闭合、接触、被碰撞卡住；这里只确认没有形成对应物体搬运。
- 均不能认定完整Long任务的imagined trajectory成功；每段预测是独立的32步未来，不应拼接成一条“成功计划”。

