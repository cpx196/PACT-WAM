import json
from pathlib import Path
import numpy as np,imageio.v2 as imageio
from PIL import Image,ImageDraw
ROOT=Path('/data/pxchen/PACT-WAM')
OUT=ROOT/'artifacts/fullvideo200_review64_20261016/selected6_paths'
MEDIA=ROOT/'evaluate_results/fastwam_noguidance_long200_fullvideo_camera_fixed_20261015/formal/libero_10'
def read(p):
 r=imageio.get_reader(p,input_params=['-threads','1']);a=[x for x in r];r.close();return a
for tid,rs in {151:[39,40,41,42],242:[30],260:[14],321:[0],559:[13],590:[3]}.items():
 p=next((MEDIA/'videos').glob(f'task{tid}_trial0--*actual.mp4'));actual=read(p)
 controls=np.array(json.loads(p.with_suffix('.json').read_text())['source_control_indices'])
 base=MEDIA/'full_predictions'/f'task{tid}_trial0';replans=json.loads((base/'index.json').read_text())['replans']
 for rid in rs:
  ent=replans[rid];pred=read(base/ent['file']);im=Image.new('RGB',(960,1760),'white');d=ImageDraw.Draw(im)
  d.text((4,4),f'Task {tid}, replan {rid}, start {ent["control_start"]}; W predicted; A actual',fill='black')
  for k in range(9):
   target=ent['control_start']+4*k;a=actual[int(np.abs(controls-target).argmin())]
   for q,(src,label) in enumerate([(pred[k],'W main'),(a,'A main'),(pred[k],'W wrist'),(a,'A wrist')]):
    x=(k%5)*192;y=40+((k//5)*4+q)*215
    d.text((x+2,y+2),f'{label} {target} (+{k*4})',fill='black')
    start=192 if q>=2 else 0;im.paste(Image.fromarray(src[:,start:start+192]),(x,y+21))
  im.save(OUT/f'transition_task{tid:04d}_r{rid:03d}.jpg',quality=88)
 if tid==151:
  times=list(range(304,354,2))
  for page in range(2):
   ts=times[page*14:(page+1)*14];im=Image.new('RGB',(7*192,2*2*215+35),'white');d=ImageDraw.Draw(im)
   d.text((4,4),'Task151 ACTUAL dense frames; main/wrist paired; seed7',fill='black')
   for j,t in enumerate(ts):
    f=actual[int(np.abs(controls-t).argmin())]
    for q in [0,1]:
     x=j%7*192;y=35+(j//7*2+q)*215;d.text((x+2,y+2),f'control {t} '+('main' if q==0 else 'wrist'),fill='black')
     im.paste(Image.fromarray(f[:,q*192:(q+1)*192]),(x,y+21))
   im.save(OUT/f'task0151_actual_dense{page+1}.jpg',quality=90)
 print('DONE',tid,rs,flush=True)
