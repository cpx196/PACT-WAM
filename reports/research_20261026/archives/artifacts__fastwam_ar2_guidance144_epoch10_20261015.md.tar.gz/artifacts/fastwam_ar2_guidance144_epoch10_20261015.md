# FastWAM 144 — JEPA 2.1 AR2 epoch10

只替换 JEPA Encoder、Predictor 和必要的 JEPA 旁路输入接口。原 FastWAM、Action Expert、执行器、任务列表不变。

- Encoder：冻结官方 V-JEPA2.1 ViT-L384 distilled，主视角，native 图像/双帧编码。
- Predictor：`artifacts/fastwam_predictor21_ar2_full10epoch_bs16_20261014/step19690.pt`，10 epoch。
- 当前 latent `[1,576,1024]`；状态 `[1,8]` = XYZ/轴角/两指 qpos。
- 原始控制动作 `[1,8,7]`，前4步/后4步，train-only normalization。
- 两步自回归，不 detach：`P1(z0,a0:4,s0)` → `P2(P1,a4:8,s0)`。
- 比较 WAM 帧对 `[t,t+4]`、`[t+4,t+8]` 的 JEPA 联合 latent；两项 L1 均值，无额外 LayerNorm。
- 不使用旧的控制指令积分、Euler 状态转换、响应校准系数。
- 保留历史相机 rot180；JEPA 不额外旋转，主相机从拼接视频左半边提取。
- FastWAM optional-IDM 原权重，BF16；JEPA FP32；不 compile。
- 10 denoise steps；video/action shift=1/1；replan 执行8步。
- 全程 guidance，trigger/probe 关闭；节点7/8/9；raw gradient4x，RMS≤0.02，verify_descent 开启。
- 相同36任务 × seed7/17/27/37，144条；不重采样任务。
- 单卡 GPU3，nohup；48步 smoke 不计入144，自动验证通过才运行正式评测。

服务器输出：`/data/pxchen/PACT-WAM/evaluate_results/fastwam_guidance789_ar2_epoch10_full144_20261015`

启动日志：`/data/pxchen/PACT-WAM/artifacts/fastwam_ar2_guidance144_epoch10_20261015_launcher.log`

隔离脚本：`scripts/fastwam_ar2_eval.py`、`scripts/fastwam_ar2_manager.py`、`scripts/launch_fastwam_ar2_guidance144.py`。

运行环境需设置 `LD_LIBRARY_PATH=/data/pxchen/envs/jepa-wam/lib`；隔离 worker 先加载 Wand，避免视觉依赖的 codec 动态库冲突。

## 启动确认（服务器时间 2026-10-15 00:47）

- nohup launcher PID：738537；GPU3；正式状态 `FULL144_RUNNING seed=7`。
- smoke 通过：6 replans、18 guidance 节点，平均梯度 RMS 0.005205，最大修正 RMS 0.0200000014（浮点误差范围）。
- 第一条正式 task365/seed7 成功，完整任务用时132.39秒；第二条已运行多次 replan。
- 第一个完整任务峰值实际分配16.30GiB，reserved20.24GiB；无 OOM。
- 按实测 replan约3–4秒、不同任务的提前成功/超时范围，预计剩余约6–8小时，今天07–09点左右完成；首条任务并非全体平均。
- 早期失败的 smoke 是环境导入/配置入口问题，已退出并保留在 `smoke_failed_*`，不计入144，也未留下重复 GPU 任务。
- 原烟雾检查器的 `calibration_verified` 字段仅校验历史配置值，不表示本次使用旧积分或校准。实际旁路是 raw 控制序列；本次不应用旧响应校准。
