# Corrected predictor training — 2026-09-28

User authorized two-GPU training after reviewing the parameter settings.
No old mismatched guidance evaluation is restarted.

## Data contract

Version `libero_ac_euler_v1`. LIBERO HDF5 ee_states = XYZ + axis-angle;
convert axis-angle to Euler XYZ before constructing the AC state. Online
observation quaternion is converted to the same Euler XYZ convention.
Position is in metres, angles in radians, gripper state is observed closedness.
The later AC state is integrated from commands by the shared adapter, not
measured ground-truth future EEF. Low-level command rotations are composed by
the adapter; they are not directly interpreted as Euler angles.

Agentview only, context [t-8,t], future clips [t,t+4] and [t+4,t+8], 8 low-level
actions grouped into 2 AC steps of stride 4. Both context and future images
rotate 180 degrees as in the chosen online image convention. This image rotation
does not rotate the EEF world coordinate system. Resize to 256x256 and normalize
as before. Source HDF5 remains untouched.

CPU preflight PASSED on 90 files, 360 windows including training/validation
trajectories from every file: rotation matrices, online-equivalent state,
NumPy/Torch adapter agreement, shapes/finiteness. 4,050 train / 450 validation
trajectories, split by demo, not by individual frame.
Training script SHA256 at preflight:
`0ee87edce81811ade6c96a45e7696dd527b512246584cec27768bf480e5f9313`.

## Model and optimization

Original initializer `/data/pxchen/JEPA_WAM/checkpoints/vjepa2/vjepa2-ac-vitg.pt`.
No continuation from the erroneous step2000 or from the smoke checkpoint.
Encoder frozen; predictor trained except unused frozen extrinsics encoder.
FP32 model parameters with BF16 autocast. AdamW lr 1e-5, weight decay 0.04,
betas 0.9/0.999, eps 1e-8, warmup100, cosine floor1e-6, clip grad norm1.0.
Teacher-forced L1 + autoregressive L1, weights1:1; AR averages the two future
steps. Batch8 per GPU x2, accum1, effective batch16, seed239, workers2 per rank.
2,000 optimizer steps, save/validate every500. Save predictor, optimizer,
scheduler, step and configuration. Resume rejects legacy/unknown format versions.

## Execution and resources

Launcher `scripts/launch_libero90_euler_fixed_dual.sh`, nohup+setsid.
Wait at most two hours for two cards with no compute processes; never occupy
one GPU while waiting for another. Small graphics residual (<1GiB) is permitted.
No sharing with other people's compute jobs. After selection, run two-GPU
20-step smoke + checkpoint check, then start formal training from original weights.
The availability check cannot reserve cards against other users; any resulting
failure stops the launcher rather than killing their jobs.

Output `/data/pxchen/PACT-WAM/artifacts/jepa_libero90_euler_fixed_rot180_20260928`.
Status in status.txt; selected cards in gpu_assignment.txt. Smoke and formal
training logs separate. Estimated60–75 minutes after two cards become available,
including smoke/load time, excluding queue wait. Not yet a convergence claim.
