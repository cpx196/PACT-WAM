# FastWAM guidance 夹爪一致性修复

已应用到服务器 `/data/pxchen/PACT-WAM/experiments/libero/eval_libero_single.py` 的 `_build_jepa_action_guidance`，只修改 guidance 输入构造。

- 夹爪走执行端的CPU反归一化，保留原始normalizer精度；按同样的开合方向和binarize_gripper配置处理。
- 夹爪命令detach，guidance不再直接对夹爪施加梯度更新；位姿6维仍保留原有前向和反向路径。
- 原生去噪、AR2梯度链、执行后处理、模型权重未修改。以后原生去噪仍可能因位姿潜变量变化间接改变夹爪预测，修复不声称整个guided rollout的夹爪必然与无guidance完全相同。
- 新增CPU回归脚本：`/data/pxchen/PACT-WAM/scripts/test_guidance_gripper_consistency.py`。

CPU检查通过：二值化开/关、批次与8步horizon、开合边界、float64 normalizer边界精度、零夹爪梯度、位姿前向及梯度保持、直接更新不改变夹爪。旧实现无法通过该回归。AST比较确认其他顶层代码不变。

未加载WAM/Predictor模型，未训练，未运行rollout；不据此声称成功率提升。

远端备份与检查记录：`/data/pxchen/PACT-WAM/artifacts/guidance_gripper_fix_20261021/`。本目录包含修改前后副本和检查脚本。
