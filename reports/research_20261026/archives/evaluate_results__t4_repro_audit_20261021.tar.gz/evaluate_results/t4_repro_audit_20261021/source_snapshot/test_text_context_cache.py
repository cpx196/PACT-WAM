import json,tempfile
from pathlib import Path
import torch
from experiments.libero.text_context_cache import save_cache,load_cache
p=Path(tempfile.mkdtemp(prefix='t4_cache_test_'))
identity=dict(dtype='torch.float32',encoding_batch_size=1,context_len=2)
cache={str(i):(torch.arange(8,dtype=torch.float32).reshape(1,2,4)+i,torch.ones(1,2,dtype=torch.bool)) for i in range(3)}
sha=save_cache(cache,p/'cache.pt',identity)
for prompts in (['0'],['2','0'],['0','1','2']):
 loaded,_=load_cache(p/'cache.pt',identity,prompts,sha)
 assert list(loaded)==prompts
 assert all(torch.equal(loaded[k][0],cache[k][0]) for k in prompts)
for args in ((identity,['missing'],sha),({**identity,'context_len':3},['0'],sha),(identity,['0'],'0'*64)):
 try:load_cache(p/'cache.pt',*args)
 except ValueError:pass
 else:raise AssertionError('Invalid cache accepted')
try:save_cache(cache,p/'cache.pt',identity)
except FileExistsError:pass
else:raise AssertionError('Existing cache overwritten')
payload=torch.load(p/'cache.pt',weights_only=True);payload['contexts']['0'][0][0,0,0]=100
corrupt=p/'corrupt.pt';torch.save(payload,corrupt)
try:load_cache(corrupt,identity,['0'])
except ValueError:pass
else:raise AssertionError('Corrupt tensor accepted')
print(json.dumps(dict(passed=True,checks=['subset_order_independence','bitwise_tensor_roundtrip','missing_prompt_rejected','asset_identity_rejected','file_hash_rejected','immutable_cache','tensor_corruption_rejected'])))
