# Full guidance 144 — corrected EEF predictor

Approved run: 36 original LIBERO-plus long-horizon tasks, seeds7/17/27/37,
one trial each (144 episodes). GPUs4/5 only. GPU4 runs7 then17; GPU5 runs27
then37. Detached nohup+setsid launcher, exclusive launcher lock and startup
idle-memory checks. No control rerun. Independent output directory:
evaluate_results/guidance789_rawgrad4x_long36_full144_euler_fixed_step2000_20260929.

Task file unchanged from original 144 run:
artifacts/evaluate_results/long36_ten_vs_789_20260916_231154_2gpu/ten_guidance_789/seed_7/libero_plus_long_36_three_perturbations_two_variants.txt.
Each seed output retains task file and effective manager configuration.

FastWAM optional-IDM two-camera checkpoint libero_optional_idm_2cam224.pt,
BF16, unchanged. JEPA float32, frozen original encoder plus newly trained
libero_ac_euler_v1 predictor step2000; source training checkpoint:
artifacts/jepa_libero90_euler_fixed_rot180_20260928/train_2000/step_002000.pt.
Inference checkpoint vjepa2-ac-libero90-euler-fixed-rot180-step2000-inference.pt.
Both JEPA context and generated future use inverted images as in original run;
camera rotation180, additional encoder rotation0, JEPA main view only.

Full guidance every replan, trigger disabled. Raw gradient4x after denoise
steps7/8/9, normalize=false, RMS cap0.02, AC steps2, verify_descent=true.
Video/action sigma shifts1/1; 10 denoise steps; execute8 actions/replan.
Encoder/action overlap enabled; compile_action_infer=false. Defaults retained:
30 wait steps and suite default episode length (max_steps_override=null).
No new gripper protection or coordinate-compatibility workaround.

Old144 total episode duration7.63 GPU-hours; two balanced queues3.75/3.89h.
Estimated4–5h wall time plus variation due to changed successes/shared load.
Compare all144 with matching no-guidance and original guidance results;
report paired harm/rescue, not only aggregate accuracy.
