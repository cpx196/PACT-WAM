# FastWAM Long200：完整预测视频候选池

目的：从真实在线无guidance轨迹中，后续人工/模型检查“想象视频明确展示任务成功、但实际失败”的案例。200条是候选池，不要求全部成为核心案例；约20条清晰案例已可用于机制研究，不为凑数量放宽标准。

## 固定抽样

- LIBERO-Plus `libero_10` / Long，2519个OOD配置中抽取200个不同配置。
- 原始10任务各20条；7个OOD类别各28/29条，单seed7、每配置1次、初始状态index0。
- 抽样seed20261015；先固定清单，未读取成功/失败结果作选择。
- task SHA256：495c6a87798ae62fee848aae344e85a3a14982f5b13aba239b000d0e95435543。

## 推理参数

- 原FastWAM optional-IDM：`checkpoints/fastwam/libero_optional_idm_2cam224.pt`，BF16。
- 无guidance，无JEPA模型加载，无trigger/排名/ARB/新IDM。
- 10个action denoise步骤、video/action shift=1/1、replan执行8步、wait30步。
- 原始两相机224×448模型输入不变，原相机方向不变。
- 任务最大步数遵循原Long默认700，完整在线执行；每次replan重新预测，不读取未来真实图像。
- 不torch.compile。仅视频保存入口隔离修改，不编辑原FastWAM模型/执行器。

## 保存

- 每次replan单独保存全部9帧，即t,t+4,...,t+32，不再截成执行前8步对应的3帧。
- 每段预测5fps，保留所有原预测帧；两相机各192×192，总384×192。
- 实际执行每2步保留1帧、10fps、同样分辨率，另保留帧号映射。
- H264 CRF28、veryfast、1编码线程。
- 每段预测的replan编号、起始control step、预测偏移、success和语言保存在index.json。
- 不把不同replan的独立想象拼成一条“完整成功视频”。不重复保存原来的截短对比视频。

## 状态与资源（12:22核对）

- 唯一nohup等待器 PID1701856，状态WAITING_TWO_IDLE_GPUS。
- 当前没有两张空卡，未停止任何其他任务。双卡各连续空闲60秒才启动。
- 流程：等待双空卡→单卡48步smoke→验证各预测视频均9帧→重新等双卡→双卡200条。
- 尚未通过GPU smoke，因为当前没有空卡；CPU配置预检和视频编码/帧数检查已通过。
- 所选200条与历史无guidance有68条重合，历史平均117.83秒/条，双卡纯任务估算3.27小时；加加载、完整预测视频编码和任务差异，预计3.5–5小时，不含等卡。
- CPU压缩代理样本来自历史真实视频，不是新的模型推理；200条压缩外推约0.134GiB。生成图像压缩率可不同，保守预估0.3–1GB，建议预留2GB。临时测试视频已自动清理。

服务器输出：`/data/pxchen/PACT-WAM/evaluate_results/fastwam_noguidance_long200_fullvideo_20261015`

主要文件：task_manifest.json、sampling_summary.json、tasks200.txt、launcher.log、status.txt、launcher.pid、storage_time_estimate.json。

脚本：prepare_fullvideo200.py、fastwam_fullvideo200_eval.py、fastwam_fullvideo200_manager.py、launch_fullvideo200_wait.py。

## 12:44 改为单卡

- 用户要求改为单卡；旧双卡等待器1701856已经停止，保留旧等待日志 `launcher_dual_wait_only.log`。
- 新nohup launcher PID1828985，参数 `--num-gpus 1 --allow-orphan-memory-gpu 6`，没有重复任务。
- GPU6残留4544MiB CUDA上下文，其PID2067187已不存在，当前只有Xorg图形进程、无运行中的计算进程；未终止或清理任何其他进程。
- GPU6空余19544MiB（约19.1GiB）。历史无guidance最大allocated13.66GiB，具备余量；优先smoke确认。
- 严格空闲GPU仍可选；GPU6仅在残留PID已不存在、显存占用<5500MiB、GPU利用率<5%且持续稳定60秒时可选。不会与活跃计算进程共享。
- 12:44:02 已进入GPU6 smoke加载阶段。参数、清单、seed、视频分辨率均不变。
- 单卡预计7–10小时，不含后续异常等待；最终以正式启动时间计。

### smoke修复记录

- 第一轮48步动作推理正常完成，6次replan约1.4–1.5秒/次，无OOM；但视频断言发现返回的预测已在更早的 `_select_predicted_future_frames` 中被切为3帧。
- 该轮未进入正式200条，日志保存在 `smoke_failed_prefix_selector` 和 `launcher_single_prefix_failure.log`。
- 隔离录像入口现在同时绕开早期可视化帧选择，并在晚期执行前缀裁剪前复制全部9帧；原动作生成/执行代码未修改。
- 单独9帧选择测试已通过。12:50重启唯一nohup launcher PID1875256，12:51进入GPU6 smoke。
- 12:54第二轮smoke成功，task1162，6次replan、54帧预测全部保存；实际视频也已保存。
- `smoke_check.json` 已逐个读取MP4确认每段9帧；实际预测覆盖32控制步。
- 实测GPU峰值allocated13.66GiB、reserved13.88GiB，GPU6容量足够；无guidance/no JEPA加载核对通过。
- smoke单次replan均值1.55秒，额外完整预测编码6段共3.91秒。计入保存开销后，正式单卡预计7–10小时。
- 12:55:53 正式200条单卡worker已启动，GPU6，状态 `FULL200_RUNNING GPUs=6`；12:56核对处于模型加载阶段。预计今天20–23点完成（非精确承诺）。
