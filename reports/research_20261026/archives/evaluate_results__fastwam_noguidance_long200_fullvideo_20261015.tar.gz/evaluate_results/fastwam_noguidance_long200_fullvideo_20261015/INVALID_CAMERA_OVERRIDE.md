# Invalid evaluation: unintended camera override

This 2026-10-15 Long200 no-guidance run was stopped with user authorization.
The launch retained non-null camera position, quaternion and fovy from current
defaults, unlike the historical native-camera no-guidance baseline. Those
fields are applied even with JEPA disabled. Results must not be pooled with
the corrected run or used as the intended native FastWAM baseline.

All results, videos and logs are retained for diagnosis. A fresh corrected
run uses the identical 200-task manifest and seed7, explicitly null camera
pose/fovy overrides and a historical-success full-episode smoke gate.
