# Synthetic 144 result

This is **not** a full 144-episode rerun. It substitutes 13 new force-first4 rollouts into the prior 144-episode trigger results, assuming the other 131 outcomes would not change. Result JSON files are symlinks to their sources; see `merge_manifest.csv` for provenance. Videos are not copied.
