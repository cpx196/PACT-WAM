# 单基础任务跨OOD小规模测试

任务：把字母汤罐与番茄酱罐放入篮子。7类OOD各3个变体，共21条；seed7，初始状态索引0，每变体1次。光照仅有两个难度3变体，因此第三个取难度4。其余全部难度3。

全部沿用相机修正版200条的无guidance配置：optional-IDM FastWAM权重，BF16，10步denoise，replan8，video/action shift=1/1，wait30，max700，不编译。JEPA、guidance、trigger关闭。相机position/quaternion/fovy均null；原生图像旋转180度口径不变。保存全部可用32步预测视频及实际双视角视频。GPU6单卡。

每类仅3个变体用于行为对照，不构成稳定成功率估计。旧结果不用于选择变体；151也重跑以检查复现。各OOD单独使用LIBERO-plus自带变体，不叠加table9到其他OOD。预计60–90分钟，预留视频与日志约50–150MB。
