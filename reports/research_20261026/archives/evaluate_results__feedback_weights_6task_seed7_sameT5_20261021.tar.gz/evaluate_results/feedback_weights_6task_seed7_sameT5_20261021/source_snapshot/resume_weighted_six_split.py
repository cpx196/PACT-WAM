"""Resume existing queued experiment: small offline job now; full rollout later."""
import fcntl,hashlib,json,os,subprocess,time,traceback
from pathlib import Path
ROOT=Path('/data/pxchen/PACT-WAM')
OUT=ROOT/'evaluate_results/feedback_weights_6task_seed7_sameT5_20261021'
SRC=OUT/'source_snapshot'
PYTHON='/data/pxchen/envs/jepa-wam/bin/python'

def save(name,obj):
 p=OUT/name;q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(obj,indent=2));q.replace(p)
def idle():
 busy=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid','--format=csv,noheader'],text=True).split()
 rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,memory.free,utilization.gpu','--format=csv,noheader,nounits'],text=True).splitlines()
 return [r[0] for line in rows for r in [[x.strip() for x in line.split(',')]] if r[1] not in busy and int(r[2])>=18432 and int(r[3])<5]

def main():
 lock=(OUT/'launcher.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 (OUT/'launcher.pid').write_text(str(os.getpid()))
 assert not (OUT/'offline/weights_registry.json').exists()
 for name,digest in json.loads((OUT/'manifest.json').read_text())['source_sha256'].items():
  assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,('Source drift',name)
 env=os.environ.copy()
 env.update(TZ='Asia/Shanghai',MUJOCO_GL='egl',PYOPENGL_PLATFORM='egl',PYTHONUNBUFFERED='1',OMP_NUM_THREADS='4',TOKENIZERS_PARALLELISM='false',LIBERO_CONFIG_PATH='/data/pxchen/FastWAM/.libero_plus_config',DIFFSYNTH_MODEL_BASE_PATH='/data/pxchen/FastWAM/checkpoints',DIFFSYNTH_SKIP_DOWNLOAD='true',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',GUIDANCE_SIX_OUT=str(OUT),GUIDANCE_SIX_NATIVE_SHA256='25d1940d14035d9416ac26e42fb01d7350f61a8a330a09c48fc12c49b9d93d1b',GUIDANCE_SIX_CACHE_SHA256='6102e417e48e5e6d516f18d56d4556fcc09e8562ee7c7f6b6a7d0225e918522a',ACTION_WEIGHTS_OUT=str(OUT/'offline'),ACTION_WEIGHTS_REGISTRY=str(OUT/'offline/weights_registry.json'),PYTHONPATH=':'.join(map(str,[SRC,ROOT,ROOT/'src',Path('/data/pxchen/LIBERO-plus'),ROOT/'artifacts/jepawam_deploy_smoke_20261009/python_deps'])))
 env['LD_LIBRARY_PATH']='/data/pxchen/envs/jepa-wam/lib'+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
 for key in list(env):
  if key.startswith('LIBERO_WORKER_'):env.pop(key)
 def run(stage,cmd,logfile,gpu):
  env.update(CUDA_VISIBLE_DEVICES=str(gpu),MUJOCO_EGL_DEVICE_ID=str(gpu))
  save('progress.json',dict(state=stage,gpu=int(gpu),updated=time.strftime('%F %T')))
  with (OUT/logfile).open('w') as log:
   child=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
   save('active_process.json',dict(stage=stage,worker_pid=child.pid,launcher_pid=os.getpid(),gpu=int(gpu),started=time.strftime('%F %T')))
   rc=child.wait()
  if rc:raise RuntimeError((stage,rc))
 free=int(subprocess.check_output(['nvidia-smi','--id=3','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
 assert free>=6500,('Insufficient headroom on GPU3',free)
 save('split_stage_plan.json',dict(offline_gpu=3,offline_shared=True,allocator_limit_bytes=4*1024**3,initial_free_mib=free,rollout_policy='Separate wait for idle GPU with >=18432MiB free'))
 adopt=int(os.environ.get('ADOPT_OFFLINE_PID','0'))
 if adopt:
  cmd=Path(f'/proc/{adopt}/cmdline').read_bytes().decode()
  assert 'run_capped_calibration.py' in cmd,cmd
  save('active_process.json',dict(stage='OFFLINE_CALIBRATION',worker_pid=adopt,launcher_pid=os.getpid(),gpu=3,adopted=True))
  while Path(f'/proc/{adopt}').exists():
   progress=OUT/'offline/progress.json'
   if progress.exists() and json.loads(progress.read_text()).get('state')=='COMPLETED':break
   time.sleep(10)
  assert json.loads((OUT/'offline/progress.json').read_text())['state']=='COMPLETED','Adopted calibration failed'
 else:
  run('OFFLINE_CALIBRATION',[PYTHON,str(SRC/'run_capped_calibration.py')],'calibration.log',3)
 registry=json.loads(Path(env['ACTION_WEIGHTS_REGISTRY']).read_text());assert registry['complete'] and len(registry['tasks'])==3
 save('progress.json',dict(state='OFFLINE_COMPLETE_WAITING_ROLLOUT_GPU',updated=time.strftime('%F %T')))
 since={}
 while True:
  now=time.monotonic();available=idle();since={g:since.get(g,now) for g in available}
  ready=[g for g in available if now-since[g]>=60]
  save('gpu_wait.json',dict(stage='ROLLOUT',updated=time.strftime('%F %T'),available=available,required_free_mib=18432))
  if ready:gpu=ready[0];break
  time.sleep(15)
 old=json.loads((ROOT/'evaluate_results/fastwam_guidance789_ar2_epoch10_selected6_20261020/formal_command.json').read_text())
 args=[]
 for arg in old[2:]:
  key=arg.split('=',1)[0]
  if key.startswith('MULTIRUN.'):continue
  if key=='EVALUATION.output_dir':arg=key+'='+str(OUT)
  args.append(arg)
 args+=['EVALUATION.text_encoder_batch_size=1','EVALUATION.binarize_gripper=true','EVALUATION.task_suite_name=libero_10','EVALUATION.task_id=151','EVALUATION.use_action_ensembler=false']
 cmd=[PYTHON,str(SRC/'eval_weighted_six.py'),*args];save('command.json',cmd)
 run('GUIDANCE_PREFLIGHT_AND_SIX_ROLLOUTS',cmd,'run.log',gpu)
 assert json.loads((OUT/'progress.json').read_text())['state']=='COMPLETED'
 save('launcher_completed.json',dict(returncode=0,completed=time.strftime('%F %T')))

if __name__=='__main__':
 try:main()
 except BaseException:
  save('launcher_failure.json',dict(traceback=traceback.format_exc()));raise
