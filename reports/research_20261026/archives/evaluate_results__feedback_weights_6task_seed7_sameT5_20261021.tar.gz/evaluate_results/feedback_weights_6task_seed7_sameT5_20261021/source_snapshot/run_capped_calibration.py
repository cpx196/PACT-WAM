"""Predictor-only calibration with a hard PyTorch allocator budget."""
import os,runpy
from pathlib import Path
import torch
total=torch.cuda.get_device_properties(0).total_memory
budget=4*1024**3
torch.cuda.set_per_process_memory_fraction(budget/total,0)
print('CALIBRATION_ALLOCATOR_CAP_BYTES',budget,flush=True)
runpy.run_path(str(Path(__file__).with_name('calibrate_weighted_six.py')),run_name='__main__')
